//                                                             2024-07-31
//  pw.h     Meine WLAN-Zugangsdaten
//
//  WLAN-Zugangsdaten ausgelagert in pw.h         // ausgelagert in pw.h
//# const char* ssid = "WLAN-NETZWERK NAME";      // ausgelagert in pw.h
//# const char* password = "DEIN PASSWORT";       // ausgelagert in pw.h

const char* ssid = "FritzBoxName";
const char* password = "0123345678901234";

