<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
<html>
	<head>
		<?php $script_version = "0.5.0"; ?>
		<title>PHP: DCC-Lokdecoder programmieren und steuern Vers. <?php echo $script_version; ?></title>
		<meta name="author" content="Thomas Borrmann">
		<meta name="date" content="2003-10-01">
		<meta name="description" content="Frontend fuer DDL/DDW-Server, Version 0.3">
		<meta name="Content-Script-type" content="text/php">
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
		<link rel="stylesheet" type="text/css" href="./css/phpDDLterminal.css">

<!--
		Aenderungen
		09.10.03 -  srcp_send_to_server: zweistufige Datenabholung fuer DDW
		10.10.03 -  Bugfix: nicht initialisierte Variable in 'srcp_client_init'
								Server-Protokoll-Abfrage und automatische Umschaltung auf 0.7 eingebaut
		30.06.04 -  READ GL NMRA CV eingebaut.
-->

		<?php

			// in der Datei $config_file werden folgende Angaben vermerkt:
			// Server-Adresse und -Port
			// Logfile nach : 'file', 'screen', 'both', '' (kein Log)
			// Anzahl der History-Zeilen von manuell eingegebenen Befehlen
			$config_file = "./phpDDLterminal.conf";
			
			$debug = false;
			//$debug = true;		// Kommentarzeichen entfernen fuer Ablaufverfolgung

			$datadir = "./data"; 		// Datenpfad
			$logdir  = "./log";  		// Log-Pfad
			$locostack = $datadir . "/locostack";
			$socketid = $datadir . "/socketid";

			// die nachfolgenden Variablen werden im Programm gesetzt, bitte hier
			// nicht editieren
			$logfile = "";					// screen:BS, file:Datei, both: BS+Datei, leer:kein Log
			$erddcd_server = "";		// Serveradresse
			$erddcd_cmdport = "";		// Serverport
			$erddcd_timeout = 0;		// Timeout fuer Server-Handshake
			$erddcd_answer = "";		// Server-Response
			$macro_file = "";				// Decoder- bzw. Ablaufdatei
			$command_string = "";		// Kommando an den Server
			$logmsg = "";						// log-message, die unten am Schirm angezeigt wird
			$history_length = 0;		// Anzahl der History-Eintraege
			$erddcd_welcome = "";		// Server-Identifikation
			
			require( "./inc/phpSrcpFuncs.php.inc" );
			
		$debug = isset( $_GET["test"] )? true : $debug;
		?>
	</head>
	<body>
	<!-- 
		Das Script wird aufgerufen mit 
		- einzelnen Werten fuer ein Kommando
		- einem Namen fuer ein Macro
		- einem Namen fuer eine Decoderwert-Datei mit dem Aufbau 
			1. Zeile: Decoder-Name
			ab 2. Zeile: CVnn = xx
		Wenn eine Datei und ein Satz Einzelwerte angegeben ist, wird zuerst
		die Datei abgearbeitet und danach das Einzelkommando 
	-->
<?php

require( "./inc/phpSrcpParser.php.inc" );
echo_parms( $debug );

// wenn kein Script angegeben ist: Setup aufrufen
$script_type = ( isset( $_POST["script_type"] )? $_POST["script_type"] :
				( isset( $_GET["script_type"] )? $_GET["script_type"] : "setup" ) );
$script_type = ( $script_type != "" ? trim( $script_type ) : "setup" );

if ( isset( $_GET["emergency-stop"] ) )	{	// Notstop?
	if ( $_GET["emergency-stop"] == "emergency-stop" )	{
		get_defaults( $config_file );
		emergency_stop( $locostack );
		unset( $_POST );
		unset( $_GET );
	}
}

if ( isset( $_GET["server-reset"] ) )	{		// Server-Reset?
	if ( "RESET" == $_GET["server-reset"] )	{
		get_defaults( $config_file );
		srcp_send_to_server( "RESET", true );
		if ( file_exists( $locostack ) )
			unlink( $locostack );
		unset( $_POST );
		unset( $_GET );
	}
}

?>

	<table class="body"><tr>
		<td><img src="./img/vertHeadline.png" class="vert-headline" alt="Logo"></td>
		
	<!-- Start der Inhalte -->	
		<td style="padding-left:10px;">
		
		<table class="menue">
			<tr>
				<td class="menue" style="border-top:none;">
					&nbsp;&nbsp;
				</td>

				<?php
					// Beschriftung des Button => script_type
					$options = array( "Setup" => "setup",
														"Programmieren" => "decoder",
														"Fahren" => "control",
														"Status" => "status" );

					foreach( $options as $caption => $sct )	{
						if ( $script_type == $sct ) 
							echo "<td class=\"active-menue\">\n"; 
						else 
							echo "<td class=\"menue\">\n"; 
						echo " <a href=\"" . $_SERVER["PHP_SELF"] . "?script_type=" . $sct . "\" " .
							"class=\"" . ( $script_type == $sct? "active" : "menue" ) . "-button\">" . 
							 $caption . "</a>\n";
						echo "</td>\n";
					}
				?>
				<td class="menue" style="border-right:none;border-top:none;">
					&nbsp;&nbsp;
				</td>
			</tr>
		</table>

	<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" enctype="multipart/form-data">
		<?php
				
			switch ( $script_type )	{
				case "decoder": include( "./inc/phpDecoder.php.inc" );
												break;
				case "control": include( "./inc/phpControl.php.inc" );
												break;
				case "status" : include( "./inc/phpStatus.php.inc" );
												break;
				default				: include( "./inc/phpSetup.php.inc" );
			}
		 ?>

		<table class="menue">
			<tr>
				<td style="vertical-align:middle;font-size:8pt;font-weight:bold;font-stretch:condensed;
									text-align:left;">Server
				<?php echo $erddcd_server ?>:<?php echo $erddcd_cmdport ?>
				<!-- br --><?php //echo $erddcd_welcome; ?>
				</td>
				<td>
					<?php
							if ( !isset( $submit ) ) 
								$submit = "Ausf&uuml;hren";
					?>
					<input type="submit" class="pushbutton" value="<?php echo $submit ?>" accesskey="e">&nbsp;&nbsp;
					<input type="reset" class="pushbutton" value="Zur&uuml;cksetzen">
				</td>
			</tr>			
		</table>		
	</form>

	 <!-- hier landet die Antwort des Servers und der Powerswitch-->
	<?php require( "./inc/phpSrcpResponse.php.inc" ); ?>
	<?php srcp_client_term(); ?>	
	<!-- Ende der Aussentabelle -->
	</td></tr></table>
	
	</div></body>
</html>