//---------------------------------------------------------------------------

#ifndef setupH
#define setupH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Mask.hpp>

//---------------------------------------------------------------------------
class TsetupForm : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TComboBox *cbPorts;
   TLabel *lbPort;
   TButton *pbOK;
   TButton *pbCancel;
   TButton *pbSetupHelp;
   TGroupBox *gbSetupDecoderMode;
   TRadioButton *cbDirectMode;
   TRadioButton *cbPageMode;
   TRadioButton *cbAutoMode;
   TCheckBox *cbUSBserial;
   TGroupBox *gbSetupHardware;
   TCheckBox *cbSafeMode;
   TCheckBox *cbTest0Bit;
   TCheckBox *cbIs6604;
   TMaskEdit *mefWait;
   TLabel *lbWait;
   TLabel *Label4;
   TCheckBox *cbBulk;
   TEdit *efBulk;
   TLabel *lblBulk;
   TRadioButton *rbIsDDL;
   TRadioButton *rbIsPR1;
   TComboBox *cbLang;
   TLabel *lbl_Lang;
   TCheckBox *cb16457bps;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall pbCancelClick(TObject *Sender);
   void __fastcall pbOKClick(TObject *Sender);
   void __fastcall cbPortsChange(TObject *Sender);
   void __fastcall FormHide(TObject *Sender);
   void __fastcall cbDirectModeClick(TObject *Sender);
   void __fastcall cbPageModeClick(TObject *Sender);
   void __fastcall cbAutoModeClick(TObject *Sender);
   void __fastcall cbBulkClick(TObject *Sender);
   void __fastcall cbLangChange(TObject *Sender);
   void __fastcall cbUSBserialClick(TObject *Sender);
private:	// Anwender-Deklarationen
   void __fastcall setLanguages();
public:		// Anwender-Deklarationen
   __fastcall TsetupForm(TComponent* Owner);
   String newPR1Port;
   String newLang;
   bool bOK;
};
//---------------------------------------------------------------------------
extern PACKAGE TsetupForm *setupForm;
//---------------------------------------------------------------------------
#endif
