//---------------------------------------------------------------------------

#ifndef tolopH
#define tolopH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CPort.hpp"
#include "CPortCtl.hpp"
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include <ExtCtrls.hpp>
#include <CheckLst.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TmainForm : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TPageControl *pc1;
   TTabSheet *tsBasis;
   TTabSheet *tsFunction;
   TTabSheet *tsSpeedTab;
   TTabSheet *tsMore;
   TTabSheet *tsSingleCV;
   TTabSheet *tsAllCV;
   TButton *pbRead;
   TButton *pbVerify;
   TButton *pbWrite;
   TStatusBar *StatusBar1;
   TEdit *efCV;
   TLabel *Label1;
   TUpDown *updnCV;
   TEdit *efCVval;
   TGroupBox *gbCVbin;
   TEdit *efCVHex;
   TGroupBox *gbCVval;
   TLabel *lbDec;
   TLabel *lbHex;
   TCheckBox *CVbit7;
   TCheckBox *CVbit6;
   TCheckBox *CVbit5;
   TCheckBox *CVbit4;
   TCheckBox *CVbit3;
   TCheckBox *CVbit2;
   TCheckBox *CVbit1;
   TCheckBox *CVbit0;
   TLabel *Label5;
   TLabel *Label6;
   TLabel *Label7;
   TLabel *Label8;
   TLabel *Label9;
   TLabel *Label10;
   TLabel *Label11;
   TLabel *Label12;
   TLabel *lbMode;
   TLabel *lbSuccess;
   TTabSheet *tsRegister;
   TLabel *lbCV8;
   TEdit *efCV8;
   TEdit *efCV7;
   TLabel *lbCV7;
   TLabel *lbCV1;
   TEdit *efCV1;
   TLabel *cv1ok;
   TGroupBox *gbCV29;
   TCheckBox *CV29b0;
   TCheckBox *CV29b1;
   TCheckBox *CV29b2;
   TCheckBox *CV29b3;
   TCheckBox *CV29b4;
   TCheckBox *CV29b5;
   TEdit *efCV29;
   TLabel *lbCV2;
   TEdit *efCV2;
   TLabel *cv2ok;
   TLabel *lbCV5;
   TEdit *efCV5;
   TLabel *cv5ok;
   TLabel *lbCV6;
   TEdit *efCV6;
   TLabel *cv6ok;
   TLabel *lbCV3;
   TEdit *efCV3;
   TLabel *cv3ok;
   TLabel *lbCV4;
   TEdit *efCV4;
   TLabel *cv4ok;
   TLabel *lbCV17_18;
   TEdit *efCV17_18;
   TLabel *cv17_18ok;
   TLabel *lbCV9;
   TEdit *efCV9;
   TLabel *cv9ok;
   TLabel *lbCV19;
   TEdit *efCV19;
   TLabel *cv19ok;
   TCheckBox *CV19b7;
   TLabel *cv29ok;
   TCheckBox *CV29b6;
   TCheckBox *CV29b7;
   TButton *pbHardReset;
   TEdit *efCV105;
   TLabel *lbCV105;
   TLabel *cv105ok;
   TEdit *efCV106;
   TLabel *lbCV106;
   TLabel *cv106ok;
   TLabel *lbCV29;
   TStringGrid *sg1_1024;
   TLabel *lbCV33;
   TLabel *lbCV34;
   TLabel *lbCV35;
   TLabel *lbCV36;
   TLabel *lbCV37;
   TLabel *lbCV38;
   TLabel *lbCV39;
   TLabel *lbCV40;
   TLabel *lbCV41;
   TLabel *lbCV42;
   TLabel *lbCV43;
   TLabel *lbCV44;
   TLabel *lbCV45;
   TLabel *lbCV46;
   TLabel *lbFLv;
   TLabel *Label41;
   TLabel *Label42;
   TLabel *Label43;
   TLabel *Label44;
   TLabel *Label45;
   TLabel *Label46;
   TLabel *Label47;
   TLabel *Label48;
   TLabel *Label49;
   TLabel *Label50;
   TLabel *Label51;
   TLabel *Label52;
   TLabel *Label53;
   TPanel *pA12;
   TCheckBox *CV41b7;
   TCheckBox *CV42b7;
   TCheckBox *CV43b7;
   TCheckBox *CV44b7;
   TCheckBox *CV45b7;
   TCheckBox *CV46b7;
   TLabel *Label54;
   TPanel *pA11;
   TLabel *Label55;
   TCheckBox *CV41b6;
   TCheckBox *CV42b6;
   TCheckBox *CV43b6;
   TCheckBox *CV44b6;
   TCheckBox *CV45b6;
   TCheckBox *CV46b6;
   TPanel *pA9;
   TLabel *Label56;
   TCheckBox *CV37b7;
   TCheckBox *CV38b7;
   TCheckBox *CV39b7;
   TCheckBox *CV40b7;
   TCheckBox *CV41b4;
   TCheckBox *CV42b4;
   TCheckBox *CV43b4;
   TCheckBox *CV44b4;
   TCheckBox *CV45b4;
   TCheckBox *CV46b4;
   TPanel *pA10;
   TLabel *Label57;
   TCheckBox *CV41b5;
   TCheckBox *CV42b5;
   TCheckBox *CV43b5;
   TCheckBox *CV44b5;
   TCheckBox *CV45b5;
   TCheckBox *CV46b5;
   TPanel *pA7;
   TLabel *Label58;
   TCheckBox *CV37b5;
   TCheckBox *CV38b5;
   TCheckBox *CV39b5;
   TCheckBox *CV40b5;
   TCheckBox *CV41b2;
   TCheckBox *CV42b2;
   TCheckBox *CV43b2;
   TCheckBox *CV44b2;
   TCheckBox *CV45b2;
   TCheckBox *CV46b2;
   TPanel *pA8;
   TLabel *Label59;
   TCheckBox *CV37b6;
   TCheckBox *CV38b6;
   TCheckBox *CV39b6;
   TCheckBox *CV40b6;
   TCheckBox *CV41b3;
   TCheckBox *CV42b3;
   TCheckBox *CV43b3;
   TCheckBox *CV44b3;
   TCheckBox *CV45b3;
   TCheckBox *CV46b3;
   TPanel *pA5;
   TLabel *Label60;
   TCheckBox *CV33b6;
   TCheckBox *CV34b6;
   TCheckBox *CV35b6;
   TCheckBox *CV36b6;
   TCheckBox *CV37b3;
   TCheckBox *CV38b3;
   TCheckBox *CV39b3;
   TCheckBox *CV40b3;
   TCheckBox *CV41b0;
   TCheckBox *CV42b0;
   TCheckBox *CV43b0;
   TCheckBox *CV44b0;
   TCheckBox *CV45b0;
   TCheckBox *CV46b0;
   TPanel *pA6;
   TLabel *Label61;
   TCheckBox *CV33b7;
   TCheckBox *CV34b7;
   TCheckBox *CV35b7;
   TCheckBox *CV36b7;
   TCheckBox *CV37b4;
   TCheckBox *CV38b4;
   TCheckBox *CV39b4;
   TCheckBox *CV40b4;
   TCheckBox *CV41b1;
   TCheckBox *CV42b1;
   TCheckBox *CV43b1;
   TCheckBox *CV44b1;
   TCheckBox *CV45b1;
   TCheckBox *CV46b1;
   TPanel *pA3;
   TLabel *Label62;
   TCheckBox *CV33b4;
   TCheckBox *CV34b4;
   TCheckBox *CV35b4;
   TCheckBox *CV36b4;
   TCheckBox *CV37b1;
   TCheckBox *CV38b1;
   TCheckBox *CV39b1;
   TCheckBox *CV40b1;
   TPanel *pA4;
   TLabel *Label63;
   TCheckBox *CV33b5;
   TCheckBox *CV34b5;
   TCheckBox *CV35b5;
   TCheckBox *CV36b5;
   TCheckBox *CV37b2;
   TCheckBox *CV38b2;
   TCheckBox *CV39b2;
   TCheckBox *CV40b2;
   TPanel *pA1;
   TLabel *Label64;
   TCheckBox *CV33b2;
   TCheckBox *CV34b2;
   TCheckBox *CV35b2;
   TCheckBox *CV36b2;
   TPanel *pA2;
   TLabel *Label65;
   TCheckBox *CV33b3;
   TCheckBox *CV34b3;
   TCheckBox *CV35b3;
   TCheckBox *CV36b3;
   TCheckBox *CV37b0;
   TCheckBox *CV38b0;
   TCheckBox *CV39b0;
   TCheckBox *CV40b0;
   TPanel *pALv;
   TLabel *Label66;
   TCheckBox *CV33b0;
   TCheckBox *CV34b0;
   TCheckBox *CV35b0;
   TCheckBox *CV36b0;
   TPanel *pALr;
   TLabel *Label67;
   TCheckBox *CV33b1;
   TCheckBox *CV34b1;
   TCheckBox *CV35b1;
   TCheckBox *CV36b1;
   TMainMenu *MainMenu;
   TMenuItem *mmFile;
   TMenuItem *mmNew;
   TMenuItem *mmLoad;
   TMenuItem *mmSave;
   TMenuItem *mmSaveAs;
   TMenuItem *mmExit;
   TMenuItem *mmSetup;
   TMenuItem *mmHelp;
   TComPort *ComPort1;
   TLabel *Label68;
   TLabel *Label69;
   TEdit *efCV33;
   TEdit *efCV34;
   TEdit *efCV35;
   TEdit *efCV36;
   TEdit *efCV37;
   TEdit *efCV38;
   TEdit *efCV39;
   TEdit *efCV40;
   TEdit *efCV41;
   TEdit *efCV42;
   TEdit *efCV43;
   TEdit *efCV44;
   TEdit *efCV45;
   TEdit *efCV46;
   TButton *pbDefaultFunctionMapping;
   TLabel *cv33ok;
   TLabel *cv34ok;
   TLabel *cv35ok;
   TLabel *cv36ok;
   TLabel *cv37ok;
   TLabel *cv38ok;
   TLabel *cv39ok;
   TLabel *cv40ok;
   TLabel *cv41ok;
   TLabel *cv42ok;
   TLabel *cv43ok;
   TLabel *cv44ok;
   TLabel *cv45ok;
   TLabel *cv46ok;
   TMenuItem *mmNewMini;
   TMenuItem *mmNewExtended;
   TMenuItem *mmNewAll;
   TLabel *lbDecoder;
   TLabel *lbCV65;
   TEdit *efCV65;
   TLabel *lbCV66;
   TEdit *efCV66;
   TLabel *lbCV95;
   TEdit *efCV95;
   TLabel *cv65ok;
   TLabel *cv66ok;
   TLabel *cv95ok;
   TGroupBox *gbSpeed;
   TEdit *efCV67;
   TLabel *cv67ok;
   TLabel *lbCV67;
   TLabel *cv68ok;
   TEdit *efCV68;
   TLabel *lbCV68;
   TLabel *cv69ok;
   TEdit *efCV69;
   TLabel *lbCV69;
   TLabel *cv70ok;
   TEdit *efCV70;
   TLabel *lbCV70;
   TLabel *cv71ok;
   TEdit *efCV71;
   TLabel *lbCV71;
   TLabel *cv72ok;
   TEdit *efCV72;
   TLabel *lbCV72;
   TLabel *cv73ok;
   TEdit *efCV73;
   TLabel *lbCV73;
   TLabel *cv80ok;
   TEdit *efCV80;
   TLabel *lbCV80;
   TLabel *cv74ok;
   TEdit *efCV74;
   TLabel *lbCV74;
   TLabel *cv75ok;
   TEdit *efCV75;
   TLabel *lbCV75;
   TLabel *cv76ok;
   TEdit *efCV76;
   TLabel *lbCV76;
   TLabel *cv77ok;
   TEdit *efCV77;
   TLabel *lbCV77;
   TLabel *cv78ok;
   TEdit *efCV78;
   TLabel *lbCV78;
   TLabel *cv79ok;
   TEdit *efCV79;
   TLabel *lbCV79;
   TLabel *cv87ok;
   TEdit *efCV87;
   TLabel *lbCV87;
   TLabel *cv81ok;
   TEdit *efCV81;
   TLabel *lbCV81;
   TLabel *cv82ok;
   TEdit *efCV82;
   TLabel *lbCV82;
   TLabel *cv83ok;
   TEdit *efCV83;
   TLabel *lbCV83;
   TLabel *cv84ok;
   TEdit *efCV84;
   TLabel *lbCV84;
   TLabel *cv85ok;
   TEdit *efCV85;
   TLabel *lbCV85;
   TLabel *cv86ok;
   TEdit *efCV86;
   TLabel *lbCV86;
   TLabel *cv94ok;
   TEdit *efCV94;
   TLabel *lbCV94;
   TLabel *cv88ok;
   TEdit *efCV88;
   TLabel *lbCV88;
   TLabel *cv89ok;
   TEdit *efCV89;
   TLabel *lbCV89;
   TLabel *cv90ok;
   TEdit *efCV90;
   TLabel *lbCV90;
   TLabel *cv91ok;
   TEdit *efCV91;
   TLabel *lbCV91;
   TLabel *cv92ok;
   TEdit *efCV92;
   TLabel *lbCV92;
   TLabel *cv93ok;
   TEdit *efCV93;
   TLabel *lbCV93;
   TRadioButton *rbDecimal;
   TRadioButton *rbBitmap;
   TEdit *efMoreCV;
   TLabel *lbDesc;
   TLabel *lbVal;
   TMenuItem *mmDecoder;
   TMenuItem *mmScan;
   TOpenDialog *odLoadFile;
   TSaveDialog *sdSaveAs;
   TMenuItem *mmChange;
   TMenuItem *mmAdd;
   TMenuItem *mmRemove;
   TMenuItem *mmAbout;
   TButton *pbCalculate;
   TButton *pbDelSpeedTable;
   TMenuItem *mmHelpInhalt;
   TMenuItem *mmHelpIndex;
   TLabel *reg1ok;
   TLabel *Label14;
   TEdit *efR1;
   TLabel *descR1;
   TLabel *lbReg;
   TLabel *lbRegVal;
   TLabel *lbRegDesc;
   TLabel *reg2ok;
   TLabel *Label20;
   TEdit *efR2;
   TLabel *descR2;
   TLabel *reg3ok;
   TLabel *Label23;
   TEdit *efR3;
   TLabel *descR3;
   TLabel *reg4ok;
   TLabel *Label26;
   TEdit *efR4;
   TLabel *descR4;
   TLabel *reg5ok;
   TLabel *Label29;
   TEdit *efR5;
   TLabel *descR5;
   TLabel *reg7ok;
   TLabel *Label35;
   TEdit *efR7;
   TLabel *descR7;
   TLabel *reg8ok;
   TLabel *Label38;
   TEdit *efR8;
   TLabel *descR8;
   TListBox *lbMoreCV;
   TCheckBox *cbBit0;
   TEdit *efBit0;
   TCheckBox *cbBit1;
   TEdit *efBit1;
   TCheckBox *cbBit2;
   TEdit *efBit2;
   TCheckBox *cbBit3;
   TEdit *efBit3;
   TCheckBox *cbBit4;
   TEdit *efBit4;
   TCheckBox *cbBit5;
   TEdit *efBit5;
   TCheckBox *cbBit6;
   TEdit *efBit6;
   TCheckBox *cbBit7;
   TEdit *efBit7;
   TEdit *memoMoreCV;
   TLabel *moreCVok;
   void __fastcall pbReadClick(TObject *Sender);
   void __fastcall pbVerifyClick(TObject *Sender);
   void __fastcall pbWriteClick(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall mmSetupClick(TObject *Sender);
   void __fastcall ComPort1RLSDChange(TObject *Sender, bool OnOff);
   void __fastcall ComPort1RxChar(TObject *Sender, int Count);
   void __fastcall updnCVClick(TObject *Sender, TUDBtnType Button);
   void __fastcall efCVChange(TObject *Sender);
   void __fastcall efCVvalChange(TObject *Sender);
   void __fastcall CVbitClick(TObject *Sender);
   void __fastcall tsBasisShow(TObject *Sender);
   void __fastcall tsSingleCVShow(TObject *Sender);
   void __fastcall setCV29bits(TObject *Sender);
   void __fastcall pbHardResetClick(TObject *Sender);
   void __fastcall mmExitClick(TObject *Sender);
   void __fastcall tsBasisHide(TObject *Sender);
   void __fastcall efCV19Change(TObject *Sender);
   void __fastcall verifyCVnum(TObject *Sender);
   void __fastcall verifyShortAddress(TObject *Sender);
   void __fastcall verifyLongAddress(TObject *Sender);
   void __fastcall verifyConsistAddress(TObject *Sender);
   void __fastcall verifyCommonVariable(TObject *Sender);
   void __fastcall mmNewClick(TObject *Sender);
   void __fastcall tsAllCVShow(TObject *Sender);
   void __fastcall pbDefaultFunctionMappingClick(TObject *Sender);
   void __fastcall FunctionMappingBitClick(TObject *Sender);
   void __fastcall tsFunctionHide(TObject *Sender);
   void __fastcall tsFunctionShow(TObject *Sender);
   void __fastcall tsAllCVHide(TObject *Sender);
   void __fastcall sg1_1024SelectCell(TObject *Sender, int ACol, int ARow,
          bool &CanSelect);
   void __fastcall mmScanClick(TObject *Sender);
   void __fastcall tsSpeedTabShow(TObject *Sender);
   void __fastcall tsSpeedTabHide(TObject *Sender);
   void __fastcall mmFileClick(TObject *Sender);
   void __fastcall mmLoadClick(TObject *Sender);
   void __fastcall mmSaveAsClick(TObject *Sender);
   void __fastcall mmChangeClick(TObject *Sender);
   void __fastcall mmAddClick(TObject *Sender);
   void __fastcall mmSaveClick(TObject *Sender);
   void __fastcall mmRemoveClick(TObject *Sender);
   void __fastcall mmAboutClick(TObject *Sender);
   void __fastcall pbCalculateClick(TObject *Sender);
   void __fastcall pbDelSpeedTableClick(TObject *Sender);
   void __fastcall mmHelpInhaltClick(TObject *Sender);
   void __fastcall mmHelpIndexClick(TObject *Sender);
   void __fastcall tsRegisterShow(TObject *Sender);
   void __fastcall tsRegisterHide(TObject *Sender);
   void __fastcall rbBitmapClick(TObject *Sender);
   void __fastcall rbDecimalClick(TObject *Sender);
   void __fastcall lbMoreCVClick(TObject *Sender);
   void __fastcall setBitmapVal(TObject *Sender);
   void __fastcall tsMoreShow(TObject *Sender);
   void __fastcall tsMoreHide(TObject *Sender);
   void __fastcall ComPort1DSRChange(TObject *Sender, bool OnOff);

private:	// Anwender-Deklarationen
   int iRetryCount;  // noch offene Wiederholungen bei Fehlern
   bool bCV29changed;
   bool bUseAll;
   int iLastSelectedCell;  // zuletzt selectierte Zelle der 1..1024-Seite
   int iActiveMoreCV;      // aktives CV aus der More-Seite
   void __fastcall loadSubMenu(String name);
   String __fastcall getSchemaFileName(String name);
   // Laden und Sichern der Ini-Datei
   void __fastcall loadIniFile(String fn);
   void __fastcall saveIniFile(String fn);
   void __fastcall addToIniFile(String section, String key, String value);
   // Log sichern
   void __fastcall saveLogFile(String fn);
   // Sichern der Decoder-Daten
   void __fastcall saveDecoderData(String fn, bool unconditional);
   void __fastcall getSingleCV();
   void __fastcall chkSingleCV();
   void __fastcall writeSingleCV();
   int __fastcall chkIntVal(TEdit *edit, int min, int max, bool quiet);
   int __fastcall testIntVal(String string, int min, int max, bool quiet);
   int  __fastcall readCVdirect(int CV);
   int  __fastcall readCVdirect_USB(int CV);
   int  __fastcall readCVpaged(int CV);
   int  __fastcall readRegister(int CV);
   void  __fastcall showCVval(int CV, int dest);
   void  __fastcall resetCVbits();
   void  __fastcall setCVbits(int val);
   void __fastcall lockButtons(TButton *button);
   void __fastcall unlockButtons();
   int  __fastcall getCVbits();
   int __fastcall setCV29();
   void __fastcall getCV29();
   void __fastcall loadBaseCVs(); // laden der Werte auf die erste Seite
   void __fastcall saveBaseCVs();
   void __fastcall resetBaseOKs();
   void __fastcall readBaseCVs();
   void __fastcall verifyBaseCVs();
   void __fastcall writeBaseCVs();
   void __fastcall makeCV1_1024Headers();
   void __fastcall hideRow(int row);
   void __fastcall readRP922();
//   void __fastcall calcFunctionMapping(int cv);
   void __fastcall setFunctionMappingBits(int cvaddr, int cvval);
   TObject * __fastcall getControlByName(String compName);
   void __fastcall enableEntryLabel(int cv);
   void __fastcall saveFunctionMapping();
   void __fastcall loadFunctionMapping();
   void __fastcall readFunctionMapping();
   void __fastcall verifyFunctionMapping();
   void __fastcall writeFunctionMapping();
   void __fastcall loadAllCV();
   void __fastcall saveAllCV();
   void __fastcall writeAllCV();
   void __fastcall verifyAllCV();
   void __fastcall readAllCV();
   void __fastcall writeSpeedTab();
   void __fastcall readSpeedTab();
   void __fastcall verifySpeedTab();
   void __fastcall loadSpeedTab();
   void __fastcall saveSpeedTab();
   void __fastcall loadRegister();
   void __fastcall saveRegister();
   void __fastcall loadMoreCV();
   void __fastcall saveMoreCV();
   void __fastcall readMoreCV();
   void __fastcall verifyMoreCV();
   void __fastcall writeMoreCV();
   void __fastcall enableBitmap(bool enabled);
   void __fastcall setBitmapBits(int cv);
   void __fastcall setBitmapText(int cv);
   void __fastcall clearBitmap();
   void __fastcall showMoreCV(int cv);
   void __fastcall storeMoreCV(int cv);
   void __fastcall readREGs();
   void __fastcall writeREGs();
   void __fastcall verifyREGs();
   void __fastcall storeCVs();
   void __fastcall restoreCVs();
   int __fastcall errMsg(String msg, int cv);
   int __fastcall errControl(int answer, int i);
   TStringList *ErrorList;    // LogListe

public:		// Anwender-Deklarationen
   int iMajorVersion;
   int iMinorVersion;
   int iBuild;
   String szAuthor;
   String szPath; // Pfad auf das Programm

   String activeDecoderFile;
   String profileName;
   TMemIniFile *pIniFile; // Ini-Datei des Programms
   bool cancelled;      // Abbruch-Taste wurde gedrueckt
   bool bButtonsLocked; // die Button wurden eingerastet
   String PR1Port;      // Anschluss fuer das Geraet
   bool PR1_NMRA_cps;    // true: Baudrate 17240, sonst 19200
   bool bDSRtrue;       // DSR wurde auf HI geschaltet
   bool bUSBserial;     // der COM-Anschluss ist ein USB-to-Serial-Adapter
                        // mit anderem Timing als ein 'echter' COM-Port

   // die folgende Variable wird fuer DDL/DDW gesetzt,
   // da hier ein _NICHT_Ring die Acks detectiert, sowie
   // eine Erkennung des Ger�tes und der Lok nicht
   // m�glich ist.
   bool bIsDDL;        // DDL- o. DDW-Server
   bool bProgTrack;    // Programmiergleis im DDL-Modus
   //----------Ende der DDL-Spezialitaeten-------------
   bool PR1Detected;   // PR1 angeschlossen
   bool AckDetected;   // Quittungsimpuls erkannt
   bool bDirectMode;   // direkter Bitmodus des Decoders
   bool bPageMode;     // Pagemodus des Decoders
   bool bSafeMode;     // Pr�fen nach Lesen und Schreiben
   bool bTest0Bit;     // Lesen des Bit: Pr�fe auf 0 und 1
   unsigned long iWait;     // Warteschleife bei schnellen Rechnern
   unsigned long iWaitXms;  // Warteschleife bei schnellen Rechnern
   bool bLog;               // Log der Ausgaben in eine Datei
   bool bExtendedPowerOn;   // Gedehntes PowerOn beim Handshake
   int iRetryOnError;       // Wiederholungs-Anzahl beim Lesen/Pr�fen
   TStringList *LogList;    // LogListe

   TTabSheet *tsActiveTabSheet; // aktives Tabsheet;
   int CVs[1024];                // Tabelle der CVs
   TStringList *bitmapCVs[1024]; // Tabelle der Bitmap-Beschreibungen
   int storedCVs[1024];          // w�hrend der Aktionen gesicherte CVs
   bool usedCVs[1024];           // Liste der benutzten CVs

   __fastcall TmainForm(TComponent* Owner);
   void __fastcall connectPort(String port); // stellt die Verbindung her
   void __fastcall closePort();     // beendet die Verbindung
   void __fastcall AppTerminate(String error); // beendet die Application
   String __fastcall readManufacturer(int number); // lesen der Hersteller
   // entfernt einen Eintrag aus dem Menue 'Neu'
   void __fastcall removeFromIniFile(String section, String key);
   void __fastcall addLog(unsigned long ulTime, String sLog);
   void __fastcall exitTabSheet(TTabSheet *ts); //Seite verlassen
   void __fastcall enterTabSheet(TTabSheet *ts); // Seite �ffnen
   bool __fastcall getCV(int CVaddr);  // CV lesen
   bool __fastcall setCV(int CVaddr, int CVval); // CV schreiben
   bool __fastcall verifyCV(int CVaddr, int CVval); // CV pruefen
   bool __fastcall getREG(int REGaddr);  // REG lesen
   bool __fastcall setREG(int REGaddr, int REGval); // REG schreiben
   bool __fastcall verifyREG(int REGaddr, int REGval); // REG pruefen
   void __fastcall clearCVs();   // Tabelle der CVs initialisieren
   void __fastcall setUsedCVs(String caption); // benutzte CVs einstellen
   void __fastcall setUsedCVsFromFile(String filename);
                                 // benutzte CVs aus Datei lesen

   // Texte f�r die Anzeigen
   String sz_ProgDev;
   String sz_noProgDev;
   String sz_Loco;
   String sz_noLoco;
   String sz_ProgTrk;
   String sz_noProgTrk;
   String sz_wait;
   String sz_Simple;
   String sz_All;
   String sz_Mini;
   String sz_Add;
   String sz_mmEntryName;
   String sz_Cancel;
   String sz_Read;
   String sz_Write;
   String sz_Verify;
   String sz_unknown;
   String sz_HardErr;
   String sz_Error;
   String sz_save;
   String sz_noPort;
   String sz_IniWrErr;
   String sz_WrDecErr;
   String sz_WrLogErr;
   String sz_File;
   String sz_noPortAccess;
   String sz_OutOfMem;
   String sz_BitmapDesc;
   String sz_InputValFormat;
   String sz_Numeric;
   String sz_Success;
   String sz_FactoryReset;
   String sz_Confirm;
   String sz_Wrong;
   String sz_Correct;
   String sz_NACK;
   String sz_Fail;
   String sz_Value;
   String sz_Description;
   
   void __fastcall setTextRessources(String lang);
   void __fastcall loadLangFile(String fn);
   void __fastcall loadGermanStrings();
   void __fastcall loadGermanCaptions(String form);
   void __fastcall loadInternationalCaptions(TMemIniFile *pF);
   void __fastcall loadCaptions(TMemIniFile *pF, TForm *form);
   void __fastcall loadFormCaptions(String lang, TForm *form);

   String szLanguage;
   TStringList *languages;
};
//---------------------------------------------------------------------------
extern PACKAGE TmainForm *mainForm;
//---------------------------------------------------------------------------
#endif
