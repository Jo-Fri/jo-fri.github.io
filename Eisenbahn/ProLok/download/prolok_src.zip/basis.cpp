//===========================================================================

//Seite tsBasis
void __fastcall TmainForm::tsBasisShow(TObject *Sender)
{
   enterTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::tsBasisHide(TObject *Sender)
{  // Blatt 'Basis' verlassen, Daten in Tabelle eintragen,
   // aber nicht in den Decoder speichern
   exitTabSheet((TTabSheet *)Sender);
   bCV29changed = false;
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::resetBaseOKs() {
// Ruecksetzen der OK-Anzeige nach dem Schreiben
   cv1ok->Visible = false;
   cv2ok->Visible = false;
   cv5ok->Visible = false;
   cv6ok->Visible = false;
   cv3ok->Visible = false;
   cv4ok->Visible = false;
   cv17_18ok->Visible = false;
   cv9ok->Visible = false;
   cv19ok->Visible = false;
   cv29ok->Visible = false;
   cv105ok->Visible = false;
   cv106ok->Visible = false;
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::loadBaseCVs() {
  // Blatt 'Basis' initialisieren
   int cvs[] = {1, 2, 5, 6, 3, 4, 9, 19, 105, 106};
   int i;
   bCV29changed = false;
   for(i=0;i<sizeof(cvs)/sizeof(cvs[0]);++i) {
      enableEntryLabel(*(cvs+i));
   }
   if(usedCVs[16]) { // CV17+18
      efCV17_18->Enabled = true;
      efCV17_18->Color = clWindow;
      lbCV17_18->Enabled = true;
   }
   else {
      efCV17_18->Enabled = false;
      efCV17_18->Color = clGrayText;
      lbCV17_18->Enabled = false;
   }

   if(usedCVs[18]) { // CV19
      efCV19->Enabled = true;
      efCV19->Color = clWindow;
      lbCV19->Enabled = true;
      CV19b7->Enabled = true;
   }
   else {
      efCV19->Enabled = false;
      efCV19->Color = clGrayText;
      lbCV19->Enabled = false;
      CV19b7->Enabled = false;
   }

   if(usedCVs[28]) //CV29
      gbCV29->Enabled = true;
   else
      gbCV29->Enabled = false;

// Eintragung der Werte auf der Seite Basis vornehmen
   efCV1->Text = CVs[0]==-1? (String)"" : IntToStr(CVs[0]);
   efCV2->Text = CVs[1]==-1? (String)"" : IntToStr(CVs[1]);
   efCV5->Text = CVs[4]==-1? (String)"" : IntToStr(CVs[4]);
   efCV6->Text = CVs[5]==-1? (String)"" : IntToStr(CVs[5]);
   efCV3->Text = CVs[2]==-1? (String)"" : IntToStr(CVs[2]);
   efCV4->Text = CVs[3]==-1? (String)"" : IntToStr(CVs[3]);
   efCV17_18->Text = CVs[16]==-1 && CVs[17]==-1?
                  (String)"" : IntToStr((CVs[16]& 0x3f) * 256 + CVs[17]);
   efCV9->Text = CVs[8]==-1? (String)"" : IntToStr(CVs[8]);
   efCV8->Text = CVs[7]==-1? (String)"" : readManufacturer(CVs[7]);
   efCV7->Text = CVs[6]==-1? (String)"" : IntToStr(CVs[6]);
   efCV19->Text = CVs[18]==-1? (String)"" : IntToStr(CVs[18] & 127);
   CV19b7->Checked = CVs[18]==-1? false : (bool)(CVs[18] & 128);
   efCV105->Text = CVs[104]==-1? (String)"" : IntToStr(CVs[104]);
   efCV106->Text = CVs[105]==-1? (String)"" : IntToStr(CVs[105]);
   getCV29();
   resetBaseOKs();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::saveBaseCVs() {
// Werte aus der Seite Basis in die CV-Tabelle eintragen
   int cvs[]= {1,2,5,6,3,4,17,18,9,19,105,106,29};
   int x, l=sizeof(cvs)/sizeof(cvs[0]);
   if(-1 != (x=chkIntVal(efCV1, 1, 127, true)))
      if(x>0) CVs[0] = x;
   if(-1 != (x=chkIntVal(efCV2,0,255, true)))
      CVs[1] = x;
   if(-1 != (x=chkIntVal(efCV5,0,255, true)))
      CVs[4] = x;
   if(-1 != (x=chkIntVal(efCV6,0,255, true)))
      CVs[5] = x;
   if(-1 != (x=chkIntVal(efCV3,0,255, true)))
      CVs[2] = x;
   if(-1 != (x=chkIntVal(efCV4,0,255, true)))
      CVs[3] = x;
   if(-1 != (x=chkIntVal(efCV17_18,0,10239,true))) {
      if(x==0) {
         CVs[16] = 0;  // MSB
         CVs[17] = 0;  // LSB
      }
      else {
         if(-1 != (x=chkIntVal(efCV17_18,128,10239, true))) {
            CVs[16] = (x / 256)|0xc0;  // MSB
            CVs[17] = x % 256;         // LSB
         }
      }
   }
   if(-1 != (x=chkIntVal(efCV9,0,255, true)))
      CVs[8] = x;
   if(-1 != (x=chkIntVal(efCV19,0,127, true)))
      CVs[18] = x;
   if(CV19b7->Checked)
      CVs[18] |= 128;
   if(-1 != (x=chkIntVal(efCV105,0,255, true)))
      CVs[104] = x;
   if(-1 != (x=chkIntVal(efCV106,0,255, true)))
      CVs[105] = x;
   if(-1 != (x = setCV29()))
      CVs[28] = x;
   for(x=0;x<l;x++)
      sg1_1024->Cells[2][*(cvs+x)] = IntToStr(CVs[*(cvs+x)-1]);
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::getCV29() {
// CV29 aus den Bits berechnen und eintragen
   if(CVs[28]!=-1) {
      efCV29->Text = IntToStr(CVs[28]);
      CV29b0->Checked = (CVs[28] & 1);
      CV29b1->Checked = (CVs[28] & 2);
      CV29b2->Checked = (CVs[28] & 4);
      CV29b3->Checked = (CVs[28] & 8);
      CV29b4->Checked = (CVs[28] & 16);
      CV29b5->Checked = (CVs[28] & 32);
      CV29b6->Checked = (CVs[28] & 64);
      CV29b7->Checked = (CVs[28] & 128);
   }
   else {
      CV29b0->Checked = false;
      CV29b1->Checked = false;
      CV29b2->Checked = false;
      CV29b3->Checked = false;
      CV29b4->Checked = false;
      CV29b5->Checked = false;
      CV29b6->Checked = false;
      CV29b7->Checked = false;
      efCV29->Text = "";
   }
}

//---------------------------------------------------------------------------

int __fastcall TmainForm::setCV29() {
// CV 29 Bits berechnen und eintragen
   int CV29 = 0;
   if(bCV29changed) {
      CV29 |= CV29b0->Checked? 1 : 0;
      CV29 |= CV29b1->Checked? 2 : 0;
      CV29 |= CV29b2->Checked? 4 : 0;
      CV29 |= CV29b3->Checked? 8 : 0;
      CV29 |= CV29b4->Checked? 16 : 0;
      CV29 |= CV29b5->Checked? 32 : 0;
      CV29 |= CV29b6->Checked? 64 : 0;
      CV29 |= CV29b7->Checked? 128 : 0;
      efCV29->Text = IntToStr(CV29);
      return CV29;
   }
   return -1;
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::readBaseCVs() {
   // Basis-CVs auslesen: Nr. in cvs[]
   // bei Erfolg wird der OK-Status angezeigt, sonst nichts
   int cvs[] = {8, 7, 1, 2, 5, 6, 3, 4, 17, 18, 9, 19, 29, 105, 106};
   TEdit * edits[] = {efCV8,efCV7,efCV1,efCV2,efCV5,efCV6,efCV3,efCV4,
                      efCV17_18,efCV9,efCV19,efCV29,efCV105,efCV106};
   int i, cv, l, a;
   bool cv17;
   resetBaseOKs();
   cancelled = false;
   l=sizeof(edits)/sizeof(edits[0]);
   for(i=0;i<l;i++) edits[i]->Text="";
   CV29b0->Checked = false;
   CV29b1->Checked = false;
   CV29b2->Checked = false;
   CV29b3->Checked = false;
   CV29b4->Checked = false;
   CV29b5->Checked = false;
   CV29b6->Checked = false;
   CV29b7->Checked = false;
   CV19b7->Checked = false;

   i = 0;
   l=sizeof(cvs)/sizeof(cvs[0]);

   while(i<l && !cancelled) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[*(cvs+i)-1] || *(cvs+i)==7 || *(cvs+i)==8) {
         if(getCV(*(cvs+i))) {
            switch(*(cvs+i)) {
               case 1: cv1ok->Visible = true;
                       efCV1->Text = IntToStr(CVs[0]);
                       break;
               case 2: cv2ok->Visible = true;
                       efCV2->Text = IntToStr(CVs[1]);
                       break;
               case 5: cv5ok->Visible = true;
                       efCV5->Text = IntToStr(CVs[4]);
                       break;
               case 6: cv6ok->Visible = true;
                       efCV6->Text = IntToStr(CVs[5]);
                       break;
               case 3: cv3ok->Visible = true;
                       efCV3->Text = IntToStr(CVs[2]);
                       break;
               case 4: cv4ok->Visible = true;
                       efCV4->Text = IntToStr(CVs[3]);
                       break;
               case 17: cv17 = true;
                       break;
               case 18: if(cv17) {
                           cv17_18ok->Visible = true;
                           efCV17_18->Text = IntToStr((CVs[16]& 0x3f) * 256 + CVs[17]);
                       }
                       break;
               case 9: cv9ok->Visible = true;
                       efCV9->Text = IntToStr(CVs[8]);
                       break;
               case 8: efCV8->Text = readManufacturer(CVs[7]);
                       break;
               case 7: efCV7->Text = IntToStr(CVs[6]);
                       break;
               case 19: cv19ok->Visible = true;
                       efCV19->Text = IntToStr(CVs[18] & 127);
                       CV19b7->Checked = (CVs[18] & 128);
                       break;
               case 29:getCV29();
                       cv29ok->Visible = true;
                       break;
               case 105: cv105ok->Visible = true;
                       efCV105->Text = IntToStr(CVs[104]);
                       break;
               case 106: cv106ok->Visible = true;
                       efCV106->Text = IntToStr(CVs[105]);
                       break;
            }
         }
         else
            a=errMsg("Lesen", *(cvs+i));
      }
      i=errControl(a,i);
   }
//   if(cancelled) loadBaseCVs();
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::writeBaseCVs() {
   // Basis-CVs schreiben: Nr. in cvs[]
   // bei Erfolg wird der OK-Status angezeigt, sonst nichts
   // nur wenn CVs[] != -1 wird geschrieben
   int cvs[] = {1, 2, 5, 6, 3, 4, 17, 18, 9, 19, 29, 105, 106};
   int i, a;
   bool cv17;
   resetBaseOKs();
   saveBaseCVs();
   i = 0;
   while(i<sizeof(cvs)/sizeof(cvs[0]) && !cancelled) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[*(cvs+i)-1]) {
         if(setCV(*(cvs+i), CVs[*(cvs+i)-1])) {
            switch(*(cvs+i)) {
               case 1: cv1ok->Visible = true;
                       break;
               case 2: cv2ok->Visible = true;
                       break;
               case 5: cv5ok->Visible = true;
                       break;
               case 6: cv6ok->Visible = true;
                       break;
               case 3: cv3ok->Visible = true;
                       break;
               case 4: cv4ok->Visible = true;
                       break;
               case 17: cv17 = true;
                       break;
               case 18: if(cv17) cv17_18ok->Visible = true;
                       break;
               case 9: cv9ok->Visible = true;
                       break;
               case 19: cv19ok->Visible = true;
                       break;
               case 29: cv29ok->Visible = true;
                       break;
               case 105: cv105ok->Visible = true;
                       break;
               case 106: cv106ok->Visible = true;
                       break;
            }
         }
         else
            a=errMsg("Schreiben", *(cvs+i));
      }
      i=errControl(a,i);
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyBaseCVs() {
   // Basis-CVs schreiben: Nr. in cvs[]
   // bei Erfolg wird der OK-Status angezeigt, sonst nichts
   // nur wenn CVs[] != -1 wird geschrieben
   int cvs[] = {1, 2, 5, 6, 3, 4, 17, 18, 9, 19, 29, 105, 106};
   int i,a;
   bool cv17;
   resetBaseOKs();
   saveBaseCVs();
   i = 0;
   while(i<sizeof(cvs)/sizeof(cvs[0]) && !cancelled) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[*(cvs+i)-1]) {
         if(verifyCV(*(cvs+i), CVs[*(cvs+i)-1])) {
            switch(*(cvs+i)) {
               case 1: cv1ok->Visible = true;
                       break;
               case 2: cv2ok->Visible = true;
                       break;
               case 5: cv5ok->Visible = true;
                       break;
               case 6: cv6ok->Visible = true;
                       break;
               case 3: cv3ok->Visible = true;
                       break;
               case 4: cv4ok->Visible = true;
                       break;
               case 17: cv17 = true;
                       break;
               case 18: if(cv17) cv17_18ok->Visible = true;
                       break;
               case 9: cv9ok->Visible = true;
                       break;
               case 19: cv19ok->Visible = true;
                       break;
               case 29: cv29ok->Visible = true;
                       break;
               case 105: cv105ok->Visible = true;
                       break;
               case 106: cv106ok->Visible = true;
                       break;
            }
         }
         else
            a=errMsg("Pr�fen", *(cvs+i));
      }
      i=errControl(a,i);
   }
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::setCV29bits(TObject *Sender)
{  // Klick auf eines der CV29-Bits auswerten
   bCV29changed = true;
   setCV29();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::efCV19Change(TObject *Sender)
{
   int i;
   if((i=chkIntVal(efCV19,0,255,false))!=-1) {
      efCV19->Text = IntToStr(i & 127);
      CV19b7->Checked = (i & 128);
   }
}

//---------------------------------------------------------------------------
