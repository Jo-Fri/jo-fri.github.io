//---------------------------------------------------------------------------

#ifndef msgFormH
#define msgFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TmsgBox : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TLabel *lbMsg;
private:	// Anwender-Deklarationen
public:		// Anwender-Deklarationen
   __fastcall TmsgBox(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TmsgBox *msgBox;
//---------------------------------------------------------------------------
#endif
