/***************************************************************/
/* erddcd - Electric Railroad Direct Digital Command Daemon    */
/*    generates without any other hardware digital commands    */
/*    to control electric model railroads                      */
/*                                                             */
/* original file: nmra.c                                       */
/* job : implements routines to compute data for the           */
/*       NMRA-DCC protocol and send this data to               */
/*       the serial device.                                    */
/*                                                             */
/* Torsten Vogt, may 1999                                      */
/* vogt@vogt-it.com                                            */
/*                                                             */
/*																			      */
/* Gek�rzt durch Th. Borrmann, thomas@borrmanns.de 	   	 	*/
/* da nur die �bersetzungstabellen gebraucht werden            */									 
/***************************************************************/

/**********************************************************************
 data format:

 look at the srcp specification

 protocol formats:

 service mode instruction packets for direct mode
 (verify cv, write cv, cv bit manipulation)
 (implemented)

 service mode instruction packets for adress-only mode
 (verify address contents, write address contents)
 (NOT implemented)

 service mode instruction packets for physical register addressing
 (verify register contents, write register contents)
 (implemented)

 service mode instruction packets paged cv addressing
 (verify/write register/cv contents)
 (NOT implemented)

 general notes:

   configuration of the serial port:

      startbit: 1
      stopbit : 1
      databits: 8
      baudrate: 19200

      ==> one serial bit takes 52.08 usec.

      ==> NMRA-0-Bit: 01         (52 usec low and 52 usec high)
          NMRA-1-Bit: 0011       (at least 100 usec low and high)

--------------------------------------------------------
ANM.:  richtig ist
      ==> NMRA-1-Bit: 01         (52 usec low and 52 usec high)
          NMRA-0-Bit: 0011       (at least 100 usec low and high)
(Th. Borrmann)
--------------------------------------------------------

      serial stream (only start/stop bits):

      0_______10_______10_______10_______10_______10_______10___ ...

      problem: how to place the NMRA-0- and NMRA-1-Bits in the serial stream

      examples:

      0          0xF0     _____-----
      00         0xC6     __--___---
      01         0x78     ____----_-
      10         0xE1     _-____----
      001        0x66     __--__--_-
      010        0x96     __--_-__--
      011        0x5C     ___---_-_-
      100        0x99     _-__--__--
      101        0x71     _-___---_-
      110        0xC5     _-_-___---
      0111       0x56     __--_-_-_-
      1011       0x59     _-__--_-_-
      1101       0x65     _-_-__--_-
      1110       0x95     _-_-_-__--
      11111      0x55     _-_-_-_-_-
                          ^        ^
                          start-   stop-
                          bit      bit

   known bugs (of version 1 of the nmra dcc translation routine):
   (i hope version 2 don't have these bugs ;-) )

      following packets are not translateable:

        N1 031 1 06 0 0 0 0 0
        N1 047 0 07 0 0 0 0 0

        N2 031 0 091 0 0 0 0 0
        N2 031 1 085 0 0 0 0 0
        N2 031 1 095 0 0 0 0 0
        N2 047 0 107 0 0 0 0 0
        N2 047 1 103 0 0 0 0 0
        N2 047 1 111 0 0 0 0 0
        N2 048 1 112 0 0 0 0 0
        N2 051 1 115 0 0 0 0 0
        N2 053 1 117 0 0 0 0 0
        N2 056 0 124 0 0 0 0 0
        N2 057 1 113 0 0 0 0 0
        N2 058 1 114 0 0 0 0 0
        N2 059 1 115 0 0 0 0 0
        N2 060 1 116 0 0 0 0 0
        N2 061 1 117 0 0 0 0 0 
        N2 062 1 118 0 0 0 0 0

     I think, that these are not really problems. The only consequence is
     e.g. that some addresses has 127 speed steps instead of 128. Thats
     life, don't worry. 

****************************************************************/
//---------------------------------------------------------------------------
#define ll          0xf0
#define lLl         0xcc
#define lHl         0xe8
#define lHLl        0x9a
#define lLHl        0xa6
#define lHHl        0xd4
#define lHHHl       0xaa
#define lh          0x00
#define lLh         0x1c
#define lHh         0x40
#define lLHh        0x4c
#define lHLh        0x34
#define lHHh        0x50
#define lHHHh       0x54
#define hLh         0x0f
#define hHLh        0x1d
#define hLHh        0x47
#define hHHLh       0x35
#define hHLHh       0x4d
#define hLHHh       0x53
#define hHHHHh      0x55
#define hl          0xff
#define hLl         0xc7
#define hHl         0xfd
#define hHLl        0xcd
#define hLHl        0xD3
#define hHHl        0xF5
#define hHHHl       0xd5



#include <vcl.h>
#pragma hdrstop

#include "nmra.h"
#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)

typedef struct {
   int  value;
   int  patternlength;
} tTranslateData_v3;

static const tTranslateData_v3 TranslateData_v3[32][2] = {
    {{ lLl   , 2  },{ ll   , 1  }},
    {{ lLl   , 2  },{ ll   , 1  }},
    {{ lLl   , 2  },{ ll   , 1  }},
    {{ lLl   , 2  },{ ll   , 1  }},
    {{ lLHl  , 3  },{ lLh  , 2  }},
    {{ lLHl  , 3  },{ lLh  , 2  }},
    {{ lLHh  , 3  },{ lLh  , 2  }},
    {{ lLHh  , 3  },{ lLh  , 2  }},
    {{ lHLl  , 3  },{ lHl  , 2  }},
    {{ lHLl  , 3  },{ lHl  , 2  }},
    {{ lHLh  , 3  },{ lHl  , 2  }},
    {{ lHLh  , 3  },{ lHl  , 2  }},
    {{ lHHl  , 3  },{ lHh  , 2  }},
    {{ lHHl  , 3  },{ lHh  , 2  }},
    {{ lHHh  , 3  },{ lHh  , 2  }},
    {{ lHHHh , 4  },{ lHHh , 3  }},
    {{ hLl   , 2  },{ hl   , 1  }},
    {{ hLl   , 2  },{ hl   , 1  }},
    {{ hLl   , 2  },{ hl   , 1  }},
    {{ hLl   , 2  },{ hl   , 1  }},
    {{ hLHl  , 3  },{ hLh  , 2  }},
    {{ hLHl  , 3  },{ hLh  , 2  }},
    {{ hLHh  , 3  },{ hLh  , 2  }},
    {{ hLHHh , 4  },{ hLHh , 3  }},
    {{ hHLl  , 3  },{ hHl  , 2  }},
    {{ hHLl  , 3  },{ hHl  , 2  }},
    {{ hHLh  , 3  },{ hHl  , 2  }},
    {{ hHLHh , 4  },{ hHLh , 3  }},
    {{ hHHl  , 3  },{ hHHl , 3  }},
    {{ hHHLh , 4  },{ hHHl , 3  }},
    {{ hHHHl , 4  },{ hHHHl, 4  }},
    {{ hHHHHh, 5  },{ hHHHHh, 5 }}
};


static char *preamble = "111111111111111";
static const int STACKSIZE  = 200;
static const int BUFFERSIZE = 200;

//------------------------------------------------------------------------------

int read_next_six_bits(char *Bitstream) {
   int i, bits = 0;
   for (i = 0; i < 6; i++)
      bits = (bits << 1) | (*Bitstream++ == '0' ? 0 : 1);
   return bits;
}
//------------------------------------------------------------------------------

int translateBitstream2Packetstream(char *Bitstream, char *Packetstream) {

   /* this routine assumes, that any Bitstream starts with a 1 Bit. */
   /* This could be changed, if necessary */

   char Buffer[BUFFERSIZE+20];  /* keep room for additional pre and postamble */
   char *read_ptr; //= Buffer+1;   /* here the real sequence starts */

   char *restart_read = Buffer; /* one more 1 in the beginning for successful restart */

   char *buf_end;

   int  restart_packet = 0;
   int  generate_packet = 0;

   bool  second_try = false;
   int  act_six;

   read_ptr = strcpy (Buffer, "11");

   /* one bit, because we start with a half-bit, so we have to put in the left half */
   /* one bit, to be able, to back up one bit, if we run into a 111110 pattern */

   strncat (Buffer, Bitstream, BUFFERSIZE-1);

   buf_end = Buffer + strlen (Buffer);  /* for simply testing, whether our job is done */

   strcat (Buffer, "111111");

   /* at most six trailing bits are possibly necessary */

   memset(Packetstream, 0, PKTSIZE);

   while (generate_packet < PKTSIZE && read_ptr < buf_end) {
      act_six = read_next_six_bits (read_ptr);
      if (act_six == 0x3e /* 111110*/){/*did we reach an untranslateble value */
          /* try again from last position, where a shorter translation */
          /* could be choosen                                          */
          second_try = true;
          generate_packet = restart_packet;
          read_ptr = restart_read;
          act_six = read_next_six_bits (read_ptr);
      }

      Packetstream[generate_packet] = TranslateData_v3[act_six >> 1][second_try ? 1 : 0]. value;

      if (act_six < 0x3e /* 111110*/) { /* is translation fixed upto here ? */
         restart_packet = generate_packet;
         restart_read = read_ptr;
      }
      read_ptr += TranslateData_v3[act_six >> 1][second_try ? 1 : 0]. patternlength;
      generate_packet ++;
      second_try = false;
   }

   return generate_packet;             /* return nr of bytes in packetstream */
}


//----------------------------------------------------------------------------

