//=========Formular tsMore================
void __fastcall TmainForm::tsMoreShow(TObject *Sender)
{
   enterTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::tsMoreHide(TObject *Sender)
{
   exitTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------

// CV ausw�hlen
void __fastcall TmainForm::lbMoreCVClick(TObject *Sender)
{
   int cv,index = lbMoreCV->ItemIndex;
   moreCVok->Visible = false;
   if(iActiveMoreCV!=0)
      storeMoreCV(iActiveMoreCV);
   clearBitmap();
   if(index!=-1) {
      cv=StrToInt(lbMoreCV->Items->Strings[index]);
      showMoreCV(cv);
      iActiveMoreCV=cv;
   }
}

//---------------------------------------------------------------------------
// soll kein Bitmap sein
void __fastcall TmainForm::rbDecimalClick(TObject *Sender)
{
   int cv=0,index = lbMoreCV->ItemIndex;
   if(index!=-1) {
      cv=StrToInt(lbMoreCV->Items->Strings[index]);
      if(bitmapCVs[cv-1]!=NULL) {
         if(Application->MessageBox(
            ("Wollen Sie die Bit-Aufteilung der CV " + IntToStr(cv) +
            " aufheben?").c_str(), "Best�tigung", MB_YESNO)==ID_YES) {
            delete bitmapCVs[cv-1];
            bitmapCVs[cv-1]=NULL;
         }
      }
   }
   efMoreCV->TabStop=true;
   efMoreCV->ReadOnly=false;
   enableBitmap(false);
   clearBitmap();
   if(cv!=0) efMoreCV->Text=IntToStr(CVs[cv-1]);
}

//---------------------------------------------------------------------------
// soll Bitmap werden
void __fastcall TmainForm::rbBitmapClick(TObject *Sender)
{
   int index = lbMoreCV->ItemIndex;
   if(index!=-1) {
      enableBitmap(true);
      setBitmapBits(StrToInt(lbMoreCV->Items->Strings[index]));
      efMoreCV->TabStop=false;
      efMoreCV->ReadOnly=true;
   }
   else {
      rbBitmap->Checked=false;
      efMoreCV->TabStop=true;
      efMoreCV->ReadOnly=false;
   }
}
//---------------------------------------------------------------------------
// die zuletzt aktive CV noch in die Tabellen schreiben
void __fastcall TmainForm::saveMoreCV() {
   if(iActiveMoreCV!=0)
      storeMoreCV(iActiveMoreCV);
}

//--------------------------------------------
void __fastcall TmainForm::loadMoreCV() {
   int cvgroups[][2] = {{10,16},{20,28},{30,32},{47,64},
                        {96,104},{107,1024}};
   int first,i,a,e,len = sizeof(cvgroups)/sizeof(cvgroups[0]);
   moreCVok->Visible = false;
   lbMoreCV->Clear();
   first=0;
   for(i=0;i<len;i++) {
      e=cvgroups[i][1];
      for(a=(cvgroups[i][0]);a<=e;a++) {
         if (usedCVs[a-1]) {
            if (first==0) first=a;
            lbMoreCV->Items->Add(IntToStr(a));
         }
      }
   }
   iActiveMoreCV=first;
   if(first==0) { // keine 'moreCVs'
      enableBitmap(false);
      lbMoreCV->Enabled=false;
      memoMoreCV->Enabled=false;
      rbDecimal->Enabled=false;
      rbBitmap->Enabled=false;
      efMoreCV->Enabled=false;
   }
   else {
      lbMoreCV->ItemIndex=0;
      lbMoreCV->Enabled=true;
      memoMoreCV->Enabled=true;
      rbDecimal->Enabled=true;
      rbBitmap->Enabled=true;
      efMoreCV->Enabled=true;
      showMoreCV(first);
   }
}
//--------------------------------------------
// Anzeigen einer CV auf der More-Seite
void __fastcall TmainForm::showMoreCV(int cv) {
   efMoreCV->Text=CVs[cv-1]==-1?(String)"":IntToStr(CVs[cv-1]);
   memoMoreCV->Text=sg1_1024->Cells[1][cv];
   if(bitmapCVs[cv-1]==NULL) { // normales CV
      rbBitmap->Checked=false;
      rbDecimal->Checked=true;
      efMoreCV->TabStop=true;
      efMoreCV->ReadOnly=false;
   }
   else {
      rbBitmap->Checked=true;
      rbDecimal->Checked=false;
      efMoreCV->TabStop=false;
      efMoreCV->ReadOnly=true;
      setBitmapBits(cv);
      setBitmapText(cv);
   }
}

//--------------------------------------------
// speichern der CV in die CV-Tabellen
void __fastcall TmainForm::storeMoreCV(int cv) {
   TEdit *edits[] = {efBit0,efBit1,efBit2,efBit3,
                     efBit4,efBit5,efBit6,efBit7};
   int i,len=sizeof(edits)/sizeof(edits[0]);
   int val=chkIntVal(efMoreCV,0,255,false);

   if(val!=-1) {
      CVs[cv-1] = val;
      sg1_1024->Cells[1][cv]=memoMoreCV->Text;
      if(rbBitmap->Checked==true) {  // Bitmap speichern
         if(bitmapCVs[cv-1]==NULL) { // noch nicht vorhanden
            try {
               bitmapCVs[cv-1]= new TStringList();
               bitmapCVs[cv-1]->QuoteChar='"';
               bitmapCVs[cv-1]->Delimiter='|';
               for(i=0;i<8;++i) bitmapCVs[cv-1]->Add("");
            }
            catch(Exception *E) {
               Application->MessageBox(
                  "Die Bitmap-Beschreibung konnte nicht gespeichert werden",
                  "Fehler", MB_OK);
            }
         }
         if(bitmapCVs[cv-1]!=NULL) { // vorhanden
            for(i=0;i<len;++i) {
               if(edits[i]->Text!="")
                  bitmapCVs[cv-1]->Strings[i] = StringReplace(edits[i]->Text,
                                                (String)"|",(String)" I ",
                                                TReplaceFlags()<<rfReplaceAll);
               else
                  bitmapCVs[cv-1]->Strings[i] = (String)"";
            }
         }
      }
   }
}

//--------------------------------------------
// Bitmap erlauben/sperren
void __fastcall TmainForm::enableBitmap(bool enabled) {
   TCheckBox *checkbox[] = {cbBit0,cbBit1,cbBit2,cbBit3,
                            cbBit4,cbBit5,cbBit6,cbBit7};
   TEdit *edits[] = {efBit0,efBit1,efBit2,efBit3,
                     efBit4,efBit5,efBit6,efBit7};
   int i,len=sizeof(checkbox)/sizeof(checkbox[0]);
   for(i=0;i<len;++i) {
      checkbox[i]->Enabled = enabled;
      edits[i]->TabStop = enabled;
      edits[i]->Enabled = enabled;
      edits[i]->ReadOnly = !enabled;
   }
}

//--------------------------------------------
// setzen der Bits
void __fastcall TmainForm::setBitmapBits(int cv) {
   TCheckBox *checkbox[] = {cbBit0,cbBit1,cbBit2,cbBit3,
                            cbBit4,cbBit5,cbBit6,cbBit7};
   int val,i,len=sizeof(checkbox)/sizeof(checkbox[0]);
   if((val=CVs[cv-1])!=-1) {
      for(i=0;i<len;++i)
         checkbox[i]->Checked = (val & (1<<i))>0?true:false;
   }
}

//--------------------------------------------
// Wert aus Bits berechnen
void __fastcall TmainForm::setBitmapVal(TObject *Sender) {
   TCheckBox *x = (TCheckBox *)Sender;
   char *name = x->Name.c_str();
   unsigned int bit,val;
   sscanf(name,"cbBit%d",&bit);
   if(efMoreCV->Text=="")
      val = 0;
   else
      val = StrToInt(efMoreCV->Text);
   if(x->Checked)
      val |= (1<<bit);
   else
      val &= ~(1<<bit);
   efMoreCV->Text=IntToStr(val);
}

//--------------------------------------------
// setzen der Erkl�rung
void __fastcall TmainForm::setBitmapText(int cv) {
   TEdit *edits[] = {efBit0,efBit1,efBit2,efBit3,
                     efBit4,efBit5,efBit6,efBit7};
   int i,len=sizeof(edits)/sizeof(edits[0]);
   for(i=0;i<len;++i)
      edits[i]->Text = bitmapCVs[cv-1]->Strings[i];
}

//--------------------------------------------
void __fastcall TmainForm::clearBitmap() {
   TCheckBox *checkbox[] = {cbBit0,cbBit1,cbBit2,cbBit3,
                            cbBit4,cbBit5,cbBit6,cbBit7};
   TEdit *edits[] = {efBit0,efBit1,efBit2,efBit3,
                     efBit4,efBit5,efBit6,efBit7};
   int i,len=sizeof(edits)/sizeof(edits[0]);
   for(i=0;i<len;++i) {
      edits[i]->Text = "";
      checkbox[i]->Checked = false;
   }
}

//--------------------------------------------
// Lesen _aller_ MoreCV
void __fastcall TmainForm::readMoreCV() {
   int i,cv,answer,index=lbMoreCV->ItemIndex;
   moreCVok->Visible = false;
   i=0;
   while(i<lbMoreCV->Items->Count && !cancelled) {
      answer = 0;
      lbMoreCV->ItemIndex = i;
      cv = StrToInt(lbMoreCV->Items->Strings[i]);
      showMoreCV(cv);
      if(getCV(cv))
         showMoreCV(cv);
      else  {
         if(!cancelled) {
            efMoreCV->Text="";
            answer=errMsg("Lesen",cv);
         }
      }
      i=errControl(answer,i);
      Application->ProcessMessages();
   }
   lbMoreCV->ItemIndex = index;
   showMoreCV(StrToInt(lbMoreCV->Items->Strings[index]));
   Application->ProcessMessages();
}

//--------------------------------------------
// Pr�fen des aller_ MoreCV
void __fastcall TmainForm::verifyMoreCV() {
   int i,cv,answer,index=lbMoreCV->ItemIndex;
   moreCVok->Visible = false;
   if(iActiveMoreCV!=0)
      storeMoreCV(iActiveMoreCV);
   i=0;
   while(i<lbMoreCV->Items->Count && !cancelled) {
      answer=0;
      lbMoreCV->ItemIndex = i;
      cv = StrToInt(lbMoreCV->Items->Strings[i]);
      showMoreCV(cv);
      Application->ProcessMessages();
      if(verifyCV(cv,CVs[cv-1]))
         moreCVok->Visible = true;
      else  {
         if(!cancelled) {
           efMoreCV->Text="";
            answer=errMsg("Pr�fen",cv);
         }
      }
      i=errControl(answer,i);
   }
   lbMoreCV->ItemIndex = index;
   showMoreCV(StrToInt(lbMoreCV->Items->Strings[index]));
   moreCVok->Visible = false;
   Application->ProcessMessages();
}

//--------------------------------------------
// Schreiben _aller_ MoreCV
void __fastcall TmainForm::writeMoreCV() {
   int i,cv,answer,index=lbMoreCV->ItemIndex;
   moreCVok->Visible = false;
   if(iActiveMoreCV!=0)
      storeMoreCV(iActiveMoreCV);
   i=0;
   while(i<lbMoreCV->Items->Count && !cancelled) {
      answer=0;
      cv = StrToInt(lbMoreCV->Items->Strings[i]);
      lbMoreCV->ItemIndex=i;
      showMoreCV(cv);
      Application->ProcessMessages();
      if(setCV(cv,CVs[cv-1]))
         moreCVok->Visible = true;
      else  {
         if(!cancelled) {
            efMoreCV->Text="";
            answer=errMsg("Schreiben",cv);
         }
      }
      i=errControl(answer,i);
   }
   lbMoreCV->ItemIndex = index;
   showMoreCV(StrToInt(lbMoreCV->Items->Strings[index]));
   moreCVok->Visible = false;
   Application->ProcessMessages();
}

