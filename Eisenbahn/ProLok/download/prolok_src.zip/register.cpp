void __fastcall TmainForm::tsRegisterShow(TObject *Sender)
{
   enterTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::tsRegisterHide(TObject *Sender)
{
   exitTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------

void __fastcall  TmainForm::loadRegister()
{  TEdit *edits[] = {efR1, efR2, efR3, efR4, efR5, efR7, efR8};
   TLabel *labels[] = {reg1ok, reg2ok, reg3ok, reg4ok,
                       reg5ok, reg7ok, reg8ok};
   int cvs[] = {1, 2, 3, 4, 29, 7, 8};
   int i,cv;
   int len = sizeof(edits)/sizeof(edits[0]);

   for(i=0;i<len;++i) {
      cv=*(cvs+i)-1;
      if(usedCVs[cv] || cv==6 || cv==7) {
         edits[i]->Text = CVs[cv]==-1?
                        (String)"":IntToStr(CVs[cv]);
         edits[i]->Color=clWindow;
         edits[i]->Enabled = true;
      }
      else {
         edits[i]->Text = "";
         edits[i]->Enabled = false;
         edits[i]->Color = clGrayText;
      }
      labels[i]->Visible = false;
   }
}

//---------------------------------------------------------------------------

void __fastcall  TmainForm::saveRegister()
{  TEdit *edits[] = {efR1, efR2, efR3, efR4, efR5, efR7, efR8};
   int cvs[] = {1, 2, 3, 4, 29, 7, 8};
   int cv,cvval,i;
   int len = sizeof(edits)/sizeof(edits[0]);
   if((cvval=testIntVal(efR1->Text, 1, 127, false))!=-1)
      CVs[0] = cvval;
   for(i=1;i<len;++i) {
      cv = *(cvs+i)-1;
      if(usedCVs[cv]) {
         if((cvval=testIntVal(edits[i]->Text, 0, 255, false))!=-1)
            CVs[cv] = cvval;
      }
   }
}

//---------------------------------------------------------------------------

void __fastcall  TmainForm::readREGs() {
   TLabel *labels[] = {reg1ok, reg2ok, reg3ok, reg4ok,
                       reg5ok, reg7ok, reg8ok};
   TEdit *edits[] = {efR1, efR2, efR3, efR4, efR5, efR7, efR8};
   int regs[] = {1,2,3,4,5,7,8};
   int cvs[] = {1, 2, 3, 4, 29, 7, 8};
   int cv,cvval,i,a;
   bool ok;
   int len = sizeof(labels)/sizeof(labels[0]);
   for(i=0;i<len;++i) {
      labels[i]->Visible = false;
      edits[i]->Text = "";
   }

   len = sizeof(edits)/sizeof(edits[0]);
   i=0;
   while(i<len && !cancelled) {
      a=0;
      cv = *(cvs+i)-1;
      if(usedCVs[cv] || cv==6 || cv==7) {
         labels[i]->Visible=getREG(*(regs+i));
         if(labels[i]->Visible)
            edits[i]->Text = CVs[cv];
         else   {
            edits[i]->Text = "";
            a=errMsg("Register Lesen",*(cvs+i));
         }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall  TmainForm::writeREGs() {
   TLabel *labels[] = {reg1ok, reg2ok, reg3ok, reg4ok,
                       reg5ok, reg7ok, reg8ok};
   TEdit *edits[] = {efR1, efR2, efR3, efR4, efR5};
   int cvs[] = {1, 2, 3, 4, 29};
   int cv,cvval,i,a;
   int len = sizeof(labels)/sizeof(labels[0]);
   for(i=0;i<len;++i)
      labels[i]->Visible = false;

   i=0;
   while(i<1&&!cancelled) {
      a=0;
      if((cvval=testIntVal(efR1->Text, 1, 127, false))!=-1) {
         CVs[0] = cvval;
         labels[0]->Visible=setREG(1,cvval);
         if(!labels[0]->Visible)
            a=errMsg("Register Schreiben",1);
      }
      i=errControl(a,i);
   }

   len = sizeof(edits)/sizeof(edits[0]);
   i=1;
   while(!cancelled && i<len) {
      a=0;
      cv = *(cvs+i)-1;
      if(usedCVs[cv]) {
         cvval=testIntVal(edits[i]->Text, 0, 255, false);
         if(cvval!=-1) {
            if(setREG(i+1, cvval)) {
               labels[1]->Visible = true;
               CVs[cv] = cvval;
            }
            else
               a=errMsg("Register Schreiben",*(cvs+i));
         }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall  TmainForm::verifyREGs() {
   TLabel *labels[] = {reg1ok,reg2ok,reg3ok,reg4ok,reg5ok,reg7ok,reg8ok};
   TEdit *edits[] = {efR1, efR2, efR3, efR4, efR5};
   int cvs[] = {1, 2, 3, 4, 29};
   int cv,cvval,i,a;
   int len = sizeof(labels)/sizeof(labels[0]);
   for(i=0;i<len;++i)
      labels[i]->Visible = false;
   i=0;
   while(i<1&&!cancelled) {
      a=0;
      if((cvval=testIntVal(efR1->Text, 1, 127, false))!=-1) {
         CVs[0] = cvval;
         labels[0]->Visible = verifyREG(1,cvval);
         if(!labels[0]->Visible)
            a=errMsg("Register Pr�fen",1);
      }
      i=errControl(a,i);
   }
   len = sizeof(edits)/sizeof(edits[0]);
   i=1;
   while(!cancelled && i<len) {
      a=0;
      cv = *(cvs+i)-1;
      if(usedCVs[cv]) {
         if((cvval=testIntVal(edits[i]->Text, 0, 255, false))!=-1) {
            labels[i]->Visible = verifyREG(i+1, cvval);
            if(!labels[i]->Visible)
               a=errMsg("Register Pr�fen",*(cvs+i));
         }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}

