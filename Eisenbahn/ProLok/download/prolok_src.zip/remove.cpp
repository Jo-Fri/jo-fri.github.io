//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "remove.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TformRemove *formRemove;

#include "tolop_main.h"
extern TmainForm *mainForm;

//---------------------------------------------------------------------------
__fastcall TformRemove::TformRemove(TComponent* Owner)
   : TForm(Owner)
{
   mainForm->loadFormCaptions(mainForm->szLanguage, formRemove);
}
//---------------------------------------------------------------------------
void __fastcall TformRemove::FormShow(TObject *Sender)
{
   mainForm->pIniFile->ReadSection("DecoderFiles",
      lbProfiles->Items);
}
//---------------------------------------------------------------------------
void __fastcall TformRemove::pbCancelClick(TObject *Sender)
{
   formRemove->Hide();   
}
//---------------------------------------------------------------------------
void __fastcall TformRemove::pbRemoveClick(TObject *Sender)
{
   if(lbProfiles->ItemIndex != -1) {
      String profile = lbProfiles->Items->Strings[lbProfiles->ItemIndex];
      lbProfiles->DeleteSelected();
      mainForm->removeFromIniFile("DecoderFiles", profile);
      for(int i=0;i<mainForm->mmNew->Count;++i) {
         if(mainForm->mmNew->Items[i]->Caption == profile) {
            mainForm->mmNew->Delete(i);
            break;
         }
      }
   }
}
//---------------------------------------------------------------------------
