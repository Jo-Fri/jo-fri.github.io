//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("tolop_main.cpp", mainForm);
USEFORM("setup.cpp", setupForm);
USEFORM("scan.cpp", scanForm);
USEFORM("msgForm.cpp", msgBox);
USEFORM("remove.cpp", formRemove);
USEFORM("about.cpp", aboutBox);
USEFORM("errors.cpp", faultListe);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
       Application->Initialize();
       Application->HelpFile = "help\\prolok.hlp";
       Application->Title = "ProLok - der einfache DCC-Lokprogrammer ";
       Application->CreateForm(__classid(TmainForm), &mainForm);
       Application->CreateForm(__classid(TsetupForm), &setupForm);
       Application->CreateForm(__classid(TscanForm), &scanForm);
       Application->CreateForm(__classid(TmsgBox), &msgBox);
       Application->CreateForm(__classid(TformRemove), &formRemove);
       Application->CreateForm(__classid(TaboutBox), &aboutBox);
       Application->CreateForm(__classid(TfaultListe), &faultListe);
       Application->Run();
   }
   catch (Exception &exception)
   {
       Application->ShowException(&exception);
   }
   catch (...)
   {
       try
       {
          throw Exception("");
       }
       catch (Exception &exception)
       {
          Application->ShowException(&exception);
       }
   }
   return 0;
}
//---------------------------------------------------------------------------
