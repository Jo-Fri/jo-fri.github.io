//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "tolop_main.h"
#include "detector.h"
#include "nmra_sm.h"

#pragma package(smart_init)
TDetectorThread *LocoDetector;
extern TmainForm *mainForm;

//---------------------------------------------------------------------------

//   Wichtig: Methoden und Eigenschaften von Objekten der VCL k�nnen nur
//   in Methoden verwendet werden, die Synchronize aufrufen, z.B.:
//
//      Synchronize(UpdateCaption);
//
//   wobei UpdateCaption so aussehen k�nnte:
//
//      void __fastcall TDetectorThread::UpdateCaption()
//      {
//        Form1->Caption = "In Thread aktualisiert";
//      }
//---------------------------------------------------------------------------

__fastcall TDetectorThread::TDetectorThread(bool CreateSuspended)
   : TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
void TDetectorThread::SetName()
{
   THREADNAME_INFO info;
   info.dwType = 0x1000;
   info.szName = "DetectorThread";
   info.dwThreadID = -1;
   info.dwFlags = 0;

   __try
   {
       RaiseException( 0x406D1388, 0, sizeof(info)/sizeof(DWORD),(DWORD*)&info );
   }
   __except (EXCEPTION_CONTINUE_EXECUTION)
   {
   }
}
//---------------------------------------------------------------------------
void __fastcall TDetectorThread::Execute()
{
   SetName();
   iNoLoco = 0;
   LocoDetected = false;
   Info = "";
   while(!Terminated) {
      Application->ProcessMessages();
      Sleep(250);
      if(!mainForm->ComPort1->Connected) {  // teste PR1
         mainForm->PR1Detected = false;
         LocoDetected = false;
      }
      else {
         if(mainForm->bIsDDL) { // DDL-> keine Lok- und Ger�teerkennung
            LocoDetected = true;
            mainForm->PR1Detected = true;
            mainForm->bProgTrack =
               mainForm->ComPort1->Signals() == TComSignals()<<csRing;
         }
         else {
            mainForm->PR1Detected = mainForm->bDSRtrue;
            if(!mainForm->PR1Detected || iNoLoco == 3)
               //nicht-erkannt-Z�hler auswerten
               LocoDetected = false;
            else
               iNoLoco++;
         }
      }
 	   if (mainForm->PR1Detected) {
         Info = mainForm->sz_ProgDev;
         // senden von 5 Idle-Paketen, danach sollten auf
         // Rx einige Bytes gelesen werden,
         // wenn eine Lok auf dem Gleis ist
         sendIdlePackets();
 	   }
      else
         Info = mainForm->sz_noProgDev;
      Synchronize(setButtons);
   }
}
//---------------------------------------------------------------------------

void __fastcall TDetectorThread::setButtons() {
   if(!mainForm->bButtonsLocked) {
      mainForm->pbRead->Enabled = ((!mainForm->bIsDDL && LocoDetected)
                        || (mainForm->bIsDDL && mainForm->bProgTrack));
      mainForm->pbVerify->Enabled = mainForm->pbRead->Enabled;
      mainForm->pbWrite->Enabled  = LocoDetected;
      mainForm->mmScan->Enabled = mainForm->pbRead->Enabled;
   }
   if(!mainForm->bIsDDL) {
      if(mainForm->PR1Detected) {
         if(LocoDetected)
            mainForm->StatusBar1->Panels->Items[2]->Text = mainForm->sz_Loco;
         else
            mainForm->StatusBar1->Panels->Items[2]->Text = mainForm->sz_noLoco;
      }
      else
         mainForm->StatusBar1->Panels->Items[2]->Text = "";
      mainForm->StatusBar1->Panels->Items[1]->Text = Info;
   }
   else {
      mainForm->StatusBar1->Panels->Items[2]->Text = "";
      if(mainForm->bProgTrack)
         mainForm->StatusBar1->Panels->Items[1]->Text = mainForm->sz_ProgTrk;
      else
         mainForm->StatusBar1->Panels->Items[1]->Text = mainForm->sz_noProgTrk;
   }
}
//---------------------------------------------------------------------------

