//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "scan.h"
#include "tolop_main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TscanForm *scanForm;

#include "msgForm.h"
extern TmsgBox *msgBox;
extern TmainForm *mainForm;

//---------------------------------------------------------------------------
__fastcall TscanForm::TscanForm(TComponent* Owner)
   : TForm(Owner)
{
   mainForm->loadFormCaptions(mainForm->szLanguage, scanForm);
  ProgressBar1->Position = 0;
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::UpDownStartScanClick(TObject *Sender, TUDBtnType Button)
{
   efStartScan->Text = IntToStr(UpDownStartScan->Position);
   if(UpDownStartScan->Position > UpDownStopScan->Position)
      UpDownStopScan->Position = UpDownStartScan->Position;
   UpDownStopScan->Min = UpDownStartScan->Position;
   efStopScan->Text = IntToStr(UpDownStopScan->Position);
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::UpDownStopScanClick(TObject *Sender,
      TUDBtnType Button)
{
   efStopScan->Text = IntToStr(UpDownStopScan->Position);
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::pbAddClick(TObject *Sender)
{
   int start = UpDownStartScan->Position;
   int stop =  UpDownStopScan->Position;
   char buf[12];
   sprintf(buf, "%4.4d - %4.4d", start, stop);
   lbScanRanges->Items->Add((AnsiString)buf);
   if(stop<1024) {
      UpDownStartScan->Position = stop+1;
      UpDownStartScan->Min = stop+1;
      UpDownStopScan->Position = stop+1;
      UpDownStopScan->Min = stop+1;
      efStartScan->Text = IntToStr(UpDownStartScan->Min);
      efStopScan->Text = IntToStr(UpDownStopScan->Min);
   }
   else {
      UpDownStartScan->Enabled = false;
      UpDownStopScan->Enabled = false;
   }
   pbScan->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::pbCloseClick(TObject *Sender)
{
   scanForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::pbScanClick(TObject *Sender)
{  // scan der CVs auf Les/Schreibbarkeit
   int cv;
   int i;
   int val, orgval;
   int range_start, range_stop, range;
   mainForm->clearCVs();
   pbScan->Enabled = false;
   pbClose->Enabled = false;
   msgBox->Show();
   for(i=0;i<lbScanRanges->Items->Count && !mainForm->cancelled;i++) {
      lbScanRanges->ItemIndex=i;
      sscanf((lbScanRanges->Items->Strings[i]).c_str(), "%d - %d",
                  &range_start, &range_stop );
      range = range_stop - range_start + 1;
      int position = 0;
      for(cv=range_start;cv<=range_stop && !mainForm->cancelled;cv++) {
        Application->ProcessMessages();
        if(position++>range)
            position=range;
         ProgressBar1->Position =
               (position* ProgressBar1->Max)/range;
         if(mainForm->getCV(cv)) {               // Wert lesen
            orgval = val = mainForm->CVs[cv-1];  // zwischenspeichern
            if(val>0)   val--;                   // abaendern
            else        val++;

            mainForm->setCV(cv,val);             // Schreibversuch
            if(!mainForm->verifyCV(cv,val)) {    // test
               mainForm->CVs[cv-1] = -1;          // kein neuer Wert
               mainForm->usedCVs[cv-1] = false;   // nicht benutzt
            }
            else {
               mainForm->setCV(cv, orgval);       // ok, restore
               mainForm->usedCVs[cv-1] = true;    // benutzt
            }
         }
      }
   }
   msgBox->Hide();
   ProgressBar1->Position = ProgressBar1->Max;
   if(mainForm->cancelled)
      mainForm->cancelled = false;
   pbClose->Enabled = true;
   pbScan->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::pbCancelClick(TObject *Sender)
{
   mainForm->cancelled = true;
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::pbDelClick(TObject *Sender)
{
   int i = lbScanRanges->Items->Count - 1;
   int a, e;
   if (i > -1) {
      sscanf((lbScanRanges->Items->Strings[i]).c_str(),"%d - %d", &a, &e);
      UpDownStartScan->Min = a;
      UpDownStopScan->Min = a;
      lbScanRanges->Selected[i] = true;
      lbScanRanges->DeleteSelected();
      if(lbScanRanges->Items->Count==0)
         Init();
   }
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::FormShow(TObject *Sender)
{
   Init();
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::FormHide(TObject *Sender)
{
   mainForm->tsActiveTabSheet=NULL;
   mainForm->tsAllCV->Visible=false;
   mainForm->tsAllCV->Show();
}
//---------------------------------------------------------------------------

void __fastcall TscanForm::Init()
{
   lbScanRanges->Clear();
   UpDownStartScan->Position = 1;
   UpDownStartScan->Min = 1;
   UpDownStopScan->Position = 1;
   UpDownStopScan->Min = 1;
   efStartScan->Text = IntToStr(UpDownStartScan->Position);
   efStopScan->Text = IntToStr(UpDownStopScan->Position);
   pbScan->Enabled = false;
}

