//===========================================================================

//Seite tsFunction
void __fastcall TmainForm::tsFunctionShow(TObject *Sender)
{
   enterTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::tsFunctionHide(TObject *Sender)
{
   exitTabSheet((TTabSheet *)Sender);
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::pbDefaultFunctionMappingClick(TObject *Sender)
{  // Eintragen der Defaultwerte in das FunctionMapping-Formular
   int defaultvalues[] = {1,2,4,8,16,4,8,16,32,64,16,32,64,128};
   int i, l=sizeof(defaultvalues)/sizeof(defaultvalues[0]);
   for(i=0;i<l;++i) {
      if(usedCVs[i+32]) {
         CVs[i+32] = defaultvalues[i];
         setFunctionMappingBits(i+33, defaultvalues[i]);
      }
   }
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::setFunctionMappingBits(int cvaddr, int cvval) {
// setzt die Checkboxen f�r ein FN-Mapping-CV
   TCheckBox *cb;
   String chkName = "CV" + IntToStr(cvaddr) + "b";
   int i;
   for(i=0;i<8;i++) {
     if(NULL!=
       (cb = (TCheckBox *)getControlByName(chkName + IntToStr(i))))
         cb->Checked = cvval & 1<<i;
   }
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::FunctionMappingBitClick(TObject *Sender)
// Aendern der FN-Mapping-Values nach Klick auf eine Bit-Checkbox
{
   int cv, cvval, bit;
   TCheckBox *cb;
   TEdit *edit;
   sscanf(((TCheckBox *)Sender)->Name.c_str(), "CV%db%d", &cv, &bit);
   String efName = "efCV" + IntToStr(cv);

   if(NULL!=(edit = (TEdit *)getControlByName(efName))) {
      if(edit->Text=="")
         cvval = 0;
      else
         cvval = StrToInt(edit->Text);
     if(((TCheckBox *)Sender)->Checked)
         edit->Text = IntToStr(cvval | (1<<bit));
     else
         edit->Text = IntToStr(cvval & ~(1<<bit));
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::saveFunctionMapping() {
   // uebertragen der Function-Mapping CVs aus dem Formular
   // in die Liste
   TEdit *efCVs[] = {efCV33,efCV34,efCV35,efCV36,efCV37,
                     efCV38,efCV39,efCV40,efCV41,efCV42,
                     efCV43,efCV44,efCV45,efCV46 };
   int i, l = sizeof(efCVs)/sizeof(efCVs[0]);
   for(i=0;i<l;i++) {
      if(efCVs[i]->Text!="") {
         CVs[i+32] = StrToInt(efCVs[i]->Text);
         sg1_1024->Cells[2][i+33] = IntToStr(CVs[i+32]);
      }
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::loadFunctionMapping() {
   // uebertragen der Function-Mapping CVs aus der Liste ins Formular
   TEdit *efCVs[] = {efCV33,efCV34,efCV35,efCV36,efCV37,
                     efCV38,efCV39,efCV40,efCV41,efCV42,
                     efCV43,efCV44,efCV45,efCV46 };
   TLabel *oklabels[] = {cv33ok,cv34ok,cv35ok,cv36ok,cv37ok,
                         cv38ok,cv39ok,cv40ok,cv41ok,cv42ok,
                         cv43ok,cv44ok,cv45ok,cv46ok };
   int i,j, l=sizeof(oklabels)/sizeof(oklabels[0]);
   TCheckBox *cbox;
   bool bDefault=false;
   for(i=0;i<l;i++) {
      oklabels[i]->Visible = false;
      enableEntryLabel(i+33);
      for(j=0;j<8;j++) {
         if(NULL!=(cbox=
            (TCheckBox *)getControlByName("CV"+IntToStr(i+33)+"b"+IntToStr(j))))
            cbox->Enabled = usedCVs[i+32];
            bDefault |= cbox->Enabled;
      }
   }
   pbDefaultFunctionMapping->Enabled=bDefault;
   for(i=0;i<l;i++) {
      if(CVs[i+32]!=-1) {
         setFunctionMappingBits(i+33, CVs[i+32]);
         efCVs[i]->Text = IntToStr(CVs[i+32]);
      }
      else {
         efCVs[i]->Text = "";
         setFunctionMappingBits(i+33, 0);
      }
   }
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::writeFunctionMapping() {
   TLabel *oklabels[] = {cv33ok,cv34ok,cv35ok,cv36ok,cv37ok,
                         cv38ok,cv39ok,cv40ok,cv41ok,cv42ok,
                         cv43ok,cv44ok,cv45ok,cv46ok };
   int i, a, l=sizeof(oklabels)/sizeof(oklabels[0]);
   for(i=0;i<l;i++)
      oklabels[i]->Visible = false;
   saveFunctionMapping();
   i=0;
   while(!cancelled && i<l) {
      a=0;
      if(usedCVs[i+32]) {
         if(setCV(i+33, CVs[i+32]))
            oklabels[i]->Visible = true;
         else  {
            oklabels[i]->Visible=false;
            a=errMsg("Schreiben",i+33);
         }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::readFunctionMapping() {
   TLabel *oklabels[] = {cv33ok,cv34ok,cv35ok,cv36ok,cv37ok,
                         cv38ok,cv39ok,cv40ok,cv41ok,cv42ok,
                         cv43ok,cv44ok,cv45ok,cv46ok };
   TEdit *efCVs[] = {efCV33,efCV34,efCV35,efCV36,efCV37,
                     efCV38,efCV39,efCV40,efCV41,efCV42,
                     efCV43,efCV44,efCV45,efCV46 };
   int i, a, l=sizeof(oklabels)/sizeof(oklabels[0]);
   for(i=0;i<l;i++) {
      oklabels[i]->Visible = false;
      efCVs[i]->Text = "";
   }
   Application->ProcessMessages();
   i=0;
   while(!cancelled && i<l) {
      a=0;
      if(usedCVs[i+32]) {
         if(getCV(i+33))
            efCVs[i]->Text = IntToStr(CVs[i+32]);
         else {
            efCVs[i]->Text = "";
            a=errMsg("Lesen",i+33);
         }
      }
      i=errControl(a,i);
      Application->ProcessMessages();
   }
   loadFunctionMapping();
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyFunctionMapping() {
   TLabel *oklabels[] = {cv33ok,cv34ok,cv35ok,cv36ok,cv37ok,
                         cv38ok,cv39ok,cv40ok,cv41ok,cv42ok,
                         cv43ok,cv44ok,cv45ok,cv46ok };
   TEdit *efCVs[] = {efCV33,efCV34,efCV35,efCV36,efCV37,
                     efCV38,efCV39,efCV40,efCV41,efCV42,
                     efCV43,efCV44,efCV45,efCV46 };
   int cv, i, a, l=sizeof(oklabels)/sizeof(oklabels[0]);
   cancelled = false;
   for(i=0;i<l;i++)
      oklabels[i]->Visible = false;
   i=0;
   while(!cancelled && i<l) {
      a=0;
      if(usedCVs[i+32]) {
         if((cv=chkIntVal(efCVs[i],0,255,true))!=-1) {
            if(verifyCV(i+33, cv))
               oklabels[i]->Visible = true;
            else  {
               oklabels[i]->Visible=false;
               a=errMsg("Pr�fen",i+33);
            }
         }
      }
      i=errControl(a,i);
      Application->ProcessMessages();
   }
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

