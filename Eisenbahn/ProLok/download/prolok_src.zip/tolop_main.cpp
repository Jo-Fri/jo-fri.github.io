//---------------------------------------------------------------------------
/*
   Prolok 1
   Programm zum Lesen, Schreiben und Pr�fen von Lokdecodern mit Hilfe
   eines Boosters/Ackdetectors oder eines Digitrax PR-1
	Lizenz:GPL
	Autor: Thomas Borrmann
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>

#pragma hdrstop

#include "tolop_main.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CPort"
#pragma link "CPortCtl"
#pragma resource "*.dfm"

TmainForm *mainForm;

#include "detector.h"
#include "nmra_sm.h"
#include "setup.h"
#include "scan.h"
#include "errors.h"
#include "msgForm.h"
#include "remove.h"
#include "about.h"
#include "ri.h"

//---------------------------------------------------------------------------
extern TaboutBox *aboutBox;
extern TformRemove *formRemove;
extern TmsgBox *msgBox;
extern TsetupForm *setupForm;
extern TscanForm *scanForm;
extern TDetectorThread *LocoDetector;
extern TRingIndikator *RingIndikator;
extern TfaultListe *faultListe;

#include "strings_de.cpp";

//---------------------------------------------------------------------------
__fastcall TmainForm::TmainForm(TComponent* Owner)
   : TForm(Owner)
{
   iMajorVersion = 0;
   iMinorVersion = 8;
   iBuild = 2;
   szAuthor = "Thomas Borrmann";

   bDirectMode = true;
   bPageMode = true;
   bIsDDL = false;
   bButtonsLocked = false;
   activeDecoderFile = "";
   bSafeMode = false;
   cancelled = false;
   bUseAll = false;
   pIniFile = NULL;
   tsActiveTabSheet=NULL;
   bTest0Bit=false;
   iRetryCount=-1;
   iWait=GetTickCount();
   szLanguage="";
   szPath=ExtractFilePath(Application->ExeName);
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::AppTerminate(String error) {
      Application->MessageBox(error.c_str(), sz_HardErr.c_str(), MB_OK);
      mainForm->Close();
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::FormCreate(TObject *Sender)
{
   int i;
   packet_init();
   pc1->ActivePage = tsBasis;
   activeDecoderFile = "";
   LocoDetector = new TDetectorThread(true);
   RingIndikator = new TRingIndikator(true);
   Application->HelpFile = szPath + "help/prolok.hlp";
   loadIniFile("prolok.ini");
   setTextRessources(szLanguage);
   if(PR1Port != "")
     connectPort(PR1Port);
   else
     StatusBar1->Panels->Items[0]->Text = sz_noPort;
   clearCVs();
   makeCV1_1024Headers();
   lbDecoder->Caption = "Decoder: " + sz_Simple;
   setUsedCVs(sz_Simple);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
   if(RingIndikator)
      RingIndikator->Terminate();
   if(LocoDetector)
      LocoDetector->Terminate();
   if(ComPort1->Connected)
      ComPort1->Close();
  saveIniFile("prolok.ini");
  saveLogFile("./daten/prolok.log");
  saveDecoderData("./daten/cvlist.bak",false);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::loadIniFile(String Name) {
  int i;
  TStringList *schemata = new TStringList;
  languages = new TStringList;
  if(pIniFile == NULL)
      pIniFile = new TMemIniFile("prolok.ini");
  try{
    mainForm->Top = pIniFile->ReadInteger("Window", "Top", 20);
    mainForm->Left = pIniFile->ReadInteger("Window", "Left", 120);
    szLanguage = pIniFile->ReadString("Window", "Lang", "");

    PR1Port = pIniFile->ReadString("PR1Port", "Port","");
    PR1_NMRA_cps = pIniFile->ReadBool("PR1Port", "NMRAbps",false);
    bUSBserial = pIniFile->ReadBool("PR1Port", "USBserial", false);
    bIsDDL = pIniFile->ReadBool("PR1Port", "IsDDL", false);

    bDirectMode = pIniFile->ReadBool("ProgrammingMode", "DirectMode", true);
    bPageMode = pIniFile->ReadBool("ProgrammingMode", "PageMode", true);
    bSafeMode = pIniFile->ReadBool("ProgrammingMode", "SafeMode", false);
    bTest0Bit = pIniFile->ReadBool("ProgrammingMode", "SafeBitTest", false);
    iWaitXms = pIniFile->ReadInteger("ProgrammingMode", "Loop", 0);
    bExtendedPowerOn =
               pIniFile->ReadBool("ProgrammingMode","ExtendedPowerOn",false);
    bLog = pIniFile->ReadBool("Logfile","Logging",false);
    if(bLog) LogList = new TStringList();
    iRetryOnError = pIniFile->ReadInteger("Logfile","RetryOnError",-1);
    pIniFile->ReadSection("DecoderFiles", schemata);
    for(i=0;i<schemata->Count;++i)
      loadSubMenu(schemata->Strings[i]);
  }
  __finally{
  }
   delete schemata;
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::saveIniFile(String Name)
{
  int i;
  TStringList *files = new TStringList();
  TStringList *schemata = new TStringList();
  if(pIniFile==NULL)
      pIniFile = new TMemIniFile(Name);
  try{
    pIniFile->WriteInteger("Window", "Top", mainForm->Top);
    pIniFile->WriteInteger("Window", "Left", mainForm->Left);
    pIniFile->WriteString("Window", "Lang", szLanguage);

    pIniFile->WriteString("PR1Port", "Port", PR1Port);
    pIniFile->WriteBool("PR1Port", "NMRAbps", PR1_NMRA_cps);
    pIniFile->WriteBool("PR1Port", "USBserial", bUSBserial);
    pIniFile->WriteBool("PR1Port", "IsDDL", bIsDDL);

    pIniFile->WriteBool("ProgrammingMode", "DirectMode", bDirectMode);
    pIniFile->WriteBool("ProgrammingMode", "PageMode", bPageMode);
    pIniFile->WriteBool("ProgrammingMode", "SafeMode", bSafeMode);
    pIniFile->WriteBool("ProgrammingMode", "SafeBitTest", bTest0Bit);
    pIniFile->WriteInteger("ProgrammingMode", "Loop", iWaitXms);
    pIniFile->WriteBool("ProgrammingMode","ExtendedPowerOn",bExtendedPowerOn);
    pIniFile->WriteBool("Logfile","Logging",bLog);
    pIniFile->WriteInteger("Logfile","RetryOnError",iRetryOnError);

    for(i=0;i<schemata->Count;++i)
      pIniFile->WriteString("DecoderFiles", schemata->Strings[i],
                                             files->Strings[i]);
    pIniFile->UpdateFile();
    delete pIniFile;
  }
  catch(Exception *E) {
      Application->MessageBox(sz_IniWrErr.c_str(),sz_Error.c_str(), MB_OK);
  }
  delete schemata;
  delete files;
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::addToIniFile(String section, String key, String value) {
   if(pIniFile!=NULL)
      pIniFile->WriteString(section, key, value);
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::removeFromIniFile(String section, String key) {
   if(pIniFile!=NULL)
      pIniFile->DeleteKey(section, key);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::loadSubMenu(String Name)
{
   TMenuItem *mmNewSub = NewItem(Name, NULL, false, true,
                                 mmNewClick,  0,
                "mmProfile"+IntToStr(mmNew->Count+1));
   mmNew->Add(mmNewSub);

}
//---------------------------------------------------------------------------

void __fastcall TmainForm::saveDecoderData(String fn, bool unconditional)
{  // Schreiben der Decoderdaten in die Datei fn
  int i;
  AnsiString cv, desc;
  TMemIniFile *pIniFile = new TMemIniFile(fn);
  msgBox->Caption = sz_save;
  msgBox->lbMsg->Caption = sz_wait;
  msgBox->Show();
  Application->ProcessMessages();
  try{
    pIniFile->Clear();
    for(i=0;i<1024;i++) {
         cv = "CV"+IntToStr(i+1);
         if(usedCVs[i]) {
            if(CVs[i] != -1)
               pIniFile->WriteInteger("DecoderData", cv, CVs[i]);
            else
               pIniFile->WriteInteger("DecoderData", cv, 0);
            if((desc=sg1_1024->Cells[1][i+1]) != "")
               pIniFile->WriteString("Description", cv, desc);
            if(NULL!=bitmapCVs[i]) {
               desc=bitmapCVs[i]->DelimitedText;
               pIniFile->WriteString("Bitmaps", cv, desc);
            }
         }
    }
    pIniFile->UpdateFile();
    delete pIniFile;
  }
  catch(Exception *E) {
      if(unconditional)
         Application->MessageBox(sz_WrDecErr.c_str(),sz_Error.c_str(),MB_OK);
  }
  msgBox->Hide();
  msgBox->lbMsg->Caption = "";
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::addLog(unsigned long ulTime, String sLog) {
   try {
      LogList->Add(IntToStr(ulTime)+ " " + sLog);
   }
   catch(...) {
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::saveLogFile(String fn)
{  // Schreiben des Log in die Datei fn
   int i, iFp;
   if(bLog) {
      try{
         if(FileExists(fn)) iFp=FileOpen(fn,fmOpenWrite);
         else              iFp=FileCreate(fn,fmOpenWrite);
         for(i=0;i<LogList->Count;++i)
            FileWrite(iFp,(LogList->Strings[i]+"\n").c_str(),(LogList->Strings[i]+"\n").Length());
         FileClose(iFp);
      }
      catch(Exception *E){
         Application->MessageBox(sz_WrLogErr.c_str(),sz_Error.c_str(),MB_OK);
      }
   }
}

//---------------------------------------------------------------------------

String __fastcall TmainForm::getSchemaFileName(String name)
{  // lesen des Dateinamens einer Schema-Datei

   if(pIniFile!=NULL)
      return pIniFile->ReadString("DecoderFiles", name,"");
  return "";
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmSetupClick(TObject *Sender)
{
   closePort();
   setupForm->Show();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmScanClick(TObject *Sender)
{
   scanForm->Show();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmExitClick(TObject *Sender)
{
   mainForm->Close();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmNewClick(TObject *Sender)
// alle Werte zur�cksetzen
{
   String caption = ((TMenuItem *)Sender)->Caption;
   bCV29changed = false;
   clearCVs();
   makeCV1_1024Headers();
   lbDecoder->Caption = "Decoder: " + caption;
   profileName = caption;
   setUsedCVs(caption);
   activeDecoderFile = "";
   tsActiveTabSheet=NULL;
   pc1->ActivePage->Hide();
   tsBasis->Show();
}
//==================================================================

void __fastcall TmainForm::mmFileClick(TObject *Sender)
{                            // Menue 'Datei' geoeffnet
   if(activeDecoderFile=="")
      mmSave->Enabled = false;
   else
      mmSave->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmLoadClick(TObject *Sender)
{                            //  'Laden'
   char *pFn;
   if(odLoadFile->Execute()) {
      activeDecoderFile = odLoadFile->FileName;
      if(NULL==(pFn = StrRScan(activeDecoderFile.c_str(), '\\')))
         pFn = activeDecoderFile.c_str();
      else
         pFn++;
      lbDecoder->Caption = sz_File + ": " + (String)pFn;
      clearCVs();
      setUsedCVsFromFile(activeDecoderFile);
      tsActiveTabSheet=NULL;
      pc1->ActivePage->Hide();
      tsBasis->Show();
   }
}
//---------------------------------------------------------------------------
// eine Tabulator-Seite verlassen
void __fastcall TmainForm::exitTabSheet(TTabSheet *ts) {

   if(ts && ts==tsActiveTabSheet) {

#ifdef __LOG
   Application->MessageBox(((String)"Exit " + ts->Caption).c_str(),
                           "Event",MB_OK);
#endif

      if(ts==tsAllCV)
         saveAllCV();
      if(ts==tsBasis)
         saveBaseCVs();
      if(ts==tsFunction)
         saveFunctionMapping();
      if(ts==tsSpeedTab)
         saveSpeedTab();
      if(ts==tsMore)
         saveMoreCV();
      if(ts==tsRegister)
         saveRegister();
   }
   Application->ProcessMessages();
}
//--------------------------------------------------------------------------

// eine Tabulator-Seite betreten
void __fastcall TmainForm::enterTabSheet(TTabSheet *ts) {

   Application->ProcessMessages();
   exitTabSheet(tsActiveTabSheet);

#ifdef __LOG
   Application->MessageBox(((String)"Enter " + ts->Caption).c_str(),
                           "Event",MB_OK);
#endif

   tsActiveTabSheet=ts;
   if(ts==tsAllCV)
      loadAllCV();
   if(ts==tsBasis)
      loadBaseCVs();
   if(ts==tsFunction)
      loadFunctionMapping();
   if(ts==tsSpeedTab)
      loadSpeedTab();
   if(ts==tsMore)
      loadMoreCV();
   if(ts==tsRegister)
      loadRegister();
}
//--------------------------------------------------------------------------

void __fastcall TmainForm::mmSaveClick(TObject *Sender)
{                             // 'Speichern'
   if(activeDecoderFile>"") {
      exitTabSheet(pc1->ActivePage);
      saveDecoderData(activeDecoderFile,true);
      loadAllCV();
   }
}
//--------------------------------------------------------------------------

void __fastcall TmainForm::mmSaveAsClick(TObject *Sender)
{                             // 'Speichern als'
   char *pFn;
   if(sdSaveAs->Execute()) {
      exitTabSheet(pc1->ActivePage);
      activeDecoderFile = sdSaveAs->FileName;
      if(NULL==(pFn = StrRScan(activeDecoderFile.c_str(), '\\')))
         pFn = activeDecoderFile.c_str();
      else
         pFn++;
      lbDecoder->Caption = sz_File + ": " + (String)pFn;
      saveDecoderData(activeDecoderFile,true);
      loadAllCV();
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmChangeClick(TObject *Sender)
{                               // 'Aendern'
   for(int i=0;i<1024;i++)
      usedCVs[i] = true;
   pc1->ActivePage->Hide();
   loadAllCV();
   tsAllCV->Show();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmAddClick(TObject *Sender)
{                               // 'Hinzufuegen'
   String sInput;
   if(InputQuery(sz_Add,sz_mmEntryName,sInput)) {
      odLoadFile->FileName="daten\\dekoder\\*";
      if(odLoadFile->Execute()) {
         addToIniFile("DecoderFiles", sInput, odLoadFile->FileName);
         loadSubMenu(sInput);
      }
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmRemoveClick(TObject *Sender)
{  //entfernen eines Profil-Eintrags
   formRemove->Show();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmAboutClick(TObject *Sender)
{
   aboutBox->lbAbout->Caption = (String)("ProLok\n\n") +
                       (String)("DCC-Decoder Service Mode\n") +
                       (String)("Version: ") +
                                IntToStr(iMajorVersion) +
                       (String)(".") +
                                IntToStr(iMinorVersion) +
                       (String)(".") +
                                IntToStr(iBuild) +
                       (String)("\n") +
                       (String)("Autor: ") + szAuthor +
                       (String)("\n") +
                       (String)("Freeware - GNU Public License");
   aboutBox->Show();
}


//================================================================

void __fastcall TmainForm::connectPort(String port) {
// COM-Port �ffnen
   PR1Detected  = false;
	AckDetected  = false;
   LocoDetector->LocoDetected = false;
   LocoDetector->iNoLoco = 0;
   lbSuccess->Caption = "";
   lbMode->Caption = "";
   if(port > "") {
      ComPort1->Port = port.c_str();
      ComPort1->EventThreadPriority=tpHighest;
      ComPort1->CustomBaudRate = PR1_NMRA_cps?16457:19200;
      ComPort1->DataBits = dbEight;
      StatusBar1->Panels->Items[1]->Text = "";
      StatusBar1->Panels->Items[2]->Text = "";
      try {
         mainForm->ComPort1->Open();
         if(ComPort1->Connected) {
            ComPort1->SetRTS(true);
            ComPort1->SetDTR(true);
            StatusBar1->Panels->Items[0]->Text =
                                mainForm->PR1Port + " on";
         }
      }
      catch (Exception *E) {
            StatusBar1->Panels->Items[0]->Text =
                                          mainForm->PR1Port + " off";
      }
      if(mainForm->ComPort1->Connected) {
         while(LocoDetector->Suspended) {
            LocoDetector->Resume();
            Application->ProcessMessages();
         }
      }
   }
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::closePort() {
// COM-Port schliessen
   while(!LocoDetector->Suspended)
      LocoDetector->Suspend();
   Application->ProcessMessages();
   while(!RingIndikator->Suspended)
      RingIndikator->Suspend();
   Application->ProcessMessages();
   try {
      if(ComPort1->Connected)
         ComPort1->Close();
   }
   catch(Exception *E) {
      AppTerminate(sz_noPortAccess);
   }
   PR1Detected  = false;
	AckDetected  = false;
   LocoDetector->LocoDetected = false;
   LocoDetector->iNoLoco = 0;
   lbSuccess->Caption = "";
   lbMode->Caption = "";
   StatusBar1->Panels->Items[1]->Text = "";
   StatusBar1->Panels->Items[2]->Text = "";
   StatusBar1->Panels->Items[0]->Text = mainForm->PR1Port + " off";
   Application->ProcessMessages();
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::ComPort1DSRChange(TObject *Sender, bool OnOff)
{
   bDSRtrue = OnOff;
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::ComPort1RLSDChange(TObject *Sender, bool OnOff)
{
   AckDetected = true;
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::ComPort1RxChar(TObject *Sender, int Count)
{
   char *dummy = new char[Count + 1];
   ComPort1->Read(dummy, Count);
   delete [] dummy;
   LocoDetector->LocoDetected = true;
   LocoDetector->iNoLoco = 0;
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::storeCVs() {
   int i;
   for(i=0;i<1024;++i) storedCVs[i]=CVs[i];
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::restoreCVs() {
   int i;
   for(i=0;i<1024;++i) CVs[i]=storedCVs[i];
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::lockButtons(TButton *button) {
   int i;
   storeCVs();
   bButtonsLocked = true;
   pbRead->Default = button==pbRead;
   pbWrite->Default = button==pbWrite;
   pbVerify->Default = button==pbVerify;

   pbRead->Enabled = button==pbRead;
   pbWrite->Enabled = button==pbWrite;
   pbVerify->Enabled = button==pbVerify;

   mmFile->Enabled = false;
   mmDecoder->Enabled = false;
   mmSetup->Enabled = false;
   mmHelp->Enabled = false;

   button->Caption = sz_Cancel;
   pc1->Enabled=false;
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::unlockButtons() {
   bButtonsLocked = false;
   pc1->Enabled=true;
   if(cancelled) {
      restoreCVs();
      tsActiveTabSheet=NULL;
      enterTabSheet(pc1->ActivePage);
   }
   cancelled = false;
   pbRead->Default = false;
   pbWrite->Default = false;
   pbVerify->Default = false;

   pbRead->Caption = sz_Read;
   pbWrite->Caption = sz_Write;
   pbVerify->Caption = sz_Verify;

   pbRead->Enabled = true;
   pbWrite->Enabled = true;
   pbVerify->Enabled = true;

   mmFile->Enabled = true;
   mmDecoder->Enabled = true;
   mmSetup->Enabled = true;
   mmHelp->Enabled = true;
   msgBox->lbMsg->Caption = "";
   msgBox->Hide();
   if(faultListe->lbErrors->Count>0)
      faultListe->Show();
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::pbReadClick(TObject *Sender)
{               // Klick auf 'Lesen'
   if(pbRead->Caption == sz_Cancel) {
      pbRead->Enabled = false;
      cancelled = true;
      return;
   }
   lockButtons(pbRead);
   msgBox->lbMsg->Caption = "";
   msgBox->Show();
   if(pc1->ActivePage == tsBasis)
      readBaseCVs();
   if(pc1->ActivePage == tsFunction)
      readFunctionMapping();
   if(pc1->ActivePage == tsSpeedTab)
      readSpeedTab();
   if(pc1->ActivePage == tsMore)
      readMoreCV();
   if(pc1->ActivePage == tsSingleCV)
      getSingleCV();
   if(pc1->ActivePage == tsAllCV)
      readAllCV();
   if(pc1->ActivePage == tsRegister)
      readREGs();
   unlockButtons();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::pbVerifyClick(TObject *Sender)
{                                   // Pr�fen
   if(pbVerify->Caption == sz_Cancel) {
      pbVerify->Enabled = false;
      cancelled = true;
      return;
   }
   lockButtons(pbVerify);
   msgBox->lbMsg->Caption = "";
   msgBox->Show();
   if(pc1->ActivePage == tsBasis)
      verifyBaseCVs();
   if(pc1->ActivePage == tsFunction)
      verifyFunctionMapping();
   if(pc1->ActivePage == tsSpeedTab)
      verifySpeedTab();
   if(pc1->ActivePage == tsMore)
      verifyMoreCV();
   if(pc1->ActivePage == tsSingleCV)
      chkSingleCV();
   if(pc1->ActivePage == tsAllCV)
      verifyAllCV();
   if(pc1->ActivePage == tsRegister)
      verifyREGs();
   unlockButtons();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::pbWriteClick(TObject *Sender)
{                                 // Schreiben
   if(pbWrite->Caption == sz_Cancel) {
      pbWrite->Enabled = false;
      cancelled = true;
      return;
   }

   lockButtons(pbWrite);
   msgBox->lbMsg->Caption = "";
   msgBox->Show();

//   if(pc1->ActivePage != tsSingleCV)
//      pbWrite->Caption = sz_Cancel;

   if(pc1->ActivePage == tsBasis)
      writeBaseCVs();
   if(pc1->ActivePage == tsFunction)
      writeFunctionMapping();
   if(pc1->ActivePage == tsSpeedTab)
      writeSpeedTab();
   if(pc1->ActivePage == tsMore)
      writeMoreCV();
   if(pc1->ActivePage == tsSingleCV)
      writeSingleCV();
   if(pc1->ActivePage == tsAllCV)
      writeAllCV();
   if(pc1->ActivePage == tsRegister)
      writeREGs();
   unlockButtons();
}

//===========================================================================

void __fastcall TmainForm::clearCVs() {
// alle CVs mit -1 initialisieren
   int i;
   bUseAll = false;
   for(i=0; i<1024; i++) {
      CVs[i] = -1;
      if(bitmapCVs[i]!=NULL)
         delete bitmapCVs[i];
      bitmapCVs[i]=NULL;
      usedCVs[i] = false;
      hideRow(i+1);
   }
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::setUsedCVs(String caption) {
// alle benutzten CVs einstellen
   String fn;
   int i;
   if((fn = getSchemaFileName(caption)) == "") {
      if(caption==sz_Mini)
         setUsedCVsFromFile("./daten/decoder/minimal.txt");
      if(caption==sz_Simple)
         setUsedCVsFromFile("./daten/decoder/standard.txt");
      if(caption==sz_All) {
         bUseAll = true;
         for(i=0; i<1024; i++) { // alle CVs neu initialisieren
           usedCVs[i] = true;
           sg1_1024->RowHeights[i+1] = sg1_1024->DefaultRowHeight;
         }
      }
   }
   else
      setUsedCVsFromFile(fn);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::setUsedCVsFromFile(String filename) {
// benutzte CV aus der Datei filename einstellen
  TMemIniFile *pIniFile = new TMemIniFile(filename);
  int i,j;
  String cv, desc;
  try{
    for(i=0;i<1024;i++) {
      cv = IntToStr(i+1);
      sg1_1024->Cells[0][i+1] = cv;
      cv = "CV" + cv;
      CVs[i] = pIniFile->ReadInteger("DecoderData", cv, -1);
      desc = pIniFile->ReadString( "Description", cv, "");
      if(desc!="" || CVs[i]!=-1) {
         usedCVs[i] = true;
         if(CVs[i]!=-1)
            sg1_1024->Cells[2][i+1] = IntToStr(CVs[i]);
         else
            sg1_1024->Cells[2][i+1] = "";
         if(desc > "")
            sg1_1024->Cells[1][i+1] = desc;
         sg1_1024->RowHeights[i+1] = sg1_1024->DefaultRowHeight;
      }
      desc = pIniFile->ReadString( "Bitmaps", cv, "");
      if(desc!="") {
         try {
            bitmapCVs[i]=new TStringList();
            bitmapCVs[i]->QuoteChar='"';
            bitmapCVs[i]->Delimiter='|';
            bitmapCVs[i]->DelimitedText=desc;
            if(bitmapCVs[i]->Count<8) {
               for(j=bitmapCVs[i]->Count-1;j<8;j++) bitmapCVs[i]->Add("");
            }
         }
         catch(Exception *E) {
            bitmapCVs[i] = NULL;
            Application->MessageBox((sz_OutOfMem + " " + sz_BitmapDesc).c_str(),
                        sz_Error.c_str(), MB_OK);
         }
      }
      else
         bitmapCVs[i] = NULL;
    }
  }
  __finally{
   delete pIniFile;
  }
}
//---------------------------------------------------------------------------

int __fastcall TmainForm::chkIntVal(TEdit *edit, int min, int max, bool quiet) {
// teste Wert in Eingabefeld edit auf Bereich zwischen min und max
// quiet=true: Fehlermeldung nicht anzeigen
   int retval=-1;
   String string = Trim(edit->Text);
   if(string!="") {
      if((retval=testIntVal(string, min, max, quiet))==-1)
         try {
            edit->SetFocus();
         }
         catch(Exception *E) {
         }
   }
   return retval;
}

//---------------------------------------------------------------------------

int __fastcall TmainForm::testIntVal(String string, int min, int max, bool quiet) {
// teste Wert val auf Bereich zwischen min und max
// quiet=true: Fehlermeldung nicht anzeigen
   int x = -1;
   if(string != "") {
      try {
         x = StrToInt(string);
         if (x > max || x < min) {
            x = -1;
            if(!quiet) {
               char buffer[128];
               sprintf(buffer,sz_InputValFormat.c_str(),min,max);
               Application->MessageBox(buffer,sz_Error.c_str(), MB_OK);
            }
         }
      }
      catch(Exception *E) {
         if(!quiet)
            Application->MessageBox(sz_Numeric.c_str(),
                                    sz_Error.c_str(), MB_OK);
      }
   }
   return x;
}

//---------------------------------------------------------------------------
int  __fastcall TmainForm::readCVdirect(int CV) {
// lesen im direct Mode
   int bitx0, bitx1, cvval, bit;
   char buf[10];
   cvval = -1;
   msgBox->Caption = sz_Read;
   msgBox->lbMsg->Caption = "";
   // Auslesen durch VERIFY Bit 0..7
   // Bit 0 = 1 oder 0...
   StatusBar1->Panels->Items[3]->Text = "Direct Mode";
   msgBox->lbMsg->Caption = "Test CV" + IntToStr(CV+1) + ": 0x01/1";
   bitx1 = protocol_nmra_sm_verify_cvbit(CV, 0, 1);
   msgBox->lbMsg->Caption = "Test CV" + IntToStr(CV+1) + ": 0x01/0";
   if (protocol_nmra_sm_verify_cvbit(CV, 0, 0)!=bitx1 && !cancelled)	{
    	cvval = bitx1;
  		// Direct Access wird vom Decoder unterstuetzt
  		for(bit=1; bit<8 && cvval!=-1 && !cancelled; bit++)	{
                        // die restlichen 7 Bits holen
         sprintf(buf, "%2.2X/1\0", (1<<bit));
         msgBox->lbMsg->Caption =
            "Test CV" + IntToStr(CV+1) + ": 0x" + (String)buf;
     		bitx1=protocol_nmra_sm_verify_cvbit(CV, bit, 1);
         if(bTest0Bit) {
            sprintf(buf, "%2.2X/0\0", (1<<bit));
            msgBox->lbMsg->Caption =
                  "Test CV" + IntToStr(CV+1) + ": 0x" + (String)buf;
            bitx0 = protocol_nmra_sm_verify_cvbit(CV, bit, 0);
         }
         else
            bitx0=1^bitx1;
         if(bitx0==bitx1)
            cvval=-1;
         else
            if(bitx1==1) cvval |= (1 << bit);
      }
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   return cancelled? -1:cvval;
}
//---------------------------------------------------------------------------

int  __fastcall TmainForm::readCVdirect_USB(int CV) {
// lesen im paged mode
// durch VERIFY von 0...255
   int test, cvval, bit;
   StatusBar1->Panels->Items[3]->Text = "Direct Mode";
   cvval = 0;
   test = 0;
   msgBox->Caption = sz_Read;
   msgBox->lbMsg->Caption = "";
	while(!cancelled && cvval < 256 && test == 0)	{
      msgBox->lbMsg->Caption =
            "Test CV" + IntToStr(CV+1) + ": " + IntToStr(cvval);
     	if((test=protocol_nmra_sm_verify_cvbyte(CV, cvval)) == 0)
        	cvval++;
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   return cvval==256 || cancelled? -1:cvval;
}
//---------------------------------------------------------------------------

int  __fastcall TmainForm::readCVpaged(int CV) {
// lesen im paged mode
// durch VERIFY von 0...255
   int test, cvval, bit;
   StatusBar1->Panels->Items[3]->Text = "Page Mode";
   cvval = 0;
   test = 0;
   msgBox->Caption = sz_Read;
   msgBox->lbMsg->Caption = "";
	while(!cancelled && cvval < 256 && test == 0)	{
      msgBox->lbMsg->Caption =
            "Test CV" + IntToStr(CV+1) + ": " + IntToStr(cvval);
     	if((test=protocol_nmra_sm_verify_cvpaged(CV, cvval)) == 0)
        	cvval++;
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   return cvval==256 || cancelled? -1:cvval;
}
//---------------------------------------------------------------------------

int  __fastcall TmainForm::readRegister(int REG) {
// lesen im register mode
   int test, regval, bit;
   // Auslesen durch VERIFY von 0...256
   StatusBar1->Panels->Items[3]->Text = "Register Mode";
   regval = 0;
   test = 0;
   msgBox->Caption = sz_Read;
   msgBox->lbMsg->Caption = "";
	while(!cancelled && regval<256 && test==0)	{
      msgBox->lbMsg->Caption =
            "Test R" + IntToStr(REG) + ": " + IntToStr(regval);
     	if((test=protocol_nmra_sm_verify_phregister(REG, regval))==0)
        	regval++;
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   return regval==256 || cancelled? -1:regval;
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::readRP922() {
// gibt die Beschreibungen der CV lt.  RP9.2.2 zur�ck
// die Stringtabelle Beschreibungstabelle ein
   int i;
   TMemIniFile *pIniFile = new TMemIniFile("./daten/nmra/rp922.txt");
   try{
      for(i=0;i<1024;i++)
        sg1_1024->Cells[1][i+1] = pIniFile->ReadString(
                  "Multi-function Decoders", IntToStr(i+1), "");
   }
   __finally{
   delete pIniFile;
   }
}

//---------------------------------------------------------------------------
String __fastcall TmainForm::readManufacturer(int number) {
// ermittelt den Hersteller aus dem Inhalt von CV8
  String manufactorer = "";
  TMemIniFile *pIniFile = new TMemIniFile("./daten/nmra/manufacturers.txt");
  try{
    manufactorer =
         pIniFile->ReadString("Manufacturers",
                              IntToStr(number), sz_unknown);
  }
  __finally{
   delete pIniFile;
  }
  return manufactorer;
}
//---------------------------------------------------------------------------

bool __fastcall TmainForm::getCV(int CVaddr) {
// Inhalt von CVaddr auslesen
// CVaddr = 1..1024, Abzug von 1 erfolgt hier
   bool stat=false;
   int CVval=-1;
   if(iRetryCount==-1)
      iRetryCount=iRetryOnError;
   if(CVaddr > 0) {
      CVaddr--;
      LocoDetector->Suspend();
      if(bDirectMode) {
     	   if(-1==(CVval = readCVdirect(CVaddr)))
            if(bUSBserial)
               CVval = readCVdirect_USB(CVaddr);
      }
      if(bPageMode && CVval==-1)
         CVval = readCVpaged(CVaddr);
      if(CVval!=-1 && bSafeMode)    // pr�ft den gelesenen Wert
         CVval = verifyCV(CVaddr+1, CVval)? CVval:-1;
      LocoDetector->Resume();
      if(CVval>-1 && CVval<256) {
         CVs[CVaddr] = CVval;
         usedCVs[CVaddr] = true;
         stat=true;
      }
   }
   if(stat) iRetryCount=-1;
   return stat;
}

//---------------------------------------------------------------------------

bool __fastcall TmainForm::setCV(int CVaddr, int CVval) {
// CVval in CVaddr schreiben
// CVaddr = 1..1024, Abzug von 1 erfolgt hier
   bool stat=false;
   msgBox->Caption = sz_Write;
   msgBox->lbMsg->Caption = "";
   if(iRetryCount==-1)
      iRetryCount=iRetryOnError;
   if(CVaddr>0 && CVval>-1) {
      msgBox->lbMsg->Caption =
         "Set CV" + IntToStr(CVaddr) + "=" + IntToStr(CVval);
      CVaddr--;
      CVs[CVaddr] = CVval;
      usedCVs[CVaddr] = true;
      LocoDetector->Suspend();
      if(bDirectMode) {
         StatusBar1->Panels->Items[3]->Text = "Direct Mode";
         Application->ProcessMessages();
         stat=(bool)(1==protocol_nmra_sm_write_cvbyte(CVaddr, CVval));
      }
      if(!stat && bPageMode) {
         StatusBar1->Panels->Items[3]->Text = "Paged Mode";
         Application->ProcessMessages();
         stat=(bool)(1==protocol_nmra_sm_write_cvpaged(CVaddr, CVval));
      }
      if(stat && bSafeMode) // noch pr�fen
         stat = verifyCV(CVaddr+1, CVval);
      LocoDetector->Resume();
   }
   StatusBar1->Panels->Items[3]->Text = "";
   if(stat) iRetryCount=-1;
   Application->ProcessMessages();
   return stat;
}
//---------------------------------------------------------------------------

bool __fastcall TmainForm::verifyCV(int CVaddr, int CVval) {
// CVval in CVaddr pruefen
// CVaddr = 1..1024, Abzug von 1 erfolgt hier
//   if(!(PR1Detected || (bIsDDL && bProgTrack))) return false;
   bool stat = false;
   msgBox->Caption = sz_Verify;
   msgBox->lbMsg->Caption = "";
   if(iRetryCount==-1)
      iRetryCount=iRetryOnError;
   if(CVaddr>0 && CVval>-1) {
      msgBox->lbMsg->Caption =
         "Verify CV" + IntToStr(CVaddr) + "=" + IntToStr(CVval);
      CVaddr--;
      LocoDetector->Suspend();
      if(bDirectMode) {
         StatusBar1->Panels->Items[3]->Text = "Direct Mode";
         Application->ProcessMessages();
         stat=protocol_nmra_sm_verify_cvbyte(CVaddr, CVval);
      }
      if(!stat && bPageMode) {
         StatusBar1->Panels->Items[3]->Text = "Paged Mode";
         Application->ProcessMessages();
         stat=protocol_nmra_sm_verify_cvpaged(CVaddr, CVval);
      }
      LocoDetector->Resume();
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   if(stat) iRetryCount=-1;
   return stat;
}

//---------------------------------------------------------------------------

bool __fastcall TmainForm::getREG(int REG) {
// Inhalt von REG auslesen
// REG = 1..8
   bool stat = false;
   int REGval;
   int regs[] = {1, 2, 3, 4, 29, -1, 7, 8};
   if(iRetryCount==-1)
      iRetryCount=iRetryOnError;
   if(REG > 0) {
      LocoDetector->Suspend();
      REGval = readRegister(REG);
      if(REGval!=-1 && bSafeMode)    // pr�ft den gelesenen Wert
         REGval = verifyREG(REG, REGval)? REGval:-1;
      LocoDetector->Resume();
      if(REGval>-1 && REGval<256 && *(regs+REG-1)!=-1) {
         CVs[*(regs+REG-1)-1] = REGval;
         stat=true;
      }
   }
   if(stat) iRetryCount=-1;
   return stat;
}

//---------------------------------------------------------------------------

bool __fastcall TmainForm::setREG(int REGaddr, int REGval) {
// Inhalt in REG schreiben
// REG = 1..8
   int regs[] = {1, 2, 3, 4, 29, -1, 7, 8};
   bool stat=false;
   msgBox->Caption = sz_Write;
   msgBox->lbMsg->Caption = "";
   StatusBar1->Panels->Items[3]->Text = "Register Mode";
   if(iRetryCount==-1)
      iRetryCount=iRetryOnError;
   if(REGaddr>0 && REGval>-1) {
      msgBox->lbMsg->Caption =
         "Set R" + IntToStr(REGaddr) + "=" + IntToStr(REGval);
      if(*(regs+REGaddr-1)!=-1) {
         CVs[*(regs+REGaddr-1)-1] = REGval;
         usedCVs[*(regs+REGaddr-1)-1] = true;
      }
      LocoDetector->Suspend();
      stat=(1==protocol_nmra_sm_write_phregister(REGaddr, REGval))?true:false;
      if(stat && bSafeMode) // noch pr�fen
         stat = verifyREG(REGaddr, REGval);
      LocoDetector->Resume();
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   if(stat) iRetryCount=-1;
   return stat;
}
//---------------------------------------------------------------------------

bool __fastcall TmainForm::verifyREG(int REGaddr, int REGval) {
// Inhalt von REG pruefen
// REG = 1..8
   bool stat = false;
   StatusBar1->Panels->Items[3]->Text = "Register Mode";
   msgBox->Caption = sz_Verify;
   msgBox->lbMsg->Caption = "";
   if(iRetryCount==-1)
      iRetryCount=iRetryOnError;
   if(REGaddr>0 && REGval>-1) {
      msgBox->lbMsg->Caption =
         "Verify R" + IntToStr(REGaddr) + "=" + IntToStr(REGval);
      LocoDetector->Suspend();
      stat = protocol_nmra_sm_verify_phregister(REGaddr, REGval);
      LocoDetector->Resume();
   }
   StatusBar1->Panels->Items[3]->Text = "";
   Application->ProcessMessages();
   return stat;
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyCVnum(TObject *Sender)
{
   TEdit *ef = (TEdit *)Sender;
   chkIntVal(ef,1,1024,false);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyShortAddress(TObject *Sender)
{
   TEdit *ef = (TEdit *)Sender;
   chkIntVal(ef,1,127,false);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyLongAddress(TObject *Sender)
{
   TEdit *ef = (TEdit *)Sender;
   if(chkIntVal(ef,0,10239,true)>0)
      chkIntVal(ef,128,10239,false);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyConsistAddress(TObject *Sender)
{
   TEdit *ef = (TEdit *)Sender;
   chkIntVal(ef,0,127,false);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyCommonVariable(TObject *Sender)
{
   TEdit *ef = (TEdit *)Sender;
   chkIntVal(ef,0,255,false);
}
//---------------------------------------------------------------------------

TObject * __fastcall TmainForm::getControlByName(String compName) {
// gibt einen Zeiger auf ein Object mit dem Namen <compName> zur�ck
// oder NULL, wenn das nicht existiert
   int i=0;
   while(i<mainForm->ComponentCount && (mainForm->Components[i]->Name!=compName))
      ++i;
   if(i<mainForm->ComponentCount)
      return (TObject *)mainForm->Components[i];
   return (TObject *)NULL;
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::enableEntryLabel(int cv) {
   String efName = "efCV" + IntToStr(cv);
   String lbName = "lbCV" + IntToStr(cv);
   TEdit *edit;
   TLabel *label;
   if(NULL!=(edit=(TEdit *)getControlByName(efName))) {
      if(usedCVs[cv-1]) {
         edit->Color=clWindow;
         edit->Enabled = true;
         if(CVs[cv-1]!=-1)
            edit->Text = IntToStr(CVs[cv-1]);
      }
      else {
         edit->Text = "";
         edit->Enabled = false;
         edit->Color = clGrayText;
      }
   }
   if(NULL!=(label=(TLabel *)getControlByName(lbName))) {
      if(usedCVs[cv-1])
         label->Enabled = true;
      else
         label->Enabled = false;
   }
}

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
#include "basis.cpp"
#include "function.cpp"
#include "speed.cpp"
#include "more.cpp"
#include "single.cpp"
#include "complete.cpp"
#include "register.cpp"
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmHelpInhaltClick(TObject *Sender)
{
   Application->HelpCommand(15, -3);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::mmHelpIndexClick(TObject *Sender)
{
   Application->HelpCommand(15, -2);
}
//---------------------------------------------------------------------------

int __fastcall TmainForm::errMsg(String msg, int cv) {
   char buf[1024];
   if(!cancelled) {
      sprintf(buf, "CV %d: %s", cv, sg1_1024->Cells[1][cv]);
      if(iRetryOnError==-1) // keine Wiederholungen
         return Application->MessageBox(buf, ("Fehler beim " + msg).c_str(),
                                        MB_ABORTRETRYIGNORE);
      else  { // wiederholen, wenn ein Fehler aufgetreten ist
              // oder in Fehlerliste eintragen
         if(iRetryCount==0) {
            if(faultListe->lbErrors->Count==0)
               faultListe->Caption="Fehlerliste vom " + msg;
            try {
               faultListe->lbErrors->Items->Add((String)buf);
            }
            catch(Exception *E) {
               return Application->MessageBox(buf,
                     ("zu viele Fehler beim " + msg).c_str(),
                      MB_ABORTRETRYIGNORE);
            }
            return IDIGNORE;
         }
         else
            return IDRETRY;
      }
   }
   else
      return IDABORT;
}
//---------------------------------------------------------------------------
int __fastcall TmainForm::errControl(int answer, int i) {
   switch(answer) {
      default:
      case IDIGNORE: iRetryCount=-1; i++; break;
      case IDRETRY: iRetryCount--; break;
      case IDABORT: iRetryCount=-1; cancelled=true; break;
   }
   return i;
}

//---------------------------------------------------------------------------


