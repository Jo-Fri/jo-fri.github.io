//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ri.h"
#pragma package(smart_init)
#include "tolop_main.h"
#include "nmra_sm.h"

#pragma package(smart_init)
extern TmainForm *mainForm;
TRingIndikator *RingIndikator;
//---------------------------------------------------------------------------

//   Wichtig: Methoden und Eigenschaften von Objekten der VCL k�nnen nur
//   in Methoden verwendet werden, die Synchronize aufrufen, z.B.:
//
//      Synchronize(UpdateCaption);
//
//   wobei UpdateCaption so aussehen k�nnte:
//
//      void __fastcall TRingIndikator::UpdateCaption()
//      {
//        Form1->Caption = "In Thread aktualisiert";
//      }
//---------------------------------------------------------------------------

__fastcall TRingIndikator::TRingIndikator(bool CreateSuspended)
   : TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
void TRingIndikator::SetName()
{
   THREADNAME_INFO info;
   info.dwType = 0x1000;
   info.szName = "RingIndikator";
   info.dwThreadID = -1;
   info.dwFlags = 0;

   __try
   {
       RaiseException( 0x406D1388, 0, sizeof(info)/sizeof(DWORD),(DWORD*)&info );
   }
   __except (EXCEPTION_CONTINUE_EXECUTION)
   {
   }
}
//---------------------------------------------------------------------------
void __fastcall TRingIndikator::Execute()
{
   SetName();
   while(!Terminated) {
      if(mainForm->ComPort1->Connected)
         mainForm->AckDetected |=
            (mainForm->ComPort1->Signals() != TComSignals()<<csRing);
      else
         mainForm->AckDetected = false;
   }
}
//---------------------------------------------------------------------------
