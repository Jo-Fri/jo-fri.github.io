//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "errors.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfaultListe *faultListe;

#include "tolop_main.h"
extern TmainForm *mainForm;
//---------------------------------------------------------------------------
__fastcall TfaultListe::TfaultListe(TComponent* Owner)
   : TForm(Owner)
{
   mainForm->loadFormCaptions(mainForm->szLanguage, faultListe);
}
//---------------------------------------------------------------------------
void __fastcall TfaultListe::pbCloseClick(TObject *Sender)
{
   faultListe->lbErrors->Clear();
   faultListe->Hide();
}
//---------------------------------------------------------------------------
