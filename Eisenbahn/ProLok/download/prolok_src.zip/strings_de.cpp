// Texte f�r die Anzeigen
void __fastcall TmainForm::setTextRessources(String lang) {
   if(lang=="deutsch" || lang=="") {
      loadGermanStrings();
      for(int i=0;i<Screen->FormCount;++i)
         loadGermanCaptions(Screen->Forms[i]->Name);
   }
   else
      loadLangFile(lang + ".lng");
   makeCV1_1024Headers();
   Application->ProcessMessages();
}

void __fastcall TmainForm::loadLangFile(String Name)
{
      String *strings[] = {
         &sz_ProgDev,&sz_noProgDev,&sz_Loco,&sz_noLoco,
         &sz_ProgTrk,&sz_noProgTrk,&sz_wait,&sz_Simple,
         &sz_All,&sz_Mini,&sz_Add,&sz_mmEntryName,&sz_Cancel,
         &sz_Read,&sz_Write,&sz_Verify,&sz_unknown,&sz_HardErr,
         &sz_Error,&sz_save,&sz_noPort,&sz_IniWrErr,&sz_WrDecErr,
         &sz_WrLogErr,&sz_File,&sz_noPortAccess,&sz_OutOfMem,
         &sz_BitmapDesc,&sz_InputValFormat,&sz_Numeric,
         &sz_Confirm, &sz_FactoryReset, &sz_Success,
         &sz_Wrong, &sz_Correct, &sz_NACK, &sz_Fail,
         &sz_Description, &sz_Value };
      String nameOfVar[] = {
         "ProgDev","noProgDev","Loco","noLoco",
         "ProgTrk","noProgTrk","wait","Simple",
         "All","Mini","Add","mmEntryName","Cancel",
         "Read","Write","Verify","unknown","HardErr",
         "Error","save","noPort","IniWrErr","WrDecErr",
         "WrLogErr","File","noPortAccess","OutOfMem",
         "BitmapDesc","InputValFormat","Numeric",
         "Confirm", "FactoryReset", "Success",
         "Wrong", "Correct", "NACK", "Fail",
         "Description", "Value" };

  int i,len = sizeof(strings)/sizeof(strings[0]);
  String temp;
  try{
    TMemIniFile *pLangFile = new TMemIniFile(Name);
    for(i=0;i<len;++i) {
      if((temp=pLangFile->ReadString("Strings", nameOfVar[i],""))>"")
         *strings[i]=temp;
    }
    loadInternationalCaptions(pLangFile);
    delete pLangFile;
  }
  catch(...) {
  }
}

void __fastcall TmainForm::loadGermanStrings()
{
      sz_ProgDev    = "Programmierger�t erkannt";
      sz_noProgDev  = "kein Programmierger�t";
      sz_Loco       = "Lok erkannt";
      sz_noLoco     = "keine Lok";
      sz_ProgTrk    = "Programmiergleis erkannt";
      sz_noProgTrk  = "kein Programmiergleis";
      sz_wait       = "Einen Moment, bitte";
      sz_Simple     = "einfach";
      sz_All        = "alle";
      sz_Mini       = "minimal";
      sz_Add        = "Hinzuf�gen als";
      sz_mmEntryName= "Bitte geben Sie einen Namen f�r den Eintrag an";
      sz_Cancel     = "Abbruch";
      sz_Read       = "Lesen";
      sz_Write      = "Schreiben";
      sz_Verify     = "Pr�fen";
      sz_unknown    = "unbekannt";
      sz_HardErr    = "Hardware-Fehler";
      sz_Error      = "Fehler";
      sz_save       = "Sichern";
      sz_noPort     = "kein Port";
      sz_IniWrErr   = "Die Datei prolok.ini wurde nicht geschrieben";
      sz_WrDecErr   = "Decoder-Datei konnte nicht geschrieben werden";
      sz_WrLogErr   = "Fehler beim Schreiben des Log";
      sz_File       = "Datei";
      sz_noPortAccess="kein Zugriff auf den Com-Port";
      sz_OutOfMem   = "Nicht genug Speicher";
      sz_BitmapDesc = "f�r die Bitmap-Beschreibung";
      sz_InputValFormat = "Bitte nur Werte von %d bis %d eingeben";
      sz_Numeric    = "Bitte nur Zahlen eingeben";
      sz_Success    = "Erfolgreich";
      sz_FactoryReset = (String)("Wollen Sie wirklich den Dekoder zur�cksetzten?\n")+
                        (String)("Alle Variablen, incl. der individuellen Kennlinie\n")+
                        (String)("in den CV67-94 sowie die User-IDs in CV105 und 106,\n")+
                        (String)("werden auf die Werks-Voreinstellung zur�ckgesetzt.\n")+
                        (String)("Diese Funktion ist experimentell. Evtl. treten nicht\n")+
                        (String)("die gew�nschten Ergebnisse ein\n")+
                        (String)("Fortfahren?");
      sz_Confirm    = "Best�tigung";
      sz_NACK       = "keine Quittung";
      sz_Correct    = "richtig";
      sz_Wrong      = "falsch";
      sz_Fail       = "fehlgeschlagen";
      sz_Value      = "Wert";
      sz_Description= "Beschreibung";
}


void __fastcall TmainForm::loadGermanCaptions(String form)
{
	if(form=="mainForm") {
      mainForm->Caption="LokProgrammer";
   	mainForm->tsBasis->Caption="&Basis";
   	mainForm->lbCV8->Caption="CV8 Hersteller";
   	mainForm->lbCV7->Caption="CV7 Version";
   	mainForm->lbCV1->Caption="CV1 Basisadresse";
   	mainForm->lbCV2->Caption="CV2 Vmin";
   	mainForm->lbCV5->Caption="CV5 Vmax";
   	mainForm->lbCV6->Caption="CV6 Vmittel";
   	mainForm->lbCV3->Caption="CV3 Beschleunigung";
   	mainForm->lbCV4->Caption="CV4 Verz�gerung";
   	mainForm->lbCV17_18->Caption="CV17+18 lange Adresse";
   	mainForm->lbCV9->Caption="CV9 PWM-Frequenz";
   	mainForm->lbCV19->Caption="CV19 Mehrfachtraktions-Adresse";
   	mainForm->lbCV105->Caption="CV105 UserID1";
   	mainForm->lbCV106->Caption="CV106 UserID2";
   	mainForm->gbCV29->Caption="CV29 Konfiguration";
   	mainForm->lbCV29->Caption="CV29 dezimal";
   	mainForm->CV29b0->Caption="Bit0 Fahrtrichtung revers";
	   mainForm->CV29b1->Caption="Bit1 28/128 Fahrstufen";
	   mainForm->CV29b2->Caption="Bit2 erlaube Analogbetrieb";
	   mainForm->CV29b3->Caption="Bit3 bidirektionale Kommunikation";
   	mainForm->CV29b4->Caption="Bit4 indiv. V-Tabelle benutzen";
   	mainForm->CV29b5->Caption="Bit5 nutze Adresse in CV17+18";
   	mainForm->CV29b6->Caption="Bit6 reserviert";
   	mainForm->CV29b7->Caption="Bit7 Funktionsdekoder";
   	mainForm->CV19b7->Caption="CV19 Bit7 Mehrfachtraktion Fahrtrichtung revers";
   	mainForm->tsFunction->Caption="&Funktionen";
   	mainForm->pbDefaultFunctionMapping->Caption="Defaultwerte setzen";
   	mainForm->tsSpeedTab->Caption="&Geschwindigkeitstabelle";
   	mainForm->lbCV65->Caption="CV65 Kickstart";
   	mainForm->lbCV66->Caption="CV66 Trimmwert vorw�rts";
   	mainForm->lbCV95->Caption="CV95 Trimmwert r�ckw�rts";
   	mainForm->gbSpeed->Caption="Fahrstufentabelle CV67=FS1..CV94=FS28";
   	mainForm->pbCalculate->Caption="Kennlinie berechnen";
   	mainForm->pbDelSpeedTable->Caption="Kennlinie l�schen";
   	mainForm->tsMore->Caption="&weitere CV";
   	mainForm->lbDesc->Caption="Beschreibung";
   	mainForm->lbVal->Caption="Wert";
   	mainForm->rbDecimal->Caption="dezimal";
   	mainForm->rbBitmap->Caption="Bitmap";
   	mainForm->tsSingleCV->Caption="&einzelne CV";
   	mainForm->gbCVval->Caption="Wert";
   	mainForm->lbDec->Caption="dezimal";
   	mainForm->lbHex->Caption="hexadezimal";
   	mainForm->gbCVbin->Caption="Bin�r";
   	mainForm->pbHardReset->Caption="Dekoder-Reset";
   	mainForm->tsRegister->Caption="&Register";
   	mainForm->descR1->Caption="kurze Adresse (CV1mainForm->, 1..127";
   	mainForm->lbReg->Caption="Register";
   	mainForm->lbRegVal->Caption="Wert";
   	mainForm->lbRegDesc->Caption="Inhalt";
   	mainForm->descR2->Caption="Anfahrspannung (CV2), 0..255";
   	mainForm->descR3->Caption="Anfahrverz�gerung (CV3), 0..255";
   	mainForm->descR4->Caption="Bremsverz�gerung (CV4), 0..255";
   	mainForm->descR5->Caption="Konfiguration (CV29)";
   	mainForm->descR7->Caption="Versionsnummer (CV7), R/O";
   	mainForm->descR8->Caption="Hersteller-ID (CV8), R/O";
   	mainForm->pbRead->Caption="&Lesen";
   	mainForm->pbVerify->Caption="&Pr�fen";
   	mainForm->pbWrite->Caption="&Schreiben";
   	mainForm->mmFile->Caption="&Datei";
   	mainForm->mmLoad->Caption="&Laden";
   	mainForm->mmSave->Caption="&Sichern";
   	mainForm->mmSaveAs->Caption="S&ichern als";
   	mainForm->mmExit->Caption="&Beenden";
   	mainForm->mmDecoder->Caption="De&coder";
	   mainForm->mmNew->Caption="Neu";
	   mainForm->mmNewMini->Caption="minimal";
	   mainForm->mmNewExtended->Caption="einfach";
	   mainForm->mmNewAll->Caption="alle";
	   mainForm->mmChange->Caption="�ndern";
	   mainForm->mmAdd->Caption="Hinzuf�gen";
	   mainForm->mmRemove->Caption="L�schen";
	   mainForm->mmScan->Caption="Scan";
	   mainForm->mmSetup->Caption="E&instellungen";
	   mainForm->mmHelp->Caption="&Hilfe";
	   mainForm->mmHelpInhalt->Caption="Inhalt";
	   mainForm->mmHelpIndex->Caption="Index";
	   mainForm->mmAbout->Caption="�ber ProLok";
   }

	if(form=="setupForm") {
      setupForm->Caption="Einstellungen";
	   setupForm->lbPort->Caption="Anschlu�";
	   setupForm->lbWait->Caption="Warteschleife";
	   setupForm->lblBulk->Caption="Anzahl der Wiederholungen";
	   setupForm->pbOK->Caption="Speichern";
	   setupForm->pbCancel->Caption="Widerrufen";
	   setupForm->pbSetupHelp->Caption="Hilfe";
	   setupForm->gbSetupDecoderMode->Caption="Decoder-Programmiermodus";
	   setupForm->cbDirectMode->Caption="direkt";
	   setupForm->cbPageMode->Caption="CV";
	   setupForm->cbAutoMode->Caption="auto";
	   setupForm->cbUSBserial->Caption="USB-Seriell-Adapter";
	   setupForm->cbSafeMode->Caption="Pr�fen nach Lesen und Schreiben";
	   setupForm->cbTest0Bit->Caption="Bit auf 0 und 1 pr�fen";
	   setupForm->cbIs6604->Caption="erweiterter Power-On-Zyklus";
	   setupForm->cbBulk->Caption="Stapelmodus";
	   setupForm->gbSetupHardware->Caption="Programmierger�t";
	   setupForm->lbl_Lang->Caption="Sprache";
	   setupForm->rbIsDDL->Caption="Booster + Quittungsdetektor-Schaltung";
	   setupForm->rbIsPR1->Caption="Digitrax PR-1 oder DECPROG";
   }

   if(form=="scanForm") {
      scanForm->Caption="Decoder Scan";
   	scanForm->gbRange->Caption="CV-Bereiche";
   	scanForm->lbFrom->Caption="von";
   	scanForm->lbTo->Caption="bis";
   	scanForm->pbClose->Caption="Schlie�en";
   	scanForm->pbScan->Caption="Scannen";
   	scanForm->pbCancel->Caption="Abbruch";
   }

	if(form=="formRemove") {
   	formRemove->Caption="Profil entfernen";
   	formRemove->pbRemove->Caption="Entfernen";
   	formRemove->pbCancel->Caption="Abbruch";
   }

	if(form=="aboutBox")
	   aboutBox->Caption="�ber ProLok";

	if(form=="faultListe") {
      faultListe->Caption="Fehlerliste";
	   faultListe->lbHeadLine->Caption="Die angeforderte Operation konnte in den nachfolgend aufgef�hrten CV nicht korrekt ausgef�hrt werden:";
	   faultListe->pbClose->Caption="Fenster s&chlie�en";
   }
}

void __fastcall TmainForm::loadInternationalCaptions(TMemIniFile *pF)
{
   int i;
   for(i=0;i<Screen->FormCount;++i)
      loadCaptions(pF, Screen->Forms[i]);
}

void __fastcall TmainForm::loadCaptions(TMemIniFile *pF, TForm *form)
{
   int j;
   String temp;
   String classname;
   String section;
   String value;

   section = form->Name;
   temp=((TMemIniFile *)pF)->ReadString(section,"Caption","");
   if(temp>"")
      form->Caption=temp;
   for(j=0;j<form->ComponentCount;++j) {
      classname=(String)(form->Components[j]->ClassName());
      value=form->Components[j]->Name;
      temp=((TMemIniFile *)pF)->ReadString(section,value,"");
      if(temp>"") {
         if(classname=="TLabel")
            ((TLabel *)form->Components[j])->Caption = temp;
         else if(classname=="TButton")
            ((TButton *)form->Components[j])->Caption = temp;
         else if(classname=="TGroupBox")
            ((TGroupBox *)form->Components[j])->Caption = temp;
         else if(classname=="TRadioButton")
            ((TRadioButton *)form->Components[j])->Caption = temp;
         else if(classname=="TCheckBox")
            ((TCheckBox *)form->Components[j])->Caption = temp;
         else if(classname=="TMenuItem")
            ((TMenuItem *)form->Components[j])->Caption = temp;
         else if(classname=="TTabSheet")
            ((TTabSheet *)form->Components[j])->Caption = temp;
      }
   }
}


void __fastcall TmainForm::loadFormCaptions(String lang, TForm *form)
{
   if(lang=="deutsch" || lang=="")
      loadGermanCaptions(form->Name);
   else {
      try {
         TMemIniFile *pF = new TMemIniFile(lang + ".lng");
         loadCaptions(pF, form);
         delete pF;
      }
      catch(...) {
      }
   }
}
