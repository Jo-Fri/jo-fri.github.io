//---------------------------------------------------------------------------

#ifndef removeH
#define removeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TformRemove : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TListBox *lbProfiles;
   TButton *pbRemove;
   TButton *pbCancel;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall pbCancelClick(TObject *Sender);
   void __fastcall pbRemoveClick(TObject *Sender);
private:	// Anwender-Deklarationen
public:		// Anwender-Deklarationen
   __fastcall TformRemove(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TformRemove *formRemove;
//---------------------------------------------------------------------------
#endif
