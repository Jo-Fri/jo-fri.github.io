//===========================================================================

void __fastcall TmainForm::tsSpeedTabShow(TObject *Sender)
{
   enterTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::tsSpeedTabHide(TObject *Sender)
{
   exitTabSheet((TTabSheet *)Sender);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::loadSpeedTab()
{
   TLabel *labels[] = {cv65ok,cv66ok,cv67ok,cv68ok,cv69ok,
                     cv70ok,cv71ok,cv72ok,cv73ok,cv74ok,
                     cv75ok,cv76ok,cv77ok,cv78ok,cv79ok,
                     cv80ok,cv81ok,cv82ok,cv83ok,cv84ok,
                     cv85ok,cv86ok,cv87ok,cv88ok,cv89ok,
                     cv90ok,cv91ok,cv92ok,cv93ok,cv94ok,
                     cv95ok};
   int i, cv, l=sizeof(labels)/sizeof(labels[0]);
   for(i=0;i<l;i++) {
      labels[i]->Visible = false;
      enableEntryLabel(i+65);
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::saveSpeedTab()
{
   TEdit *edits[]  = {efCV65, efCV66, efCV67, efCV68, efCV69,
                      efCV70, efCV71, efCV72, efCV73, efCV74,
                      efCV75, efCV76, efCV77, efCV78, efCV79,
                      efCV80, efCV81, efCV82, efCV83, efCV84,
                      efCV85, efCV86, efCV87, efCV88, efCV89,
                      efCV90, efCV91, efCV92, efCV93, efCV94,
                      efCV95};

   int i, cv, l=sizeof(edits)/sizeof(edits[0]);
   for(i=0;i<l;i++){
      if(edits[i]->Enabled && edits[i]->Text!="") {
         CVs[i+64] = StrToInt(edits[i]->Text);
         sg1_1024->Cells[2][i+65] = IntToStr(CVs[i+64]);
      }
   }
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::writeSpeedTab()
// alle Werte aus Formular 'Geschwindigkeitstabelle' schreiben
{
   TLabel *labels[] = {cv65ok,cv66ok,cv67ok,cv68ok,cv69ok,
                     cv70ok,cv71ok,cv72ok,cv73ok,cv74ok,
                     cv75ok,cv76ok,cv77ok,cv78ok,cv79ok,
                     cv80ok,cv81ok,cv82ok,cv83ok,cv84ok,
                     cv85ok,cv86ok,cv87ok,cv88ok,cv89ok,
                     cv90ok,cv91ok,cv92ok,cv93ok,cv94ok,
                     cv95ok};
   TEdit *edits[] = {efCV65, efCV66, efCV67, efCV68, efCV69,
                      efCV70, efCV71, efCV72, efCV73, efCV74,
                      efCV75, efCV76, efCV77, efCV78, efCV79,
                      efCV80, efCV81, efCV82, efCV83, efCV84,
                      efCV85, efCV86, efCV87, efCV88, efCV89,
                      efCV90, efCV91, efCV92, efCV93, efCV94,
                      efCV95};
   int cv, i, a, l=sizeof(labels)/sizeof(labels[0]);
   for(i=0;i<l;i++)
      labels[i]->Visible = false;
   i=0;
   while(!cancelled && i<l) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[i+64]) {
         cv = testIntVal(edits[i]->Text,0,255,true);
         if(setCV(i+65,cv))
            labels[i]->Visible=true;
         else {
            labels[i]->Visible=false;
            a=errMsg("Schreiben",i+65);
         }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}

//---------------------------------------------------------------------------
void __fastcall TmainForm::readSpeedTab()
// alle Werte aus Formular 'Geschwindigkeitstabelle' lesen
{
   TLabel *labels[] = {cv65ok,cv66ok,cv67ok,cv68ok,cv69ok,
                     cv70ok,cv71ok,cv72ok,cv73ok,cv74ok,
                     cv75ok,cv76ok,cv77ok,cv78ok,cv79ok,
                     cv80ok,cv81ok,cv82ok,cv83ok,cv84ok,
                     cv85ok,cv86ok,cv87ok,cv88ok,cv89ok,
                     cv90ok,cv91ok,cv92ok,cv93ok,cv94ok,
                     cv95ok};
   TEdit * edits[] = {efCV65, efCV66, efCV67, efCV68, efCV69,
                      efCV70, efCV71, efCV72, efCV73, efCV74,
                      efCV75, efCV76, efCV77, efCV78, efCV79,
                      efCV80, efCV81, efCV82, efCV83, efCV84,
                      efCV85, efCV86, efCV87, efCV88, efCV89,
                      efCV90, efCV91, efCV92, efCV93, efCV94,
                      efCV95};

   int i, a, cv, l=sizeof(edits)/sizeof(edits[0]);
   for(i=0;i<l;i++) {
      labels[i]->Visible = false;
      edits[i]->Text = "";
   }
   i=0;
   while(!cancelled && i<l) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[i+64]) {
         if(getCV(i+65)) {
            edits[i]->Text = IntToStr(CVs[i+64]);
            labels[i]->Visible = true;
         }
         else {
            edits[i]->Text = "";
            a=errMsg("Lesen",i+65);
         }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::verifySpeedTab() {
   TLabel *labels[] = {cv65ok,cv66ok,cv67ok,cv68ok,cv69ok,
                     cv70ok,cv71ok,cv72ok,cv73ok,cv74ok,
                     cv75ok,cv76ok,cv77ok,cv78ok,cv79ok,
                     cv80ok,cv81ok,cv82ok,cv83ok,cv84ok,
                     cv85ok,cv86ok,cv87ok,cv88ok,cv89ok,
                     cv90ok,cv91ok,cv92ok,cv93ok,cv94ok,
                     cv95ok};
   TEdit *edits[] = {efCV65, efCV66, efCV67, efCV68, efCV69,
                      efCV70, efCV71, efCV72, efCV73, efCV74,
                      efCV75, efCV76, efCV77, efCV78, efCV79,
                      efCV80, efCV81, efCV82, efCV83, efCV84,
                      efCV85, efCV86, efCV87, efCV88, efCV89,
                      efCV90, efCV91, efCV92, efCV93, efCV94,
                      efCV95};
   int cv, i, a, l=sizeof(labels)/sizeof(labels[0]);
   for(i=0;i<l;i++)
      labels[i]->Visible = false;
   i=0;
   while(!cancelled && i<l) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[i+64]) {
        if((cv=chkIntVal(edits[i],0,255,true))!=-1) {
            if(verifyCV(i+65, cv))
               labels[i]->Visible = true;
            else {
               labels[i]->Visible=false;
               a=errMsg("Pr�fen",i+65);
            }
        }
      }
      i=errControl(a,i);
   }
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::pbCalculateClick(TObject *Sender)
{
   TEdit *edits[] = { efCV67, efCV68, efCV69,
                      efCV70, efCV71, efCV72, efCV73, efCV74,
                      efCV75, efCV76, efCV77, efCV78, efCV79,
                      efCV80, efCV81, efCV82, efCV83, efCV84,
                      efCV85, efCV86, efCV87, efCV88, efCV89,
                      efCV90, efCV91, efCV92, efCV93, efCV94 };
   int i, e, n, cvmin, cvmax, step, rstep, faktor,
       l=sizeof(edits)/sizeof(edits[0]);
   i = 1;
   e = 0;
   if((cvmin=chkIntVal(edits[0],0,255,true))==-1) {
      cvmin = 1;
      edits[0]->Text = IntToStr(cvmin);
   }
   cvmax = -1;
   while(i<l) {
      while(i<l && cvmax==-1)
         if((cvmax=chkIntVal(edits[i],0,255,true))==-1) i++;
      if(i>e) {
         n = i-e;
         if(i<l) i++;
         else     cvmax = 255;
         step = (cvmax - cvmin) / n;
         rstep = (cvmax - cvmin) % n;
         for(n=e+1;n<i;n++) {
            cvmin += step;
            if(rstep<0) cvmin--;
            if(rstep>0) cvmin++;
            if(rstep!=0)
               rstep = rstep>0? rstep-1 : rstep+1;
            if(edits[n]->Enabled)
               edits[n]->Text = IntToStr(cvmin);
         }
      }
      e=i-1;
      cvmax = -1;
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::pbDelSpeedTableClick(TObject *Sender)
{
   TEdit * edits[] = {efCV67, efCV68, efCV69,
                      efCV70, efCV71, efCV72, efCV73, efCV74,
                      efCV75, efCV76, efCV77, efCV78, efCV79,
                      efCV80, efCV81, efCV82, efCV83, efCV84,
                      efCV85, efCV86, efCV87, efCV88, efCV89,
                      efCV90, efCV91, efCV92, efCV93, efCV94 };

   int i, cv, l=sizeof(edits)/sizeof(edits[0]);
   for(i=0;i<l;i++)
      if(edits[i]->Enabled)
         edits[i]->Text="";
}
//---------------------------------------------------------------------------
