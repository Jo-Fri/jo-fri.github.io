/***************************************************************/
/* erddcd - Electric Railroad Direct Digital Command Daemon    */
/*    generates without any other hardware digital commands    */
/*    to control electric model railroads                      */
/*                                                             */
/* original file: nmra.c                                       */
/* job : implements routines to compute data for the           */
/*       NMRA-DCC protocol and send this data to               */
/*       the serial device.                                    */
/*                                                             */
/* Torsten Vogt, may 1999                                      */
/* vogt@vogt-it.com                                            */
/*                                                             */
/*																			      */
/* Gek�rzt durch Th. Borrmann, thomas@borrmanns.de 	   	 	*/
/* da nur die �bersetzungstabellen gebraucht werden            */
/***************************************************************/

//---------------------------------------------------------------------------
#ifndef NMRAH
#define NMRAH
//---------------------------------------------------------------------------

#define PKTSIZE     40

int translateBitstream2Packetstream(char *Bitstream, char *Packetstream);

#endif
