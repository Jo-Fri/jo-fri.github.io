//---------------------------------------------------------------------------

#ifndef aboutH
#define aboutH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TaboutBox : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TImage *Image1;
   TLabel *lbAbout;
private:	// Anwender-Deklarationen
public:		// Anwender-Deklarationen
   __fastcall TaboutBox(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TaboutBox *aboutBox;
//---------------------------------------------------------------------------
#endif
