//---------------------------------------------------------------------------


#pragma hdrstop

#include "tolop_main.h"
#include "nmra.cpp"
#include "nmra_sm.h"
#include "ri.h"
//---------------------------------------------------------------------------
#ifndef STREAMSIZE
#define STREAMSIZE 4096
#endif

#pragma package(smart_init)
extern TmainForm *mainForm;
extern TRingIndikator *RingIndikator;

static char resetstream[PKTSIZE];
static int  rs_size = 0;
static char idlestream[PKTSIZE];
static int  is_size = 0;
static char pagepresetstream[PKTSIZE];
static int  ps_size = 0;

static char *longpreamble  = "111111111111111111111111111111";

static char reset_packet[] = "1111111111111111111111111111110000000000000000000000000001";
static char page_preset_packet[] = "1111111111111111111111111111110011111010000000010011111001";
static char idle_packet[] = "1111111111111111111111111111110111111110000000000111111111";
static char factory_reset_packet[] = "011111110000010000011101111";
//---------------------------------------------------------------------------

void __fastcall packet_init() {
	memset(resetstream, 0, PKTSIZE);
	rs_size=translateBitstream2Packetstream(reset_packet, resetstream);
	memset(idlestream, 0, PKTSIZE);
	is_size=translateBitstream2Packetstream(idle_packet, idlestream);
	memset(pagepresetstream, 0, PKTSIZE);
	ps_size=translateBitstream2Packetstream(page_preset_packet,pagepresetstream);
}
//---------------------------------------------------------------------------

void __fastcall xor_two_bytes(char *byte, char *byte1, char *byte2) {

   int i;

   strcpy(byte, "00000000");
   for (i=0; i<8; i++)
      *(byte+i)|= *(byte2+i)^ *(byte1+i);
}
//------------------------------------------------------------------------------
int __fastcall protocol_nmra_sm_direct_cvbyte(int cv, int value, int verify) {
   /* direct cv access */

   char byte2[9];
   char byte3[9];
   char byte4[9];
   char byte5[9];
   char bitstream[100];
   char packetstream[PKTSIZE];
   char PowerOnStream[STREAMSIZE];
   char SendStream[STREAMSIZE];
   char ResetStream[STREAMSIZE];
   int i,j,L,R,P;

   /* no special error handling, it's job of the clients */
   if (cv<0 || cv>1023 || value<0 || value>255) return 2;

   /* calculating byte3: AAAAAAAA (rest of CV#) */
   strcpy(byte3, "00000000");
   for (i=7; i>=0; i--) {
      j=cv%2;
      cv=cv/2;
      byte3[i] |= j;
   }

   /* calculating byte2: 011111AA (instruction byte1) */
   if (verify)
      strcpy(byte2, "01110100");
   else
      strcpy(byte2, "01111100");
   for (i=7; i>=6; i--) {
      j=cv%2;
      cv=cv/2;
      byte2[i] |= j;
   }

   /* calculating byte4: DDDDDDDD (data) */
   strcpy(byte4, "00000000");
   for (i=7; i>=0; i--) {
      j=value%2;
      value=value/2;
      byte4[i] |= j;
   }

   /* calculating byte5: EEEEEEEE (error detection byte) */
   memset(byte5, 0, 9);
   for (i=0; i<8; i++) {
     byte5[i] = (byte2[i] ^ byte3[i]) ^ byte4[i];
   }

   /* putting all together in a 'bitstream' (char array) */
   memset(bitstream, 0, 100);
   strcat(bitstream, longpreamble);
   strcat(bitstream, "0");
   strcat(bitstream, byte2);
   strcat(bitstream, "0");
   strcat(bitstream, byte3);
   strcat(bitstream, "0");
   strcat(bitstream, byte4);
   strcat(bitstream, "0");
   strcat(bitstream, byte5);
   strcat(bitstream, "1");

   j=translateBitstream2Packetstream(bitstream, packetstream);

   memset(PowerOnStream,0,STREAMSIZE);
   if(mainForm->bExtendedPowerOn) {
      for (P=0; P<50; P++) strcat(PowerOnStream, idlestream);
      for (P=0; P<25; P++) strcat(PowerOnStream, resetstream);
      P=50*is_size+25*rs_size;
   }
   else {
      for (P=0; P<20; P++) strcat(PowerOnStream, idlestream);
      for (P=0; P<5; P++) strcat(PowerOnStream, resetstream);
      P=20*is_size+5*rs_size;
   }


   memset(SendStream,0,STREAMSIZE);

   for (L=0; L<5; L++) strcat(SendStream, packetstream);
   L=5*j;

   memset(ResetStream,0,STREAMSIZE);
   if(!verify) {
        for (i=0; i<6; i++) strcat(SendStream, packetstream);
        L+=6*j;
        R=0;
   }
   else {
        strcat(ResetStream, resetstream);
        R=rs_size;
   }

   return ProcSM_Handshake(PowerOnStream,P,SendStream,L,ResetStream,R);
}

//----------------------------------------------------------------------------

int __fastcall protocol_nmra_sm_write_cvbyte(int cv, int value) {
   return protocol_nmra_sm_direct_cvbyte(cv, value, 0);
}
//----------------------------------------------------------------------------

int __fastcall protocol_nmra_sm_verify_cvbyte(int cv, int value) {
	return protocol_nmra_sm_direct_cvbyte(cv, value, 1);
}
//----------------------------------------------------------------------------

int __fastcall protocol_nmra_sm_verify_cvbit(int cv, int bit, int value) {
   // direct access: bit manipulation

   char byte2[9];
   char byte3[9];
   char byte4[9];
   char byte5[9];
   char bitstream[100];
   char packetstream[PKTSIZE];
   char PowerOnStream[STREAMSIZE];
   char SendStream[STREAMSIZE];
   char ResetStream[STREAMSIZE];
   int i,j,L,R,P;

   /* no special error handling, it's job of the clients */
   if (cv<0 || cv>1023 || bit<0 || bit>7 || value<0 || value>1) return 2;

   /* calculating byte3: AAAAAAAA (rest of CV#) */
   strcpy(byte3, "00000000");
   for (i=7; i>=0; i--) {
      j=cv%2;
      cv=cv/2;
      byte3[i] |= j;
   }

   /* calculating byte2: 011110AA (instruction byte1) */
   strcpy(byte2, "01111000");
   for (i=7; i>=6; i--) {
      j=cv%2;
      cv=cv/2;
      byte2[i] |= j;
   }

   /* calculating byte4: 111KDBBB (data) */
   memset(byte4, 0, 9);
   strcpy(byte4, "11100000");
   byte4[4] |= value;   // Data =0 | 1
   for (i=7; i>=5; i--) {
      j=bit%2;
      bit=bit/2;
      byte4[i] |= j;
   }

   /* calculating byte5: EEEEEEEE (error detection byte) */
   memset(byte5, 0, 9);
   for (i=0; i<8; i++) {
     byte5[i] = (byte2[i] ^ byte3[i]) ^ byte4[i];
   }

   /* putting all together in a 'bitstream' (char array) */
   memset(bitstream, 0, 100);
   strcat(bitstream, longpreamble);
   strcat(bitstream, "0");
   strcat(bitstream, byte2);
   strcat(bitstream, "0");
   strcat(bitstream, byte3);
   strcat(bitstream, "0");
   strcat(bitstream, byte4);
   strcat(bitstream, "0");
   strcat(bitstream, byte5);
   strcat(bitstream, "1");

   j=translateBitstream2Packetstream(bitstream, packetstream);
   memset(PowerOnStream,0,STREAMSIZE);
   memset(SendStream,0,STREAMSIZE);
   memset(ResetStream,0,STREAMSIZE);

   if(mainForm->bExtendedPowerOn) {
      for (P=0; P<50; P++) strcat(PowerOnStream, idlestream);
      for (P=0; P<25; P++) strcat(PowerOnStream, resetstream);
      P=50*is_size+25*rs_size;
   }
   else {
      for (P=0; P<20; P++) strcat(PowerOnStream, idlestream);
      for (P=0; P<5; P++) strcat(PowerOnStream, resetstream);
      P=20*is_size+5*rs_size;
   }

   for (L=0; L<5; L++) strcat(SendStream, packetstream);
   L=5*j;

   strcat(ResetStream, resetstream);
   R=rs_size;

   return ProcSM_Handshake(PowerOnStream,P,SendStream,L,ResetStream,R);
}

//----------------------------------------------------------------------------

int __fastcall protocol_nmra_sm_phreg(int reg,int value,bool verify) {
   /* physical register addressing */

   char byte1[9];
   char byte2[9];
   char byte3[9];
   char bitstream[100];
   char packetstream[PKTSIZE];
   char PowerOnStream[STREAMSIZE];
   char SendStream[STREAMSIZE];
   char ResetStream[STREAMSIZE];
   int i,j,l,R,P,L;

   /* no special error handling, it's job of the clients */
   if (reg<1 || reg>8 || value<0 || value>255) return 2;

   /* calculating byte1: 0111CRRR (instruction and nr of register) */
   memset(byte1, 0, 9);
   if (verify)
      strcpy(byte1,"01110");
   else
      strcpy(byte1,"01111");
   switch (reg) {
      case 1: strcat(byte1, "000"); break;
      case 2: strcat(byte1, "001"); break;
      case 3: strcat(byte1, "010"); break;
      case 4: strcat(byte1, "011"); break;
      case 5: strcat(byte1, "100"); break;
      case 6: strcat(byte1, "101"); break;
      case 7: strcat(byte1, "110"); break;
      case 8: strcat(byte1, "111"); break;
   }

   /* calculating byte2: DDDDDDDD (data) */
   strcpy(byte2, "00000000");
   for (i=7; i>=0; i--) {
      j=value%2;
      value=value/2;
      byte2[i] |= j;
   }

   /* calculating byte3 (error detection byte) */
   xor_two_bytes(byte3, byte1, byte2);

   /* putting all together in a 'bitstream' (char array) */
   memset(bitstream, 0, 100);
   strcat(bitstream, longpreamble);
   strcat(bitstream, "0");
   strcat(bitstream, byte1);
   strcat(bitstream, "0");
   strcat(bitstream, byte2);
   strcat(bitstream, "0");
   strcat(bitstream, byte3);
   strcat(bitstream, "1");

   memset(packetstream, 0, PKTSIZE);

   j=translateBitstream2Packetstream(bitstream, packetstream);

   memset(PowerOnStream,0,STREAMSIZE);
   memset(SendStream,0,STREAMSIZE);
   memset(ResetStream,0,STREAMSIZE);

   // 20xPowerOn, 3xReset, 5xPagePreset, 6xReset,
   if(mainForm->bExtendedPowerOn) {
      for (l=0; l<50; l++) strcat(PowerOnStream, idlestream);
      for (l=0; l<15; l++) strcat(PowerOnStream, resetstream);
      for (l=0; l<15; l++) strcat(PowerOnStream, pagepresetstream);
      for (l=0; l<15; l++) strcat(PowerOnStream, resetstream);
      P=50*is_size + 15*rs_size + 15*ps_size+15*rs_size;
   }
   else {
      for (l=0; l<20; l++) strcat(PowerOnStream, idlestream);
      for (l=0; l<3; l++) strcat(PowerOnStream, resetstream);
      for (l=0; l<5; l++) strcat(PowerOnStream, pagepresetstream);
      for (l=0; l<6; l++) strcat(PowerOnStream, resetstream);
      P=20*is_size + 3*rs_size + 5*ps_size+6*rs_size;
   }

   // 3xReset, 5x Write o. 7x Verify
   for (l=0; l<3; l++) strcat(SendStream, resetstream);
   L=3*rs_size;
   if (!verify) {
      // 5 write packets + 6 or more reset or identical write packets
      for (l=0; l<11; l++) strcat(SendStream, packetstream);
      L+=11*j;
      // 3 or more reset packets
      if (reg==1) {
         for (l=0; l<10; l++) strcat(ResetStream, resetstream);
         R=10*rs_size;
      }
      else  {
         for (l=0; l<6; l++) strcat(ResetStream, resetstream);
         R=6*rs_size;
      }
   }
   else {
      // 7 or more verify packets
      for (l=0; l<7; l++) strcat(SendStream, packetstream);
      L+=7*j;
      R=0;
   }
   return ProcSM_Handshake(PowerOnStream,P,SendStream,L,ResetStream,R);
}
//----------------------------------------------------------------------------

int __fastcall protocol_nmra_sm_write_phregister(int reg,int value) {
   return protocol_nmra_sm_phreg(reg,value,false);
}
//----------------------------------------------------------------------------

int __fastcall protocol_nmra_sm_verify_phregister(int reg,int value) {
   return protocol_nmra_sm_phreg(reg,value,true);
}

//----------------------------------------------------------------------------
int __fastcall protocol_nmra_sm_cvpaged(int cv, int value, bool verify) {
// cv = 0..1023, value=0..255, verify=true/false(write)
   char byte1[9];
   char byte2[9];
   char byte3[9];
   char bitstream[100];
   char packetstream[PKTSIZE];
   char pageselectstream[PKTSIZE];
   char PowerOnStream[STREAMSIZE];
   char SendStream[STREAMSIZE];
   char ResetStream[STREAMSIZE];
   int pagereg,datareg,i,j,k,l,R,P,L;

   /* no special error handling, it's job of the clients */
   if (cv<0 || cv>1023 || value<0 || value>255) return 2;

   // berechnet den PageRegister-Stream
   // byte1: 01111101 Schreibe nach Paging Register
   strcpy(byte1,"01111101");
   if(cv==28) {
      pagereg = 1;
      datareg = 5;
   }
   else {
      pagereg= (cv/4)+1;
      datareg = cv%4;
   }
   /* calculating byte2: DDDDDDDD (paging register) */
   strcpy(byte2, "00000000");
   for (i=7; i>=0; i--) {
      j=pagereg%2;
      pagereg=pagereg/2;
      byte2[i] |= j;
   }

   /* calculating byte3 (error detection byte) */
   xor_two_bytes(byte3, byte1, byte2);

   /* putting all together in a 'bitstream' (char array) */
   memset(bitstream, 0, 100);
   strcat(bitstream, longpreamble);
   strcat(bitstream, "0");
   strcat(bitstream, byte1);
   strcat(bitstream, "0");
   strcat(bitstream, byte2);
   strcat(bitstream, "0");
   strcat(bitstream, byte3);
   strcat(bitstream, "1");

   memset(pageselectstream, 0, PKTSIZE);
   k=translateBitstream2Packetstream(bitstream, pageselectstream);

   /* calculating byte1: 0111CRRR (instruction and nr of register) */
   memset(byte1, 0, 9);
   if (verify)
      strcpy(byte1,"01110");
   else
      strcpy(byte1,"01111");
   switch (datareg) {
      case 0: strcat(byte1, "000"); break;
      case 1: strcat(byte1, "001"); break;
      case 2: strcat(byte1, "010"); break;
      case 3: strcat(byte1, "011"); break;
      case 5: strcat(byte1, "100"); break;
   }

   /* calculating byte2: DDDDDDDD (data) */
   strcpy(byte2, "00000000");
   for (i=7; i>=0; i--) {
      j=value%2;
      value=value/2;
      byte2[i] |= j;
   }

   /* calculating byte3 (error detection byte) */
   xor_two_bytes(byte3, byte1, byte2);

   /* putting all together in a 'bitstream' (char array) */
   memset(bitstream, 0, 100);
   strcat(bitstream, longpreamble);
   strcat(bitstream, "0");
   strcat(bitstream, byte1);
   strcat(bitstream, "0");
   strcat(bitstream, byte2);
   strcat(bitstream, "0");
   strcat(bitstream, byte3);
   strcat(bitstream, "1");

   memset(packetstream, 0, PKTSIZE);
   j=translateBitstream2Packetstream(bitstream, packetstream);

   memset(PowerOnStream,0,STREAMSIZE);
   memset(SendStream,0,STREAMSIZE);
   memset(ResetStream,0,STREAMSIZE);

   // 20xPowerOn, 3xReset, 5xPageSelect, 6xReset, 3xReset
   // 5xWrite o. 7xVerify
   if(mainForm->bExtendedPowerOn) {
      for (l=0; l<50; l++) strcat(PowerOnStream, idlestream);
      for (l=0; l<15; l++) strcat(PowerOnStream, resetstream);
      for (l=0; l<15; l++) strcat(PowerOnStream, pageselectstream);
      for (l=0; l<20; l++) strcat(PowerOnStream, resetstream);
      P=50*is_size+ 15*rs_size + 15*k + 20*rs_size;
   }
   else {
      for (l=0; l<20; l++) strcat(PowerOnStream, idlestream);
      for (l=0; l<3; l++) strcat(PowerOnStream, resetstream);
      for (l=0; l<5; l++) strcat(PowerOnStream, pageselectstream);
      for (l=0; l<9; l++) strcat(PowerOnStream, resetstream);
      P=20*is_size+ 3*rs_size + 5*k + 9*rs_size;
   }


   if (!verify) {
      // 5+6 or more reset or identical write packets
      for (l=0; l<11; l++) strcat(SendStream, packetstream);
      // 6 or more reset or identical write packets
      L=11*j;

      // 3 or more reset packets
      if (cv==0) {
         // address==0->10 x Reset = recovery time
         for (l=0; l<10; l++) strcat(ResetStream, resetstream);
         R=10*rs_size;
      }
      else  {
         for (l=0; l<6; l++) strcat(ResetStream, resetstream);
         R=6*rs_size;
      }
      // Paging-Register wieder auf 1
      for (l=0; l<10; l++) strcat(ResetStream, pagepresetstream);
      for (l=0; l<10; l++) strcat(ResetStream, resetstream);
      R+=10*ps_size+10*rs_size;
   }
   else {
      for (l=0; l<5; l++) strcat(SendStream, packetstream);
      L=5*j;
      // Paging-Register wieder auf 1
      for (l=0; l<10; l++) strcat(ResetStream, pagepresetstream);
      for (l=0; l<10; l++) strcat(ResetStream, resetstream);
      R=10*ps_size+10*rs_size;
   }

   return ProcSM_Handshake(PowerOnStream,P,SendStream,L,ResetStream,R);
}

//----------------------------------------------------------------------------
int __fastcall protocol_nmra_sm_verify_cvpaged(int cv, int value) {
   return protocol_nmra_sm_cvpaged(cv,value,true);
}

//----------------------------------------------------------------------------
int __fastcall protocol_nmra_sm_write_cvpaged(int cv, int value) {
   return protocol_nmra_sm_cvpaged(cv,value,false);
}

//----------------------------------------------------------------------------

void __fastcall sendIdlePackets() {
   /* sendet 5 Idle-Pakete an den Port */

   char IdleStream[STREAMSIZE];
   int I;

   if(mainForm->ComPort1->Connected) {
	 	memset(IdleStream,0,STREAMSIZE);
	   for (I=0; I<5; I++)  strcat(IdleStream, idlestream);
   	I=5*is_size;
      mainForm->ComPort1->Write(IdleStream,I);
  }
	return;
}

//----------------------------------------------------------------------------
void __fastcall sendFactoryReset() {
   /* sendet NMRA-Factory-Reset */

   char bitstream[100];
   char packetstream[PKTSIZE];
   char FactoryResetStream[STREAMSIZE];
   int F,j;

   /* putting all together in a 'bitstream' (char array) */
   memset(bitstream, 0, 100);
   strcat(bitstream, longpreamble);
   strcat(bitstream, "0");
   strcat(bitstream, factory_reset_packet);
   strcat(bitstream, "1");

   j=translateBitstream2Packetstream(bitstream, packetstream);

   memset(FactoryResetStream,0,STREAMSIZE);
   for (F=0; F<20; F++) strcat(FactoryResetStream, idlestream);
   for (F=0; F<3; F++) strcat(FactoryResetStream, packetstream);
   for (F=0; F<10;F++) strcat(FactoryResetStream, resetstream);
   F=20*is_size+3*j+10*rs_size;

  if(mainForm->ComPort1->Connected)
      mainForm->ComPort1->Write(FactoryResetStream,F);
  return;
}

//----------------------------------------------------------------------------

int __fastcall ProcSM_Handshake(char* poweron, int po,
                                char* programming, int p,
                                char* reset, int r)
{
   int ack,cycles,i,n;
   ack = 0;
   // Warte bei schnellen Rechner, damit der Decoder mindestens 5ms
   // zum Reagieren hat
   while(GetTickCount()-mainForm->iWait<mainForm->iWaitXms);
   // verlaengert die Reaktionszeit
   cycles = mainForm->bUSBserial? 5 : 1;
   Application->ProcessMessages();
   if(mainForm->ComPort1->Connected) {
      if(mainForm->bLog)
         mainForm->addLog(GetTickCount()-mainForm->iWait,
            "Start ServiceModeInstruction");
      if(po>0) // power on
         mainForm->ComPort1->Write(poweron,po);
      if(mainForm->bIsDDL && mainForm->bProgTrack) {
         RingIndikator->Resume();
         Sleep(5);      // evtl. warten auf Resume-Ausf�hrung
      }
      Application->ProcessMessages();
      mainForm->AckDetected = false;
      n=cycles;
      do {
         if(p>0)  // programmiersequenz o. wiederholen
            mainForm->ComPort1->Write(programming,p);
         i = cycles*10;
         do {
            Application->ProcessMessages();
            if(mainForm->AckDetected) ack=1;
         } while(!ack && --i>0);
      } while(!ack && --n>0);
      // Detector ausschalten
      if(mainForm->bIsDDL && mainForm->bProgTrack)
         RingIndikator->Suspend();
      // sende 1 oder 6 x reset
      // auch wenn kein ACK, setzt das Page-Register zurueck
      if(r>0)
         mainForm->ComPort1->Write(reset,r);
      if(mainForm->bLog)
         mainForm->addLog(GetTickCount()-mainForm->iWait,
            "Ende ServiceModeInstruction, ack=" + IntToStr(ack) + "\n");
   }
   mainForm->iWait=GetTickCount();
   Application->ProcessMessages();
   return ack;
}


//----------------------------------------------------------------------------
