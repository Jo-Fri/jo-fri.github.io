//===========================================================================
// Seite tsSingleCV

void __fastcall TmainForm::tsSingleCVShow(TObject *Sender)
{  // Blatt 'einzelne CV' initialisieren
   exitTabSheet(tsActiveTabSheet);
   tsActiveTabSheet=tsSingleCV;
   lbMode->Caption = "";
   lbSuccess->Caption = "";
   resetCVbits();
   updnCV->Position = 1;
   efCV->Text = "1";
   showCVval(CVs[0],7);
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::updnCVClick(TObject *Sender, TUDBtnType Button)
{  // CV auf/ab-Rollfeld
   if(updnCV->Position == 1024)
      updnCV->Position = 1;
   if (updnCV->Position < 1)
      updnCV->Position = 1024;
   efCV->Text = IntToStr(updnCV->Position);
}
//---------------------------------------------------------------------------

void  __fastcall TmainForm::showCVval(int val, int dest) {
   // dest = 0 -> kein Objekt �ndern
   // dest = 1 -> efCVval �ndern
   // dest = 2 -> efCVhex �ndern
   // dest = 4 -> CVbit0..7 �ndern
   char x[4];
   if(dest) {
      if(val>-1) {
         if(dest & 1)
            efCVval->Text = IntToStr(val);
         if(dest & 2) {
            sprintf(x, "%2.2X\0", val);
            efCVHex->Text = (String)x;
         }
         if(dest & 4)
            setCVbits(val);
      }
      else { // CVval == -1
         if(dest & 1)
            efCVval->Text = "";
         if(dest & 2) {
            efCVHex->Text = "";
         }
         if(dest & 4) {
            resetCVbits();
         }
      }
   }
}

//---------------------------------------------------------------------------

void  __fastcall TmainForm::setCVbits(int val) {
// Bit-Checkboxen setzen lt. val
   int i;
   if(val != -1) {
      for(i=0; i<8; i++) {
        switch(i) {
           case 0: CVbit0->Checked = (val & 1); break;
           case 1: CVbit1->Checked = (val & 2); break;
           case 2: CVbit2->Checked = (val & 4); break;
           case 3: CVbit3->Checked = (val & 8); break;
           case 4: CVbit4->Checked = (val & 16); break;
           case 5: CVbit5->Checked = (val & 32); break;
           case 6: CVbit6->Checked = (val & 64); break;
           case 7: CVbit7->Checked = (val & 128); break;
        }
     }
   }
}

//---------------------------------------------------------------------------
int  __fastcall TmainForm::getCVbits() {
// Wert berechnen aus Bit-Checkbox
   int i;
   int val = 0;
   for(i=0; i<8; i++) {
     switch(i) {
        case 0: if(CVbit0->Checked) val |= 1; break;
        case 1: if(CVbit1->Checked) val |= 2; break;
        case 2: if(CVbit2->Checked) val |= 4; break;
        case 3: if(CVbit3->Checked) val |= 8; break;
        case 4: if(CVbit4->Checked) val |= 16; break;
        case 5: if(CVbit5->Checked) val |= 32; break;
        case 6: if(CVbit6->Checked) val |= 64; break;
        case 7: if(CVbit7->Checked) val |= 128; break;
     }
   }
   return val;
}
//---------------------------------------------------------------------------

void  __fastcall TmainForm::resetCVbits() {
// alle Bit-Checkboxes auf unchecked
   CVbit0->Checked = false;
   CVbit1->Checked = false;
   CVbit2->Checked = false;
   CVbit3->Checked = false;
   CVbit4->Checked = false;
   CVbit5->Checked = false;
   CVbit6->Checked = false;
   CVbit7->Checked = false;
}

//---------------------------------------------------------------------------


void __fastcall TmainForm::efCVChange(TObject *Sender) {
   int cv;
   // CV-Nummer im Eingabefeld wurde ge�ndert,
   // anpassen der Position des Up/Down Rollfeldes
   try {
      cv = StrToInt(efCV->Text);
      if(cv>0 && cv<1025) {
         updnCV->Position = cv;
         showCVval(CVs[cv-1],7);
      }
   }
   catch(Exception *E) {
   }
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::getSingleCV() {
// CV lesen, Seite: tsSingleCV
   int CVaddr = chkIntVal(efCV,1,1024,false);
   int CVval = -1;

   lbMode->Caption = sz_Read;
   lbSuccess->Caption = "";
   showCVval(CVval,7);
   if(getCV(CVaddr)) {
      CVval = CVs[CVaddr-1];
      lbSuccess->Caption = "OK";
   }
   else
      lbSuccess->Caption = sz_Fail;
   Application->ProcessMessages();
   showCVval(CVval,7);
   lbMode->Caption = "";
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::chkSingleCV() {
// CV pruefen, Seite: tsSingleCV
   int CVaddr = chkIntVal(efCV,1,1024,false);
   int CVval = chkIntVal(efCVval,0,255,false);

   lbSuccess->Caption = "";
   lbMode->Caption = sz_Verify;
   if(verifyCV(CVaddr,CVval))
      lbSuccess->Caption = sz_Correct;
   else
      lbSuccess->Caption = sz_Wrong;
   lbMode->Caption = "";
   Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::writeSingleCV() {
// CV schreiben, Seite: tsSingleCV
   int CVaddr = chkIntVal(efCV,1,1024,false);
   int CVval = chkIntVal(efCVval,0,255,false);

   lbSuccess->Caption = "";
   lbMode->Caption = sz_Write;
   if(setCV(CVaddr,CVval))
     lbSuccess->Caption = "OK";
   else
      lbSuccess->Caption = sz_NACK;
   Application->ProcessMessages();
   lbMode->Caption = "";
   Application->ProcessMessages();
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::efCVvalChange(TObject *Sender)
{  // Eingabefeld CVval wurde ge�ndert: Hex- und Bin�rdarstelung
   // anpassen
   int i = chkIntVal(efCVval,0,255,false);
   showCVval(i,6);
   efCVval->SelStart = (efCVval->Text).Length();
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::CVbitClick(TObject *Sender)
{  // Eine Bit-Checkbox wurde geklickt
   int i = getCVbits();
   showCVval(i,3);
}
//---------------------------------------------------------------------------

void __fastcall TmainForm::pbHardResetClick(TObject *Sender)
{  // Nachfrage vor Dekoder-Reset
   lbMode->Caption = "Reset";
   lbSuccess->Caption = "";
   unsigned long zeit;

   if(Application->MessageBox(sz_FactoryReset.c_str(),
                        sz_Confirm.c_str(),MB_YESNO)==ID_YES) {
      setCV(1,1);
      sendFactoryReset();        // Factory-Reset nach NMRA RP 9.2.3
      zeit = GetTickCount();
      while(verifyCV(8,255) && (GetTickCount()-zeit < 5000)) {
                                 // CV8 bleibt auf 255 bis der
         sendIdlePackets();      // Reset vollstaendig ausgefuehrt ist
         Application->ProcessMessages();
      }
      if(verifyCV(1,3))          // danach sollte die Adresse 3 sein
         lbSuccess->Caption = sz_Success;
      else {
         setCV(1, 0);   // cT: CV1=0 bedeutet: Power Conversion Mode!
         setCV(8, 33);  // Lenz: CV8=33
         setCV(8, 8);   // NMRA: CV8=8
         setCV(1, 3);   // NMRA: CV1=3
         if(verifyCV(1,3))          // danach sollte die Adresse 3 sein
            lbSuccess->Caption = sz_Success;
      }
   }
   lbMode->Caption = "";
   Application->ProcessMessages();
}

//===========================================================================
