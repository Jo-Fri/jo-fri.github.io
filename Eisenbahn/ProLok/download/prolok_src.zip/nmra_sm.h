//---------------------------------------------------------------------------

#ifndef nmra_smH
#define nmra_smH
//---------------------------------------------------------------------------

void __fastcall packet_init();
void __fastcall xor_two_bytes(char *byte, char *byte1, char *byte2);
void __fastcall sendIdlePackets();
void __fastcall sendFactoryReset();

int __fastcall protocol_nmra_sm_direct_cvbyte(int cv, int value, int verify);
int __fastcall protocol_nmra_sm_write_cvbyte(int cv, int value);
int __fastcall protocol_nmra_sm_verify_cvbyte(int cv, int value);

int __fastcall protocol_nmra_sm_verify_cvbit(int cv, int bit, int value);

int __fastcall protocol_nmra_sm_phreg(int reg,int value,bool verify);
int __fastcall protocol_nmra_sm_write_phregister(int reg,int value);
int __fastcall protocol_nmra_sm_verify_phregister(int reg,int value);

int __fastcall protocol_nmra_sm_cvpaged(int cv, int value, bool verify);
int __fastcall protocol_nmra_sm_verify_cvpaged(int cv, int value);
int __fastcall protocol_nmra_sm_write_cvpaged(int cv, int value);

// PowerON-String, L�nge des~
// Programmiersequenz, L�nge der~
// ResetString, L�nge des~
int __fastcall ProcSM_Handshake(char* poweron, int po,
                                 char* programming, int p,
                                 char* reset, int r);
//----------------------------------------------------------------------------
#endif
