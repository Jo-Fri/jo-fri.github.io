//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "about.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TaboutBox *aboutBox;

#include "tolop_main.h"
extern TmainForm *mainForm;

//---------------------------------------------------------------------------
__fastcall TaboutBox::TaboutBox(TComponent* Owner)
   : TForm(Owner)
{
   mainForm->loadFormCaptions(mainForm->szLanguage, aboutBox);
}
//---------------------------------------------------------------------------
