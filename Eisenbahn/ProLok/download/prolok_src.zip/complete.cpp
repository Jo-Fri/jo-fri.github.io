//===========================================================================

//Seite tsAllCV

void __fastcall TmainForm::tsAllCVShow(TObject *Sender)
// alle Werte anzeigen im Formular '1..1024'
{
   enterTabSheet((TTabSheet *)Sender);
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::tsAllCVHide(TObject *Sender)
// alle Werte aus Formular '1..1024' in die CV-Tabelle �bernehmen
{
   exitTabSheet((TTabSheet *)Sender);
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::loadAllCV() {
   int i;
   iLastSelectedCell = 0;
   for(i=0;i<1024;++i) {
      if(CVs[i]==-1)
         sg1_1024->Cells[2][i+1] = "";
      else
         sg1_1024->Cells[2][i+1] = IntToStr(CVs[i]);
      if(usedCVs[i])
         sg1_1024->RowHeights[i+1] = sg1_1024->DefaultRowHeight;
      else
         hideRow(i+1);
   }
}
//---------------------------------------------------------------------------
void __fastcall TmainForm::saveAllCV()
// alle Werte aus Formular '1..1024' in die CV-Tabelle �bernehmen
{
   int i;
   for(i=0;i<1024;++i) {
      CVs[i] = testIntVal(sg1_1024->Cells[2][i+1],0,255,true);
      usedCVs[i] = (CVs[i]!=-1) || bUseAll;
   }
   usedCVs[17] = usedCVs[16] || usedCVs[17];
   usedCVs[16] = usedCVs[17];
   if(usedCVs[17] && CVs[17]==-1) CVs[17]=0;
   if(usedCVs[16] && CVs[16]==-1) CVs[17]=192;
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::writeAllCV()
// alle Werte aus Formular '1..1024' schreiben
{
   int i,a;
   cancelled = false;
   i=0;
   while(!cancelled && i<1024) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[i] && CVs[i]!=-1) {
         if(!setCV(i+1, testIntVal(sg1_1024->Cells[2][i+1],0,255,true)))
            a=errMsg("Schreiben",i+1);
      }
      i=errControl(a,i);
   }
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void __fastcall TmainForm::verifyAllCV()
// alle Werte aus Formular '1..1024' schreiben
{
   int i, a;
   cancelled = false;
   i=0;
   while(!cancelled && i<1024) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[i] && CVs[i]!=-1)
         if(!verifyCV(i+1, testIntVal(sg1_1024->Cells[2][i+1],0,255,true)))
            a=errMsg("Pr�fen",i+1);
      i=errControl(a,i);
   }
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::readAllCV()
// alle Werte aus Formular '1..1024' lesen
{
   int i, a, cv;
   i=0;
   while(!cancelled && i<1024) {
      a=0;
      Application->ProcessMessages();
      if(usedCVs[i]) {
         if(getCV(i+1))
            sg1_1024->Cells[2][i+1] = CVs[i];
         else {
            sg1_1024->Cells[2][i+1] = "0";
            a=errMsg("Lesen",i+1);
         }
      }
      i=errControl(a,i);
   }
}

//---------------------------------------------------------------------------

void __fastcall TmainForm::makeCV1_1024Headers() {
// erstellt die Liste der CVs von 1-1024 und
// tr�gt die Beschreibungen der CV lt.  RP9.2.2 in
// die Stringtabelle Beschreibungstabelle ein
   int i;
   sg1_1024->TopRow = 1;
   sg1_1024->LeftCol = 1;
   sg1_1024->Cells[0][0] = "CV#";
   sg1_1024->Cells[1][0] = sz_Description;
   sg1_1024->Cells[2][0] = sz_Value;
   for(i=1; i<1025; ++i) {
      sg1_1024->Cells[0][i] = IntToStr(i);
      sg1_1024->Cells[2][i] = CVs[(i-1)]==-1? (String)"":IntToStr(CVs[i-1]);
      if(usedCVs[i-1])
         sg1_1024->RowHeights[i] = sg1_1024->DefaultRowHeight;
      else
         hideRow(i);
   }
   readRP922();
}

//--------------------------------------------------------------------------
void __fastcall TmainForm::hideRow(int row) {
//versteckt die Zeile
   sg1_1024->RowHeights[row] = 0;
}


//---------------------------------------------------------------------------
void __fastcall TmainForm::sg1_1024SelectCell(TObject *Sender, int ACol,
      int ARow, bool &CanSelect)
{
   int row = ARow - 1;
   int dist;
   if(!usedCVs[row]) {
      if(iLastSelectedCell > row)
         dist = -1;
      else
         dist = 1;
      while(row>-1 && row<1024 && !usedCVs[row])
         row+=dist;
      if(row==1024) {
         --row;
         while(row>-1 && !usedCVs[row])
            --row;
      }
      if(row==-1)
         row = 0;
      CanSelect = false;
      sg1_1024->Row = row+1;
   }
   iLastSelectedCell = sg1_1024->Row - 1;
}
//---------------------------------------------------------------------------


