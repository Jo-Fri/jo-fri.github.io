//---------------------------------------------------------------------------

#ifndef riH
#define riH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TRingIndikator : public TThread
{
  typedef struct tagTHREADNAME_INFO
  {
    DWORD dwType;     // mu� 0x1000 sein
    LPCSTR szName;    // Zeiger auf Name (in user addr space)
    DWORD dwThreadID; // Thread-ID (-1=caller thread)
    DWORD dwFlags;    // Reserviert f�r sp�tere Verwendung, mu� 0 sein
  } THREADNAME_INFO;
private:
  void SetName();
protected:
   void __fastcall Execute();
public:
   __fastcall TRingIndikator(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif
