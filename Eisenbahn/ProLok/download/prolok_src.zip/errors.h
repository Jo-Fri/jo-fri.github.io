//---------------------------------------------------------------------------

#ifndef errorsH
#define errorsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TfaultListe : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TListBox *lbErrors;
   TButton *pbClose;
   TLabel *lbHeadLine;
   void __fastcall pbCloseClick(TObject *Sender);
private:	// Anwender-Deklarationen
public:		// Anwender-Deklarationen
   __fastcall TfaultListe(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfaultListe *faultListe;
//---------------------------------------------------------------------------
#endif
