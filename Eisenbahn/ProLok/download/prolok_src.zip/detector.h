//---------------------------------------------------------------------------

#ifndef detectorH
#define detectorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TDetectorThread : public TThread
{
  typedef struct tagTHREADNAME_INFO
  {
    DWORD dwType;     // mu� 0x1000 sein
    LPCSTR szName;    // Zeiger auf Name (in user addr space)
    DWORD dwThreadID; // Thread-ID (-1=caller thread)
    DWORD dwFlags;    // Reserviert f�r sp�tere Verwendung, mu� 0 sein
  } THREADNAME_INFO;
private:
  void SetName();
  String Info;
  void __fastcall setButtons();
protected:
   void __fastcall Execute();
public:
   bool LocoDetected;
   int  iNoLoco;
   __fastcall TDetectorThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif
