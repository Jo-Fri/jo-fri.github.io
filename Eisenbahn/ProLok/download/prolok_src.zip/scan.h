//---------------------------------------------------------------------------

#ifndef scanH
#define scanH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TscanForm : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
   TGroupBox *gbRange;
   TLabel *lbFrom;
   TLabel *lbTo;
   TEdit *efStartScan;
   TEdit *efStopScan;
   TUpDown *UpDownStartScan;
   TUpDown *UpDownStopScan;
   TButton *pbAdd;
   TListBox *lbScanRanges;
   TButton *pbDel;
   TButton *pbClose;
   TButton *pbScan;
   TProgressBar *ProgressBar1;
   TButton *pbCancel;
   void __fastcall UpDownStartScanClick(TObject *Sender, TUDBtnType Button);
   void __fastcall UpDownStopScanClick(TObject *Sender, TUDBtnType Button);
   void __fastcall pbAddClick(TObject *Sender);
   void __fastcall pbCloseClick(TObject *Sender);
   void __fastcall pbScanClick(TObject *Sender);
   void __fastcall pbCancelClick(TObject *Sender);
   void __fastcall pbDelClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall FormHide(TObject *Sender);
private:	// Anwender-Deklarationen
   void __fastcall Init();
public:		// Anwender-Deklarationen
   __fastcall TscanForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TscanForm *scanForm;
//---------------------------------------------------------------------------
#endif
