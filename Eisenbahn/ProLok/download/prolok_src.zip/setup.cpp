//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "setup.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TsetupForm *setupForm;

#include "tolop_main.h"
#include "detector.h"

extern TmainForm *mainForm;
extern TDetectorThread *LocoDetector;

//---------------------------------------------------------------------------
__fastcall TsetupForm::TsetupForm(TComponent* Owner)
   : TForm(Owner)
{
   mainForm->loadFormCaptions(mainForm->szLanguage, setupForm);
}
//---------------------------------------------------------------------------
void __fastcall TsetupForm::FormShow(TObject *Sender)
{
   int index;
   if(mainForm->bDirectMode && mainForm->bPageMode)
      cbAutoMode->Checked = true;
   else {
      cbAutoMode->Checked = false;
      cbDirectMode->Checked = mainForm->bDirectMode;
      cbPageMode->Checked = mainForm->bPageMode;
   }
   cbUSBserial->Checked = mainForm->bUSBserial;
   if(cbUSBserial->Checked) {
      cbSafeMode->Enabled=false;
      cbSafeMode->Checked = true;
   }
   else {
      cbSafeMode->Enabled=true;
      cbSafeMode->Checked = mainForm->bSafeMode;
   }
   cb16457bps->Checked = mainForm->PR1_NMRA_cps;
   rbIsDDL->Checked = mainForm->bIsDDL;
   rbIsPR1->Checked = !rbIsDDL->Checked;
   cbIs6604->Checked = mainForm->bExtendedPowerOn;
   mefWait->Text = IntToStr(mainForm->iWaitXms);
   setLanguages();
   if(mainForm->bDirectMode)
      cbTest0Bit->Checked = mainForm->bTest0Bit;
   else {
      cbTest0Bit->Checked = false;
      cbTest0Bit->Enabled = false;
   }

   if(mainForm->ComPort1->Connected)
      mainForm->ComPort1->Close();
   mainForm->StatusBar1->Panels->Items[1]->Text = "";
   mainForm->StatusBar1->Panels->Items[2]->Text = "";
   newPR1Port = mainForm->PR1Port;
   EnumComPorts(cbPorts->Items);
   if(cbPorts->Items->Count>0) {
      if(newPR1Port!="" && (index = cbPorts->Items->IndexOf(newPR1Port))!=-1)
         cbPorts->ItemIndex = index;
      else
         cbPorts->ItemIndex = 0;
   }
   if(newPR1Port != "")
      cbPorts->Text = newPR1Port;
   bOK = true;
   if(mainForm->iRetryOnError>-1) {
      cbBulk->Checked=true;
      lblBulk->Enabled=true;
      efBulk->Enabled=true;
      efBulk->Text=IntToStr(mainForm->iRetryOnError);
   }
   else {
      cbBulk->Checked=false;
      lblBulk->Enabled=false;
      efBulk->Enabled=false;
      efBulk->Text="2";
   }
   newLang = mainForm->szLanguage;
   if(cbLang->Items->Count>0) {
      if(mainForm->szLanguage!="" &&
         (index = cbLang->Items->IndexOf(mainForm->szLanguage))!=-1)
         cbLang->ItemIndex = index;
      else
         cbLang->ItemIndex = 0;
   }

}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::pbCancelClick(TObject *Sender)
{
   bOK = false;
   setupForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::pbOKClick(TObject *Sender)
{
   newPR1Port = cbPorts->Text;
   setupForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::cbPortsChange(TObject *Sender)
{
   	newPR1Port = cbPorts->Text;
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::FormHide(TObject *Sender)
{
  if(bOK) {
   mainForm->bPageMode = cbPageMode->Checked | cbAutoMode->Checked;
   mainForm->bDirectMode = cbDirectMode->Checked | cbAutoMode->Checked;
   mainForm->bUSBserial = cbUSBserial->Checked;
   mainForm->bIsDDL = rbIsDDL->Checked;
   mainForm->bSafeMode = cbSafeMode->Checked;
   mainForm->bTest0Bit = cbTest0Bit->Checked && mainForm->bDirectMode;
   mainForm->bExtendedPowerOn = cbIs6604->Checked;
   mainForm->PR1_NMRA_cps = cb16457bps->Checked;
   try {
      mainForm->iWaitXms = StrToInt(mefWait->Text);
   }
   catch(Exception *E) {
      mainForm->iWaitXms = 0;
   }
   if(newPR1Port != "") {
     mainForm->PR1Port = newPR1Port;
     mainForm->connectPort(mainForm->PR1Port);
   }
   else
     mainForm->StatusBar1->Panels->Items[0]->Text = mainForm->sz_noPort;

   if(cbBulk->Checked) {
      try {
         mainForm->iRetryOnError = StrToInt(efBulk->Text);
      }
      catch(Exception *E) {
         mainForm->iRetryOnError = 0;
      }
   }
   else
      mainForm->iRetryOnError = -1;
   if(newLang != "" && newLang != mainForm->szLanguage) {
     mainForm->szLanguage = newLang;
     mainForm->setTextRessources(newLang);
   }
  }
  if(mainForm->PR1Port!="")
     mainForm->connectPort(mainForm->PR1Port);
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::cbDirectModeClick(TObject *Sender)
{
   cbTest0Bit->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::cbPageModeClick(TObject *Sender)
{
   cbTest0Bit->Enabled=false;
   cbTest0Bit->Checked=false;
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::cbAutoModeClick(TObject *Sender)
{
   cbTest0Bit->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::cbBulkClick(TObject *Sender)
{
   efBulk->Enabled=cbBulk->Checked;
   lblBulk->Enabled=efBulk->Enabled;
}
//---------------------------------------------------------------------------

void __fastcall TsetupForm::cbLangChange(TObject *Sender)
{
   	newLang = cbLang->Text.LowerCase();
}
//---------------------------------------------------------------------------
void __fastcall TsetupForm::setLanguages()
{
   TSearchRec tsr;
   cbLang->Clear();
   cbLang->Items->Add("deutsch");
   if(FindFirst(mainForm->szPath + "*.lng", faAnyFile, tsr)==0) {
      do {
         int iPos = tsr.Name.Pos(".lng")-1;
         cbLang->Items->Add(tsr.Name.SubString(0,iPos));
      } while(FindNext(tsr)==0);
      FindClose(tsr);
   }
}

void __fastcall TsetupForm::cbUSBserialClick(TObject *Sender)
{
   if(cbUSBserial->Checked) {
      cbSafeMode->Enabled=false;
      cbSafeMode->Checked = true;
   }
   else {
      cbSafeMode->Enabled=true;
      cbSafeMode->Checked = mainForm->bSafeMode;
   }
}
//---------------------------------------------------------------------------


