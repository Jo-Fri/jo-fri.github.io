//---------------------------------------------------------------------------

#ifndef srcpterminal_mainH
#define srcpterminal_mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ScktComp.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Menus.hpp>

#include <IniFiles.hpp>
#include <Buttons.hpp>

//---------------------------------------------------------------------------
class TSrcpTerm : public TForm
{
__published:	// Von der IDE verwaltete Komponenten
        TLabel *Label3;
        TLabel *Label4;
        TComboBox *CB_Cmd;
        TButton *PB_Send;
        TMemo *MEMO_Resp;
        TStatusBar *StatusBar1;
        TClientSocket *IPSock;
        TImage *Image1;
        TMainMenu *MM_1;
        TMenuItem *Datei1;
        TMenuItem *MM_1_Connect;
        TMenuItem *MM_1_Disconnect;
        TMenuItem *MM_1_Close;
        TSpeedButton *PB_Connect;
        void __fastcall PB_ConnectClick(TObject *Sender);
        void __fastcall Save(TObject *Sender, TCloseAction &Action);
        void __fastcall Load(TObject *Sender);
        void __fastcall Put(TObject *Sender);
        void __fastcall SetChangedFlag(TObject *Sender);
        void __fastcall CBCmdKeyPressed(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall ClientConnect(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall TryClientConnect(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall ClientDisconnect(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall ClientSockErr(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
        void __fastcall ClientRead(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall ClientWrite(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall SrcpTermClose(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
public:		// Anwender-Deklarationen
        __fastcall TSrcpTerm(TComponent* Owner);
        String Server;
        Integer Port;
        bool bTextChanged;
private:
        void __fastcall SendSrcpCommand(void);
        void __fastcall ConnectToServer(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TSrcpTerm *SrcpTerm;
//---------------------------------------------------------------------------
#endif
