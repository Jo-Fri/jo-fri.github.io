//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "srcpterminal_main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSrcpTerm *SrcpTerm;

//---------------------------------------------------------------------------
__fastcall TSrcpTerm::TSrcpTerm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::PB_ConnectClick(TObject *Sender)
{
        ConnectToServer();
}
//---------------------------------------------------------------------------
void __fastcall TSrcpTerm::Save(TObject *Sender, TCloseAction &Action)
{
   if(IPSock->Active==true)
    IPSock->Close();
   TMemIniFile *pIniFile = new TMemIniFile("srcpterm.ini");
   try{
    pIniFile->Clear();
    pIniFile->WriteInteger("FormPosition", "Top", SrcpTerm->Top);
    pIniFile->WriteInteger("FormPosition", "Left", SrcpTerm->Left);
    pIniFile->WriteString("IPConnection", "Server", Server);
    pIniFile->WriteInteger("IPConnection", "Port", Port);
    for(int i=0; i<CB_Cmd->Items->Count; i++) {
     pIniFile->WriteString("RecentSRCPCommands", "Cmd[" + (String)i + "]", CB_Cmd->Items->Strings[i]);
    }
    pIniFile->UpdateFile();
   }
   __finally{
    delete pIniFile;
   }
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::Load(TObject *Sender)
{
  MEMO_Resp->Clear();
//  CB_Cmd->Items->LoadFromFile("srcpterm.dat");
  TMemIniFile *pIniFile = new TMemIniFile("srcpterm.ini");
  try{
   TStringList *pValues = new TStringList;
   try{
    pIniFile->ReadSectionValues("RecentSRCPCommands", pValues);
    for(int i=0; i<pValues->Count; ++i) {
    if(char *pItem =(char *)StrScan(pValues->Strings[i].c_str(),'='))
     CB_Cmd->Items->Add(pItem+1);
    }
   }
   __finally{
     delete pValues;
   }
  }
  __finally{
   delete pIniFile;
  }

}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::Put(TObject *Sender)
{
    SendSrcpCommand();
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::SetChangedFlag(TObject *Sender)
{
        bTextChanged = true;
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::CBCmdKeyPressed(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if (Key==VK_DELETE) {
    if(!CB_Cmd->Text.IsEmpty())
     CB_Cmd->ItemIndex = CB_Cmd->Items->IndexOf(CB_Cmd->Text);
    if(CB_Cmd->ItemIndex!=-1)
      CB_Cmd->DeleteSelected();
  }
  if (Key == VK_RETURN) {
      SendSrcpCommand();
  }
}
//---------------------------------------------------------------------------
void __fastcall TSrcpTerm::ClientConnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  MM_1_Connect->Enabled = false;
  MM_1_Disconnect->Enabled = true;
  CB_Cmd->Enabled = true;
  StatusBar1->Panels->Items[0]->Text= "Verbunden mit " + Socket->RemoteHost + ":" + IntToStr(Socket->RemotePort);
  PB_Send->Enabled = true;
  PB_Connect->Hint = "Trennen";
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::TryClientConnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  StatusBar1->Panels->Items[0]->Text= "Verbinde mit " + Server + ":" + IntToStr(Port);
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::ClientDisconnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  MM_1_Connect->Enabled = true;
  MM_1_Disconnect->Enabled = false;
  CB_Cmd->Enabled = false;
  StatusBar1->Panels->Items[0]->Text= "";
  StatusBar1->Panels->Items[1]->Text= "";
  CB_Cmd->Text="";
  MEMO_Resp->Clear();
  PB_Send->Enabled = false;
  PB_Connect->Hint = "Verbinden";
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::ClientSockErr(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
  MEMO_Resp->Lines->Add("Kommunikationsfehler an Server " + Server + ":" + IntToStr(Port));
  String sErrorType;
  switch(ErrorEvent) {
   default:
   case eeGeneral: sErrorType = "unbekannter Fehler"; break;
   case eeSend: sErrorType = "Fehler beim Senden"; break;
   case eeReceive: sErrorType = "Fehler beim Empfangen"; break;
   case eeConnect: sErrorType = "Fehler beim Verbinden"; break;
   case eeDisconnect: sErrorType = "Fehler beim Trennen"; break;
  }
  MEMO_Resp->Lines->Add("Fehler " + IntToStr(ErrorCode) + ": " + sErrorType);
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::ClientRead(TObject *Sender,
      TCustomWinSocket *Socket)
{
  String received = Socket->ReceiveText();
  MEMO_Resp->Lines->Add(Trim(received));
  if(StrPos(StrUpper(received.c_str()), "SRCP 0.7"))
   StatusBar1->Panels->Items[1]->Text= "SRCP 0.7";
  if(StrPos(StrUpper(received.c_str()), "SRCP 0.8"))
   StatusBar1->Panels->Items[1]->Text= "SRCP 0.8";
}
//---------------------------------------------------------------------------



void __fastcall TSrcpTerm::ClientWrite(TObject *Sender,
      TCustomWinSocket *Socket)
{
    MEMO_Resp->Lines->Add(CB_Cmd->Text);
}
//---------------------------------------------------------------------------

void __fastcall TSrcpTerm::SendSrcpCommand(void)
{
  AnsiString text = CB_Cmd->Text.UpperCase();
  if (bTextChanged==true) {
   TObject *newEntry;
   if (!text.IsEmpty()) {
    if(CB_Cmd->Items->IndexOf(text) == -1)
     CB_Cmd->AddItem(text, newEntry);
   }
   bTextChanged = false;
  }
  if(text > "" && IPSock->Active==true)
   IPSock->Socket->SendText(text + "\n");
}
void __fastcall TSrcpTerm::SrcpTermClose(TObject *Sender)
{
        SrcpTerm->Close();
}
//---------------------------------------------------------------------------



void __fastcall TSrcpTerm::ConnectToServer(void)
{
 MEMO_Resp->Clear();
 String sInput="";
 if (Server>"")
  sInput = Server + ":" + IntToStr(Port);
 else
  sInput = "localhost:12345";
 Server = "";
 Port = 0;
 if (IPSock->Active==false) {
  if(InputQuery("Verbinden mit Server",
                "Bitte Adresse in der Form Servername:Port oder IP-Adresse:Port eingeben",
                sInput)) {
   char *pszPort;
   char *pszInput = new char[sInput.Length() + 1];
   StrCopy(pszInput, sInput.c_str());
   if((pszPort = StrScan(pszInput, ':'))!= NULL) {
    Port = StrToInt(pszPort + 1);
    *pszPort = '\0';
    Server = Trim((String)pszInput);
    IPSock->Host = Server;
    IPSock->Port = Port;
   }
   delete [] pszInput;
  }
  if(Server>"" && Port>1023 && Port<66535)
   IPSock->Open();
  else {
   if(Port<1024 || Port>65535)
    MEMO_Resp->Lines->Add("Port muss im Bereich 1024..65535 sein");
   else
    MEMO_Resp->Lines->Add("Bitte einen Servernamen oder eine IP-Adresse angeben");
  }
 }
 else {
  IPSock->Close(); // Trennen
 }
}

void __fastcall TSrcpTerm::FormCreate(TObject *Sender)
{
  TMemIniFile *pIniFile = new TMemIniFile("srcpterm.ini");
  try{
   SrcpTerm->Top = pIniFile->ReadInteger("FormPosition", "Top", 20);
   SrcpTerm->Left = pIniFile->ReadInteger("FormPosition", "Left", 120);
   Server = pIniFile->ReadString("IPConnection", "Server", "localhost");
   Port = pIniFile->ReadInteger("IPConnection", "Port", 12345);
  }
  __finally{
   delete pIniFile;
  }
}
//---------------------------------------------------------------------------


